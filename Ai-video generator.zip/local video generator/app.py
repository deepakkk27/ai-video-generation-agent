"""Local Course Video Generator — Streamlit UI."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

import streamlit as st

from config import SETTINGS as S
from src.ingestion.dispatcher import IngestError, new_job_id, sanitize_filename
from src.llm.ollama_client import OllamaClient
from src.pipeline import orchestrator as orch
from src.pipeline.duration import target_word_count
from src.storage.jobs import JobStore
from src.tts.factory import make_tts
from src.ui.components import CSS, download_if_exists, status_badge
from src.ui.progress import ProgressView
from src.video.ffmpeg import check_ffmpeg
from src.visuals.theme import THEMES

st.set_page_config(page_title="Course Video Generator", page_icon="🎓", layout="centered")
st.markdown(CSS, unsafe_allow_html=True)
store = JobStore(S.output_dir)

st.title("Course Video Generator")
st.write("Upload learning material, choose a target duration, and generate a narrated educational video locally.")
st.caption("🔒 Your files stay on this computer. No content is sent to any external service.")

# ---- System readiness ----
with st.expander("System readiness", expanded=False):
    with st.form("adv"):
        model = st.text_input("Ollama model", S.ollama_model)
        provider = st.selectbox("TTS backend", ["kokoro", "piper"], index=["kokoro", "piper"].index(S.tts_provider))
        st.form_submit_button("Apply")
    llm = OllamaClient(S.ollama_base_url, model, S.ollama_num_ctx, S.ollama_temperature)
    probe_tts = make_tts(provider)
    voices = probe_tts.list_voices()
    voice = st.selectbox("Voice (installed only)", voices or ["(none installed)"])
    tts = make_tts(provider, voice if voices else "")
    ff_ok, ff_msg = check_ffmpeg()
    llm_ok, llm_msg = llm.health()
    tts_ok, tts_msg = tts.availability()
    status_badge(ff_ok, ff_msg)
    status_badge(llm_ok, llm_msg)
    status_badge(tts_ok, tts_msg)
    if tts_ok and st.button("Run voice self-test"):
        with tempfile.TemporaryDirectory() as td:
            ok, m = tts.self_test(Path(td) / "t.wav")
        status_badge(ok, m)
ready = ff_ok and llm_ok and tts_ok

# ---- Section A: source ----
st.header("1. Source file")
up = st.file_uploader("Drag and drop a file", type=["pdf", "pptx", "docx", "txt", "md", "srt", "vtt"])
if up is not None:
    st.write(f"**{up.name}** · {up.size / 1024:.0f} KB · type: {Path(up.name).suffix.lower().lstrip('.')}")
    if up.size > S.max_upload_mb * 1024 * 1024:
        st.error(f"File exceeds the {S.max_upload_mb} MB limit.")
    elif st.button("Analyze source"):
        jid = new_job_id()
        jdir = store.create(jid)
        dest = jdir / ("original_" + sanitize_filename(up.name))
        dest.write_bytes(up.getbuffer())
        try:
            with st.spinner("Extracting content..."):
                orch.analyze_source(store, jid, dest, S)
            st.session_state["job_id"] = jid
        except IngestError as e:
            st.error(str(e))
            store.delete(jid)
        except Exception as e:  # noqa: BLE001
            st.error(f"Unexpected error while reading the file: {e}")
            store.delete(jid)

jid = st.session_state.get("job_id")
job = store.load(jid) if jid else {}
src = job.get("source")
if src:
    c1, c2, c3 = st.columns(3)
    c1.metric("Records (pages/slides/paragraphs)", src["records"])
    c2.metric("Chunks", src["chunks"])
    c3.metric("Words", src["words"])
    status_badge(src["coverage_complete"], "Extraction coverage: " +
                 ("complete" if src["coverage_complete"] else "INCOMPLETE — some pages/slides failed or were skipped"))
    for w in src["warnings"]:
        st.warning(w)
    jd = store.job_dir(jid)
    text = (jd / "extracted_text.txt").read_text(encoding="utf-8")
    st.text_area("Preview", text[:2000], height=140, disabled=True)
    download_if_exists("Download extracted text", jd / "extracted_text.txt", "text/plain", "dl_text")

    # ---- Section B ----
    st.header("2. Course settings")
    if "minutes" not in st.session_state:
        st.session_state["minutes"] = S.default_duration_minutes
    qcols = st.columns(5)
    for col, m in zip(qcols, (10, 20, 30, 40, 60)):
        if col.button(f"{m} min"):
            st.session_state["minutes"] = min(m, S.max_duration_minutes)
    minutes = st.number_input("Target duration (minutes)", 1, S.max_duration_minutes, step=1, key="minutes")
    mode_label = st.radio("Content mode", ["Source-grounded (recommended)", "Expanded teaching"])
    mode = "source" if mode_label.startswith("Source") else "expanded"
    if mode == "expanded":
        st.info("Expanded teaching adds labelled analogies/examples. Version 1 has no browsing, so new "
                "factual claims are flagged as needing outside confirmation, never marked verified.")
    audience = st.text_input("Audience / level", "general adult learners")
    title = st.text_input("Course title (optional)")
    theme = st.selectbox("Visual theme", list(THEMES))
    low_res = st.checkbox("Use 1280×720 (faster, lighter on memory)")

    words = target_word_count(minutes, S.words_per_minute)
    st.markdown(f"**Confirmation:** {src['words']} source words · {minutes} min target · "
                f"{mode_label} · voice: {tts.name}/{tts.voice} · ≈{words} narration words")
    if src["words"] < words * 0.5 and mode == "source":
        st.warning("The source looks short for this duration. In source-grounded mode the video may come "
                   "out shorter than the target rather than adding invented content.")
    if not ready:
        st.error("Generation is disabled until FFmpeg, Ollama (with the model) and a TTS voice are ready. "
                 "Open 'System readiness' above for exact fix commands.")

    if st.button("Generate video", type="primary", disabled=not ready or job.get("status") == "running"):
        req = orch.CourseRequest(minutes=int(minutes), mode=mode, audience=audience, title=title,
                                 theme=theme, low_res=low_res)
        view = ProgressView()
        try:
            orch.generate_video(store, jid, req, S, llm, tts, view)
            st.success("Video generated.")
        except orch.PipelineError as e:
            st.error(f"Generation stopped: {e}")
            st.caption("Completed intermediate work was kept. Click Generate video again to resume.")
        job = store.load(jid)

# ---- Section D ----
if jid and job.get("status") in ("complete", "complete_out_of_tolerance"):
    st.header("3. Preview and download")
    jd = store.job_dir(jid)
    mp4 = jd / "course_video.mp4"
    meta_f = jd / "video_metadata.json"
    if mp4.exists() and meta_f.exists():
        meta = json.loads(meta_f.read_text(encoding="utf-8"))
        st.video(str(mp4))
        c1, c2, c3 = st.columns(3)
        c1.metric("Measured duration", f"{meta['actual_duration_s'] / 60:.2f} min")
        c2.metric("Target", f"{meta['target_duration_s'] / 60:.2f} min")
        c3.metric("Deviation", f"{meta['deviation_percent']:+.1f}%")
        st.write(f"{meta['width']}×{meta['height']} @ {meta['fps']:.0f} fps · {meta['video_codec']}/{meta['audio_codec']} · "
                 f"{mp4.stat().st_size / 1e6:.1f} MB · audio: {'yes' if meta['has_audio'] else 'NO'} · "
                 "captions: burned in + SRT (sentence-level sync)")
        if meta["within_tolerance"]:
            st.success(job["result"]["duration_statement"])
        else:
            st.error("The target duration was NOT met. " + job["result"]["duration_statement"] + " "
                     + job["result"].get("cause", ""))
        for w in job["result"].get("warnings", [])[:10]:
            st.caption("⚠ " + w)
        qa_f = jd / "qa_report.md"
        if qa_f.exists():
            with st.expander("Quality report (automated checks only)"):
                st.markdown(qa_f.read_text(encoding="utf-8"))
        sync_f = jd / "sync" / "sync_report.md"
        if sync_f.exists():
            res = job.get("result", {})
            (st.success if res.get("sync_verified") else st.warning)(
                "Narration/visual sync " + ("verified on the final MP4" if res.get("sync_verified") else "NOT fully verified")
                + (" · word-level alignment used" if res.get("word_level_alignment") else " · sentence-level only (WhisperX not used)"))
            with st.expander("Synchronization report"):
                st.markdown(sync_f.read_text(encoding="utf-8"))
        download_if_exists("Download MP4", mp4, "video/mp4", "dl_mp4")
        download_if_exists("Download SRT", jd / "captions.srt", "text/plain", "dl_srt")
        download_if_exists("Download script", jd / "script.md", "text/markdown", "dl_script")
        download_if_exists("Download outline", jd / "outline.md", "text/markdown", "dl_outline")
        download_if_exists("Download coverage report", jd / "analysis_coverage.json", "application/json", "dl_cov")

# ---- Saved jobs ----
with st.expander("Saved jobs"):
    for j in store.list_jobs()[:20]:
        c1, c2, c3 = st.columns([3, 2, 2])
        c1.write(f"`{j['job_id'][:8]}` {j.get('source', {}).get('filename', '')}")
        c2.write(j.get("status", ""))
        if c3.button("Open", key=f"o{j['job_id']}"):
            st.session_state["job_id"] = j["job_id"]
            st.rerun()
        if st.checkbox("Confirm delete", key=f"c{j['job_id']}") and st.button("Delete job and files", key=f"d{j['job_id']}"):
            store.delete(j["job_id"])
            st.session_state.pop("job_id", None)
            st.rerun()
