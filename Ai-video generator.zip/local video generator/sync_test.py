"""60-90 s synchronization test video (9 beats: definition, steps, diagram-like flow, chart, comparison...).

    python sync_test.py                # real Kokoro voice + real WhisperX alignment (what you want to watch)
    python sync_test.py --llm          # additionally let Qwen (Ollama) ground the on-screen items
    python sync_test.py --synthetic    # no models: tone 'speech' with known word times (checks the machinery)
    python sync_test.py --legacy       # same script through the OLD per-segment assembler, for comparison

Output: outputs/sync_test/ -> sync_test.mp4, sync/sync_report.md|json, sync/verify_frames/, contact_sheet.png
"""
from __future__ import annotations

import argparse
import math
import shutil
import sys
import wave
from pathlib import Path

import numpy as np
from PIL import Image

from config import SETTINGS as S
from src.models.schemas import AlignedWord, AudioUnit, Segment, UnitAlignment
from src.sync import qa_sync, runner as sync_runner
from src.sync.aligner import Aligner
from src.tts.audio_utils import TARGET_SR, wav_duration
from src.video import assembler, probe
from src.video.subtitles import assign_timeline
from src.visuals.renderer import render_frames, render_shots, split_units

SCRIPT = [
    ("intro", "title", "K-Means Clustering", ["Unsupervised learning"],
     "Welcome. In this short lesson we will learn how K-Means clustering works."),
    ("explanation", "definition", "What is K-Means?",
     ["K-Means groups unlabeled data into k clusters", "Each cluster is represented by a centroid"],
     "K-Means is an unsupervised algorithm that groups unlabeled data into k clusters. "
     "Each cluster is represented by its center, called a centroid."),
    ("explanation", "steps", "The four steps",
     ["Initialize the centroids", "Assign points to clusters", "Update the centroids", "Repeat until stable"],
     "The algorithm repeats four steps. First, initialize the centroids at random positions. "
     "Second, assign every data point to its nearest centroid. "
     "Third, update each centroid to the mean of its assigned points. "
     "Fourth, repeat until the assignments stop changing."),
    ("explanation", "bullets", "Centroid initialization",
     ["Random starts", "Poor clusters possible", "K-Means plus plus spreads centroids"],
     "Centroid initialization matters. Random starts can give poor clusters. "
     "K-Means plus plus avoids this by spreading the starting centroids far apart."),
    ("explanation", "comparison", "Choosing k",
     ["Elbow method", "Silhouette score"],
     "Choosing k is difficult. The elbow method plots the error against k and looks for a bend. "
     "The silhouette score measures how well each point fits its own cluster."),
    ("example", "chart", "Error falls as k grows",
     ["One cluster", "Two clusters", "Three clusters", "Four clusters"],
     "Look at the error values. With one cluster the error is one hundred. "
     "With two clusters it falls to fifty five. Three clusters brings it down to thirty. "
     "After four clusters the gains are small."),
    ("question", "question", "Checkpoint", ["Six customers", "k equals two", "Which centroid?"],
     "Try this. Imagine six customers and k equal to two. Which centroid does each customer join?"),
    ("recap", "recap", "Key takeaways",
     ["Initialize centroids", "Assign points", "Update centroids", "Choose k carefully"],
     "To recap. K-Means initializes centroids, assigns points, and updates the centroids until nothing changes. "
     "Choose k carefully and initialize wisely."),
    ("outro", "closing", "Summary", ["Thanks for watching"], "That completes the lesson. Review the key points."),
]
CHART = {"labels": ["One cluster", "Two clusters", "Three clusters", "Four clusters"], "values": [100, 55, 30, 22]}


def make_segments() -> list[Segment]:
    segs = []
    for i, (typ, vis, title, items, text) in enumerate(SCRIPT):
        segs.append(Segment(segment_id=f"T-S{i + 1:03d}", module_id="T", narration_text=text, segment_type=typ,
                            visual_type=vis, visual_title=title, on_screen_text=items,
                            chart_data=CHART if vis == "chart" else None, source_ids=["TEST"]))
    return segs


# ------------------------------------------------------------------ synthetic "speech" with known times
class TruthAligner(Aligner):
    """Returns the exact word times the synthetic audio was built from (ground truth)."""
    name = "ground-truth(synthetic)"

    def __init__(self):
        self.truth: dict[str, list[AlignedWord]] = {}

    def availability(self):
        return True, "synthetic ground truth"

    def align(self, wav, text, duration_s, unit_id):
        return UnitAlignment(unit_id=unit_id, status="ok", aligner=self.name, words=self.truth[Path(wav).stem])


def synth_tone_speech(text: str, out: Path, truth: dict) -> None:
    words, t, parts, tw = text.split(), 0.08, [np.zeros(int(0.08 * TARGET_SR))], []
    for w in words:
        d = 0.10 + 0.050 * len(w)
        n = int(d * TARGET_SR)
        x = np.arange(n) / TARGET_SR
        f = 180 + (sum(map(ord, w)) % 40) * 9
        env = np.minimum(1, np.minimum(x / 0.01, (d - x) / 0.02))
        parts.append(np.sin(2 * math.pi * f * x) * env * 0.4)
        tw.append(AlignedWord(word=w, start=round(t, 3), end=round(t + d, 3), score=0.9, aligned=True))
        gap = 0.07 + (0.18 if w.endswith(",") else 0)
        parts.append(np.zeros(int(gap * TARGET_SR)))
        t += d + gap
    pcm = (np.concatenate(parts) * 32767).astype(np.int16)
    with wave.open(str(out), "wb") as wv:
        wv.setnchannels(1); wv.setsampwidth(2); wv.setframerate(TARGET_SR); wv.writeframes(pcm.tobytes())
    truth[out.stem] = tw


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--llm", action="store_true")
    ap.add_argument("--legacy", action="store_true")
    ap.add_argument("--out", default=str(S.output_dir / "sync_test"))
    ap.add_argument("--lowres", action="store_true", help="1280x720")
    a = ap.parse_args()
    out = Path(a.out)
    if out.exists():
        shutil.rmtree(out)
    (out / "audio").mkdir(parents=True)
    W, H = (S.fallback_video_width, S.fallback_video_height) if a.lowres else (S.video_width, S.video_height)
    fps, pause = S.video_fps, S.pause_between_units_s
    segs = make_segments()

    tts, aligner, truth = None, None, {}
    if a.synthetic:
        aligner = TruthAligner()
        aligner.truth = truth
    else:
        from src.tts.factory import make_tts
        tts = make_tts(S.tts_provider, S.tts_voice)
        ok, msg = tts.availability()
        if not ok:
            print("TTS not ready:", msg); return 2

    units: list[AudioUnit] = []
    for seg in segs:
        for i, text in enumerate(split_units(seg.narration_text), 1):
            uid = f"{seg.segment_id}-U{i:02d}"
            wav = out / "audio" / f"{uid}.wav"
            if a.synthetic:
                synth_tone_speech(text, wav, truth)
            else:
                tts.synthesize(text, wav)
            units.append(AudioUnit(unit_id=uid, segment_id=seg.segment_id, text=text, wav_path=str(wav),
                                   duration_s=wav_duration(wav)))
    units = assign_timeline(units, pause)
    total = units[-1].end_s + pause
    print(f"{len(segs)} beats, {len(units)} sentences, narration timeline {total:.1f}s")

    llm = None
    if a.llm:
        from src.llm.ollama_client import OllamaClient
        llm = OllamaClient(S.ollama_base_url, S.ollama_model, S.ollama_num_ctx, S.ollama_temperature, max_tokens=400)
        ok, msg = llm.health()
        print("LLM:", msg)
        if not ok:
            llm = None

    mp4 = out / "sync_test.mp4"
    if a.legacy:
        frames = render_frames(segs, units, out / "frames", W, H, "Clean Light")
        assembler.assemble(units, frames, pause, out, mp4, W, H, fps)
        print("legacy video written:", mp4, f"{probe.summarize(probe.probe(mp4))['duration_s']:.2f}s")
        return 0
    plan = sync_runner.plan_sync(segs, units, pause, out, S.tts_voice or "af_heart", S.align_device,
                                 S.align_model_dir, fps, llm, llm is not None, aligner=aligner)
    render_shots(plan.beats, plan.shots, segs, out / "frames", W, H, "Clean Light")
    sync_runner.save_plan(plan, out)
    assembler.assemble_timeline(plan.shots, units, pause, out, mp4, W, H, fps)
    rep = qa_sync.build_sync_report(plan.beats, plan.shots, units, plan.aligns, pause, out / "narration.wav", mp4,
                                    fps, out / "sync", plan.aligner, plan.aligner_message)

    # contact sheet of the frames pulled out of the final MP4
    pics = sorted((out / "sync" / "verify_frames").glob("*_at_change.png"))[:12]
    if pics:
        ims = [Image.open(p).resize((480, 270)) for p in pics]
        cols = 3
        sheet = Image.new("RGB", (cols * 480, math.ceil(len(ims) / cols) * 270), "white")
        for i, im in enumerate(ims):
            sheet.paste(im, ((i % cols) * 480, (i // cols) * 270))
        sheet.save(out / "contact_sheet.png")

    print(("VERIFIED" if rep["sync_verified"] else "NOT VERIFIED"), "| word-level alignment:",
          rep["word_level_alignment_used"], "| aligner:", rep["aligner"])
    for c in rep["checks"]:
        print(("  PASS " if c["passed"] else "  FAIL ") + c["check"] + (f"  [{c['detail']}]" if c["detail"] else ""))
    for w in rep["warnings"]:
        print("  WARN", w)
    print("report:", out / "sync" / "sync_report.md", "\nvideo:", mp4)
    return 0 if rep["sync_verified"] else 1


if __name__ == "__main__":
    sys.exit(main())
