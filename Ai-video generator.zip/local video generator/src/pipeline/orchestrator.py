"""End-to-end pipeline. Each stage persists its artifact so a rerun resumes where it stopped."""
from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from config import Settings
from src.ingestion.chunker import chunk_records
from src.ingestion.coverage import analysis_coverage, extraction_coverage
from src.ingestion.dispatcher import IngestResult, ingest, sanitize_filename
from src.llm.analysis import analyze_chunks, global_summary
from src.llm.base import LLMError, LLMProvider
from src.llm.outline import build_outline, outline_markdown
from src.llm.scriptwriter import assemble_script, count_words, finalize_segment, top_up, write_script
from src.models.schemas import (AudioUnit, Chunk, ChunkAnalysis, Outline, Segment,
                                SourceRecord, VideoMetadata)
from src.pipeline import qa as qa_mod
from src.pipeline.duration import calibrate_wpm, deviation_percent, describe, within_tolerance
from src.storage.jobs import JobStore
from src.tts.audio_utils import wav_duration
from src.tts.base import TTSError, TTSProvider
from src.video import assembler, probe
from src.video.ffmpeg import check_ffmpeg
from src.video.subtitles import assign_timeline, build_srt
from src.sync import qa_sync, runner as sync_runner
from src.visuals.renderer import render_frames, render_shots, split_units

STAGES = ["Validating source", "Extracting content", "Analyzing all source chunks",
          "Building course outline", "Writing and auditing script", "Generating narration",
          "Creating visuals and captions", "Rendering and joining video", "Validating final MP4"]

Progress = Callable[[int, float, str], None]  # (stage_index, fraction 0-1, detail)


class PipelineError(Exception):
    pass


@dataclass
class CourseRequest:
    minutes: int
    mode: str = "source"  # "source" | "expanded"
    audience: str = "general adult learners"
    title: str = ""
    theme: str = "Clean Light"
    low_res: bool = False


def _logger(job_dir: Path) -> logging.Logger:
    lg = logging.getLogger(f"job.{job_dir.name}")
    if not lg.handlers:
        h = logging.FileHandler(job_dir / "job.log", encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        lg.addHandler(h)
        lg.setLevel(logging.INFO)
    return lg


def _save(path: Path, obj) -> None:
    path.write_text(json.dumps(obj, indent=2, default=str), encoding="utf-8")


# ---------------- Stage 1-2a: ingest -----------------
def analyze_source(store: JobStore, job_id: str, upload: Path, s: Settings) -> dict:
    job_dir = store.job_dir(job_id)
    lg = _logger(job_dir)
    res: IngestResult = ingest(upload, s.max_upload_mb)
    records = res.records
    chunks = chunk_records(records, max_chars=max(1500, s.ollama_num_ctx))
    cov = extraction_coverage(records)
    (job_dir / "source_records.json").write_text(
        json.dumps([r.model_dump() for r in records], indent=2), encoding="utf-8")
    (job_dir / "chunks.json").write_text(
        json.dumps([c.model_dump() for c in chunks], indent=2), encoding="utf-8")
    _save(job_dir / "extraction_coverage.json", cov)
    text = "\n\n".join(f"[{r.source_id}]\n{r.text}" for r in records if r.text)
    (job_dir / "extracted_text.txt").write_text(text, encoding="utf-8")
    words = sum(len(r.text.split()) for r in records)
    summary = {"kind": res.kind, "filename": sanitize_filename(res.original_name),
               "sha256": res.sha256, "size_bytes": res.size_bytes, "records": len(records),
               "chunks": len(chunks), "chars": sum(len(r.text) for r in records), "words": words,
               "warnings": res.warnings, "coverage_complete": cov["complete"]}
    store.update(job_id, source=summary, status="analyzed_source")
    lg.info("Source ingested: %s", summary)
    return summary


# ---------------- Stages 2b-9 -----------------
def _load_records(job_dir: Path) -> list[SourceRecord]:
    return [SourceRecord(**r) for r in json.loads((job_dir / "source_records.json").read_text(encoding="utf-8"))]


def _synth_missing(segments: list[Segment], tts: TTSProvider, audio_dir: Path,
                   cb: Optional[Callable[[int, int, str], None]] = None) -> tuple[list[AudioUnit], list[str]]:
    audio_dir.mkdir(parents=True, exist_ok=True)
    plan = [(seg, i, t) for seg in segments for i, t in enumerate(split_units(seg.narration_text), 1)]
    units: list[AudioUnit] = []
    failed: list[str] = []
    for n, (seg, i, text) in enumerate(plan, 1):
        uid = f"{seg.segment_id}-U{i:02d}"
        wav = audio_dir / f"{uid}.wav"
        txt = audio_dir / f"{uid}.txt"
        cached = wav.exists() and txt.exists() and txt.read_text(encoding="utf-8") == text
        if not cached:
            try:
                tts.synthesize(text, wav)
                txt.write_text(text, encoding="utf-8")
            except TTSError as e:
                failed.append(f"{uid}: {e}")
                continue
        units.append(AudioUnit(unit_id=uid, segment_id=seg.segment_id, text=text,
                               wav_path=str(wav), duration_s=wav_duration(wav)))
        if cb:
            cb(n, len(plan), seg.visual_title or seg.segment_id)
    return units, failed


def _calibrated_wpm(job_dir: Path, tts: TTSProvider, s: Settings, lg) -> float:
    """Speaking rate of the selected voice (cached per voice); falls back to the configured rate."""
    f = job_dir / "calibration.json"
    key = f"{tts.name}/{tts.voice}"
    try:
        if f.exists():
            d = json.loads(f.read_text(encoding="utf-8"))
            if d.get("voice") == key:
                return float(d["wpm"])
        wpm, info = calibrate_wpm(tts, job_dir / "calibration", s.pause_between_units_s)
        f.write_text(json.dumps({**info, "voice": key}), encoding="utf-8")
        lg.info("Voice calibration for %s: %.1f words/min", key, wpm)
        return wpm
    except (TTSError, OSError, ValueError) as e:
        lg.warning("Voice calibration failed (%s); using configured %d wpm", e, s.words_per_minute)
        return float(s.words_per_minute)


def _bookend_segments(outline: Outline) -> tuple[Segment, Segment]:
    intro = Segment(segment_id="M0-S001", module_id="M0", segment_type="intro", visual_type="title",
                    narration_text=f"Welcome. In this course, we will cover {outline.title}.",
                    visual_title=outline.title, on_screen_text=[outline.audience])
    outro = Segment(segment_id="MZ-S001", module_id="MZ", segment_type="outro", visual_type="closing",
                    narration_text="That completes the course. Review the key points to reinforce what you learned.",
                    visual_title="Summary", on_screen_text=[o for o in outline.objectives[:1]])
    return intro, outro


def generate_video(store: JobStore, job_id: str, req: CourseRequest, s: Settings, llm: LLMProvider,
                   tts: TTSProvider, progress: Optional[Progress] = None) -> dict:
    job_dir = store.job_dir(job_id)
    lg = _logger(job_dir)
    t0 = time.time()
    if hasattr(llm, "on_call"):
        llm.on_call = lg.info  # per-call timing and tokens/s go to job.log

    last_save = [0.0]

    def P(stage: int, frac: float, detail: str = ""):
        now = time.time()
        if frac >= 1.0 or now - last_save[0] >= 1.0:  # throttle disk writes
            last_save[0] = now
            store.update(job_id, current_stage=STAGES[stage], stage_index=stage, stage_fraction=frac,
                         stage_detail=detail, elapsed_s=now - t0)
        if progress:
            progress(stage, frac, detail)

    if not store.acquire_lock(job_id):
        raise PipelineError("Another generation job is already running.")
    stage = 0
    cg = logging.getLogger("coursegen")  # script-stage diagnostics go to this job's log
    cg.setLevel(logging.INFO)
    for h in lg.handlers:
        cg.addHandler(h)
    try:
        ok, msg = check_ffmpeg()
        if not ok:
            raise PipelineError(msg)
        ok, msg = llm.health()
        if not ok:
            raise PipelineError(msg)
        ok, msg = tts.availability()
        if not ok:
            raise PipelineError(msg)
        store.update(job_id, status="running", request=req.__dict__)

        # Stage 0-1 already done by analyze_source
        P(0, 1.0, "Source validated")
        records = _load_records(job_dir)
        P(1, 1.0, f"{len(records)} source records")
        chunks = [Chunk(**c) for c in json.loads((job_dir / "chunks.json").read_text(encoding="utf-8"))]
        valid_ids = {r.source_id for r in records if r.status == "processed"}
        ext_cov = json.loads((job_dir / "extraction_coverage.json").read_text(encoding="utf-8"))

        # Stage 2: analysis
        stage = 2
        analyses = analyze_chunks(chunks, llm, job_dir / "analysis",
                                  lambda i, n, c: P(2, i / n, f"chunk {c} ({i}/{n})"))
        an_cov = analysis_coverage(chunks, analyses)
        _save(job_dir / "analysis_coverage.json", an_cov)
        if an_cov["failed"] or an_cov["missing"]:
            raise PipelineError(f"Analysis incomplete (failed: {an_cov['failed']}). "
                                "Fix the issue and retry; completed chunks are kept.")
        summary_f = job_dir / "global_summary.txt"
        if not summary_f.exists():
            summary_f.write_text(global_summary(analyses, llm), encoding="utf-8")
        summary = summary_f.read_text(encoding="utf-8")

        # Calibrate the narration rate with the selected voice (word budgets use the real speaking rate)
        wpm = _calibrated_wpm(job_dir, tts, s, lg)

        # Stage 3: outline
        stage = 3
        P(3, 0.0, "Planning modules")
        out_f = job_dir / "outline.json"
        if out_f.exists():
            outline = Outline.model_validate_json(out_f.read_text(encoding="utf-8"))
        else:
            outline = build_outline(analyses, summary, llm, req.minutes, wpm, req.title,
                                    req.audience, req.mode, sorted(valid_ids), 40, note=lg.warning,
                                    debug_dir=job_dir / "debug")
            out_f.write_text(outline.model_dump_json(indent=2), encoding="utf-8")
            (job_dir / "outline.md").write_text(outline_markdown(outline), encoding="utf-8")
        P(3, 1.0, outline.title)

        # Stage 4: source-aware script (units are cached; finished units are never redone)
        stage = 4
        target_s = req.minutes * 60.0
        tol = s.duration_tolerance_percent
        intro, outro = _bookend_segments(outline)
        finalize_segment(intro, wpm)
        finalize_segment(outro, wpm)
        body_words = max(60, int(req.minutes * wpm) - intro.word_count - outro.word_count)
        units_dir = job_dir / "script_units"
        body, warnings, script_report = write_script(
            outline, analyses, llm, req.mode, wpm, valid_ids, body_words,
            lambda i, n, t: P(4, i / n, f"part {i}/{n}: {t}"),
            cache_dir=units_dir, debug_dir=job_dir / "debug", chunks=chunks)
        segments = [intro] + body + [outro]
        lg.info("Script: %s words planned for %s, capacity %s words", script_report["actual_words"],
                body_words, script_report["capacity_words"])

        # Stage 5: narration with measured duration; bounded, source-aware top-ups if too short
        stage = 5
        pause = s.pause_between_units_s
        failed: list[str] = []
        units: list[AudioUnit] = []
        exhausted = ""
        total_s = 0.0
        for rnd in range(4):
            units, failed = _synth_missing(segments, tts, job_dir / "audio",
                                           lambda i, n, t: P(5, i / n, f"{t} ({i}/{n})"))
            if failed:
                raise PipelineError("TTS failed for: " + "; ".join(failed[:3]) +
                                    ". Completed audio is kept; retry to redo only failed units.")
            units = assign_timeline(units, pause)
            total_s = (units[-1].end_s + pause) if units else 0.0
            if within_tolerance(total_s, target_s, tol) or total_s > target_s or rnd == 3:
                break
            words_now = sum(x.word_count for x in segments)
            need = int(0.95 * (target_s - total_s) / (total_s / max(1, words_now)))
            if need < 10:
                break
            added, spare = top_up(units_dir, need, llm, req.mode, wpm, debug_dir=job_dir / "debug")
            lg.info("Top-up round %d: needed %d words, added %d (spare capacity %d)", rnd + 1, need, added, spare)
            if added < 10:
                exhausted = ("the source material is used up (no unused capacity left)" if spare < need * 0.5
                             else "the model could not produce new, non-duplicate narration for the "
                                  "remaining source passages")
                break
            body, dups = assemble_script(outline, units_dir)
            segments = [intro] + [finalize_segment(x, wpm) for x in body] + [outro]
        # fine-tune the pause between caption units (audio timing only, kept within natural limits)
        if units and len(units) > 1 and not within_tolerance(total_s, target_s, tol):
            new_pause = min(0.6, max(0.15, pause + (target_s - total_s) / len(units)))
            units = assign_timeline(units, new_pause)
            t2 = units[-1].end_s + new_pause
            if abs(t2 - target_s) < abs(total_s - target_s):
                pause, total_s = new_pause, t2
                warnings.append(f"Pause between caption units adjusted to {pause:.2f}s to fit the duration.")
            else:
                units = assign_timeline(units, pause)
        real_total = total_s
        dur_msg = describe(real_total, target_s, tol)
        cause = ""
        if not within_tolerance(real_total, target_s, tol):
            if real_total < target_s:
                cause = (f"The video is shorter than requested because {exhausted or 'the script reached the maximum number of expansion rounds'}. "
                         f"Estimated source-grounded capacity: about {script_report['capacity_words']} words "
                         f"(~{script_report['capacity_minutes']} min of narration).")
            else:
                cause = "The script is longer than the target. No source material was removed to force a fit."
            warnings = warnings + [dur_msg + " " + cause]
        script_report["wpm_used"] = round(wpm, 1)
        script_report["final_words"] = sum(x.word_count for x in segments)
        _save(job_dir / "script_report.json", script_report)
        _save(job_dir / "script.json", {"segments": [x.model_dump() for x in segments], "warnings": warnings})
        (job_dir / "script.md").write_text(
            "\n\n".join(f"**{x.segment_id}** ({x.segment_type}; sources: {', '.join(x.source_ids) or 'n/a'})\n{x.narration_text}"
                        for x in segments), encoding="utf-8")
        _save(job_dir / "audio_manifest.json", [u.model_dump() for u in units])
        (job_dir / "captions.srt").write_text(build_srt(units), encoding="utf-8")

        stage = 6
        W, H = (s.fallback_video_width, s.fallback_video_height) if req.low_res else (s.video_width, s.video_height)
        out_mp4 = job_dir / "course_video.mp4"
        plan = None
        if s.sync_enabled:
            # Narration-led timeline: real clip lengths + WhisperX word times decide every picture change.
            units = assign_timeline(units, pause)  # same sample-exact timeline the audio track is built from
            plan = sync_runner.plan_sync(
                segments, units, pause, job_dir, tts.voice, s.align_device, s.align_model_dir, s.video_fps,
                llm, s.sync_use_llm_cues, progress=lambda f, d: P(6, 0.5 * f, d))
            render_shots(plan.beats, plan.shots, segments, job_dir / "frames", W, H, req.theme,
                         lambda i, n, t: P(6, 0.5 + 0.5 * i / n, f"{t} ({i}/{n})"))
            sync_runner.save_plan(plan, job_dir)
            frames = {}
            for u in units:
                sh = next((x for x in plan.shots if x.start_s <= u.start_s + 1e-6 < x.end_s), None)
                if sh:
                    frames[u.unit_id] = Path(sh.frame_path)
            stage = 7
            assembler.assemble_timeline(plan.shots, units, pause, job_dir, out_mp4, W, H, s.video_fps,
                                        lambda i, n, t: P(7, i / n, t))
        else:  # legacy per-segment path (known to drift on long videos)
            frames = render_frames(segments, units, job_dir / "frames", W, H, req.theme,
                                   lambda i, n, t: P(6, i / n, f"{t} ({i}/{n})"))
            stage = 7
            assembler.assemble(units, frames, pause, job_dir, out_mp4, W, H, s.video_fps,
                               lambda i, n, t: P(7, i / n, f"segment {i}/{n}"))
        stage = 8
        P(8, 0.5, "Probing final MP4")
        psum, problems = probe.validate_mp4(out_mp4, W, H)
        if problems:
            raise PipelineError("Final MP4 failed validation: " + "; ".join(problems))
        actual = psum["duration_s"]
        meta = VideoMetadata(
            target_duration_s=target_s, actual_duration_s=actual, width=psum["width"],
            height=psum["height"], fps=psum["fps"], video_codec=psum["video_codec"],
            audio_codec=psum["audio_codec"], has_audio=psum["has_audio"], has_video=psum["has_video"],
            subtitle_file="captions.srt", source_sha256=store.load(job_id).get("source", {}).get("sha256", ""),
            llm_model=getattr(llm, "model", "unknown"), tts_backend=tts.name, tts_voice=tts.voice,
            within_tolerance=within_tolerance(actual, target_s, s.duration_tolerance_percent),
            deviation_percent=deviation_percent(actual, target_s))
        (job_dir / "video_metadata.json").write_text(meta.model_dump_json(indent=2), encoding="utf-8")
        qa = qa_mod.build_qa(ext_cov, an_cov, warnings, segments, units, failed, frames, psum, problems,
                             target_s, s.duration_tolerance_percent, script_report=script_report,
                             valid_ids=valid_ids, cause=cause)
        sync_rep = None
        if plan is not None:
            P(8, 0.7, "Verifying picture/narration sync in the final MP4")
            sync_rep = qa_sync.build_sync_report(
                plan.beats, plan.shots, units, plan.aligns, pause, job_dir / "narration.wav", out_mp4,
                s.video_fps, job_dir / "sync", plan.aligner, plan.aligner_message)
            qa["checks"] += [{"check": "Sync: " + c["check"], "passed": c["passed"], "detail": c["detail"]}
                             for c in sync_rep["checks"]]
            qa["checks"].append({"check": "Sync: word-level alignment used", "passed": sync_rep["word_level_alignment_used"],
                                 "detail": plan.aligner_message if not sync_rep["word_level_alignment_used"] else plan.aligner})
            qa["all_passed"] = all(c["passed"] for c in qa["checks"])
            warnings = warnings + sync_rep["warnings"][:10]
            lg.info("Sync verified=%s word_level=%s", sync_rep["sync_verified"], sync_rep["word_level_alignment_used"])
        qa_mod.save_qa(qa, job_dir)
        if not s.keep_intermediates:
            import shutil
            for d in ("frames", "clips", "audio"):
                shutil.rmtree(job_dir / d, ignore_errors=True)
        P(8, 1.0, "Done")
        ok_final = meta.within_tolerance
        store.update(job_id, status="complete" if ok_final else "complete_out_of_tolerance",
                     result={"duration_statement": qa["duration_statement"],
                             "within_tolerance": meta.within_tolerance, "cause": cause,
                             "capacity_minutes": script_report["capacity_minutes"],
                             "sync_verified": bool(sync_rep and sync_rep["sync_verified"]),
                             "word_level_alignment": bool(sync_rep and sync_rep["word_level_alignment_used"]),
                             "warnings": warnings})
        lg.info("Job complete: %s", qa["duration_statement"])
        return meta.model_dump()
    except (PipelineError, LLMError, TTSError, RuntimeError, OSError, ValueError) as e:
        lg.exception("Pipeline failed at stage %s", STAGES[min(stage, 8)])
        store.update(job_id, status="failed", error=str(e), failed_stage=STAGES[min(stage, 8)])
        raise PipelineError(str(e)) from e
    finally:
        for h in list(cg.handlers):
            cg.removeHandler(h)
        store.release_lock()
