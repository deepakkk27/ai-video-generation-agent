"""Automated QA report (JSON + Markdown). Automated checks do not prove correctness."""
from __future__ import annotations

import json
from pathlib import Path

from src.models.schemas import AudioUnit, Segment
from src.pipeline.duration import describe
from src.video.subtitles import validate_timeline


def build_qa(extraction_cov: dict, analysis_cov: dict, script_warnings: list[str],
             segments: list[Segment], units: list[AudioUnit], failed_units: list[str],
             frames: dict, probe_summary: dict, probe_problems: list[str],
             target_s: float, tol: float, script_report: dict | None = None,
             valid_ids: set | None = None, cause: str = "") -> dict:
    from src.llm.scriptwriter import near_duplicate
    checks = []

    def add(name, ok, detail=""):
        checks.append({"check": name, "passed": bool(ok), "detail": detail})

    add("Extraction coverage complete", extraction_cov.get("complete"),
        f"failed={extraction_cov.get('failed')} skipped={extraction_cov.get('skipped')}")
    add("All chunks analyzed", analysis_cov.get("complete"),
        f"failed={analysis_cov.get('failed')} missing={analysis_cov.get('missing')}")
    add("No source-traceability warnings", not script_warnings, "; ".join(script_warnings[:10]))
    if script_report is not None:
        tw, aw = script_report.get("target_words", 0), script_report.get("final_words", 0)
        add("Script length matches the plan", aw >= 0.97 * tw if tw else True,
            f"{aw} words in script vs {tw} planned (capacity {script_report.get('capacity_words')} words)")
        short = [u["unit"] for u in script_report.get("units", [])
                 if u["words"] < 0.7 * u["target"] and u["words"] < u["cap"] * 0.95]
        add("Every script unit reached its word target", not short, f"short units: {short[:6]}")
    body = [x for x in segments if x.segment_type not in ("intro", "outro")]
    dup = [(a.segment_id, b.segment_id) for i, a in enumerate(body) for b in body[i + 1:]
           if near_duplicate(a.narration_text, b.narration_text)]
    add("No duplicate narration", not dup, f"duplicate pairs: {dup[:5]}")
    if valid_ids:
        used = {i for x in segments for i in x.source_ids} | set((script_report or {}).get("covered_source_ids", []))
        cov = len(used & valid_ids) / len(valid_ids)
        add("Source coverage in script (>=90% of source records narrated)", cov >= 0.9,
            f"{cov * 100:.0f}% of {len(valid_ids)} source records narrated")
    add("Every segment cites a source", all(x.source_ids for x in body), "")
    add("No failed TTS clips", not failed_units, f"failed={failed_units}")
    missing_vis = [u.unit_id for u in units if u.unit_id not in frames or not Path(frames[u.unit_id]).exists()]
    add("All visuals present", not missing_vis, f"missing={missing_vis[:5]}")
    tl = validate_timeline(units)
    add("Subtitle timeline valid", not tl, "; ".join(tl[:5]))
    long_caps = [u.unit_id for u in units if len(u.text.split()) > 25]
    add("Captions readable length", not long_caps, f"long={long_caps[:5]}")
    add("Final MP4 streams valid", not probe_problems, "; ".join(probe_problems))
    actual = probe_summary.get("duration_s", 0)
    dur_msg = describe(actual, target_s, tol) if actual else "no measured duration"
    add("Duration within tolerance", actual and abs(actual - target_s) / target_s * 100 <= tol, dur_msg)
    return {"checks": checks, "all_passed": all(c["passed"] for c in checks),
            "duration_statement": dur_msg, "cause": cause,
            "note": "Automated checks only. They do not verify educational correctness; human review is required."}


def qa_markdown(qa: dict) -> str:
    lines = ["# QA Report", "", f"**{qa['duration_statement']}**", ""]
    if qa.get("cause"):
        lines += [f"**Cause:** {qa['cause']}", ""]
    for c in qa["checks"]:
        lines.append(f"- [{'x' if c['passed'] else ' '}] {c['check']}" + (f" — {c['detail']}" if c["detail"] else ""))
    lines += ["", f"_{qa['note']}_", ""]
    return "\n".join(lines)


def save_qa(qa: dict, out_dir: Path) -> None:
    (out_dir / "qa_report.json").write_text(json.dumps(qa, indent=2), encoding="utf-8")
    (out_dir / "qa_report.md").write_text(qa_markdown(qa), encoding="utf-8")
