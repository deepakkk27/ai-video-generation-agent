"""Duration planning and measurement."""
from __future__ import annotations


def target_word_count(minutes: float, wpm: int = 130) -> int:
    return int(round(minutes * wpm))


def estimate_seconds(words: int, wpm: int = 130) -> float:
    return words / wpm * 60.0


def deviation_percent(actual_s: float, target_s: float) -> float:
    return (actual_s - target_s) / target_s * 100.0 if target_s > 0 else 0.0


def within_tolerance(actual_s: float, target_s: float, tol_percent: float) -> bool:
    return abs(deviation_percent(actual_s, target_s)) <= tol_percent


def describe(actual_s: float, target_s: float, tol_percent: float) -> str:
    dev = deviation_percent(actual_s, target_s)
    a, t = actual_s / 60, target_s / 60
    if within_tolerance(actual_s, target_s, tol_percent):
        return f"Measured {a:.1f} min vs target {t:.1f} min ({dev:+.1f}%), within {tol_percent:g}% tolerance."
    word = "longer" if dev > 0 else "shorter"
    return (f"Measured {a:.1f} min vs target {t:.1f} min: {abs(dev):.1f}% {word}, outside the "
            f"{tol_percent:g}% tolerance.")


CAL_TEXT = ("Learning is most effective when ideas are introduced clearly, explained step by step, and "
            "connected to examples. In this lesson, we will define the key terms, walk through the main "
            "procedure, and review the results so that each concept is easy to remember and apply.")


def calibrate_wpm(tts, work_dir, pause_s: float) -> tuple[float, dict]:
    """Measure the selected voice's real speaking rate (including the pause between caption units)."""
    from pathlib import Path

    from src.tts.audio_utils import wav_duration
    from src.visuals.renderer import split_units

    work = Path(work_dir)
    work.mkdir(parents=True, exist_ok=True)
    units = split_units(CAL_TEXT, 20)
    speech = 0.0
    for i, u in enumerate(units):
        wav = work / f"cal{i}.wav"
        tts.synthesize(u, wav)
        speech += wav_duration(wav)
    words = len(CAL_TEXT.split())
    seconds = speech + pause_s * len(units)
    wpm = max(90.0, min(200.0, words / (seconds / 60.0)))
    return wpm, {"wpm": round(wpm, 1), "speech_s": round(speech, 2), "words": words,
                 "units": len(units), "pause_s": pause_s}
