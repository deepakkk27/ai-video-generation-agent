"""Pydantic schemas shared across the pipeline. All LLM output is validated here."""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field, field_validator

ALLOWED_VISUALS = (
    "title", "divider", "definition", "bullets", "flow", "steps",
    "comparison", "timeline", "chart", "example", "question", "recap", "closing",
)
VisualType = Literal[
    "title", "divider", "definition", "bullets", "flow", "steps",
    "comparison", "timeline", "chart", "example", "question", "recap", "closing",
]
SegmentType = Literal[
    "explanation", "example", "analogy", "recap", "question", "transition", "intro", "outro",
]


_SEGMENT_TYPES = ("explanation", "example", "analogy", "recap", "question", "transition", "intro", "outro")


class SourceRecord(BaseModel):
    source_id: str
    kind: str  # pdf | pptx | docx | txt | md | srt | vtt
    index: int
    raw_text: str = ""
    text: str = ""
    status: Literal["processed", "skipped", "failed"] = "processed"
    note: str = ""
    start_s: Optional[float] = None
    end_s: Optional[float] = None
    heading: bool = False


class Chunk(BaseModel):
    chunk_id: str
    source_ids: list[str]
    text: str


class ChunkAnalysis(BaseModel):
    chunk_id: str = ""
    source_ids: list[str] = Field(default_factory=list)
    summary: str = ""
    main_ideas: list[str] = Field(default_factory=list)
    terms: list[str] = Field(default_factory=list)
    facts: list[str] = Field(default_factory=list)
    examples: list[str] = Field(default_factory=list)
    dependencies: list[str] = Field(default_factory=list)
    must_keep: list[str] = Field(default_factory=list)
    ambiguities: list[str] = Field(default_factory=list)
    status: Literal["analyzed", "failed"] = "analyzed"
    error: str = ""


class Module(BaseModel):
    module_id: str
    title: str
    objectives: list[str] = Field(default_factory=list)
    subtopics: list[str] = Field(default_factory=list)
    source_ids: list[str] = Field(default_factory=list)
    word_budget: int = 0
    recap_points: list[str] = Field(default_factory=list)


class Outline(BaseModel):
    title: str
    audience: str = "general adult learners"
    objectives: list[str] = Field(default_factory=list)
    prerequisites: list[str] = Field(default_factory=list)
    modules: list[Module]
    excluded_source_notes: list[str] = Field(default_factory=list)

    @field_validator("modules")
    @classmethod
    def _need_modules(cls, v):
        if not v:
            raise ValueError("outline needs at least one module")
        return v


class Segment(BaseModel):
    segment_id: str
    module_id: str
    narration_text: str
    source_ids: list[str] = Field(default_factory=list)
    segment_type: SegmentType = "explanation"
    visual_type: VisualType = "bullets"
    visual_title: str = ""
    on_screen_text: list[str] = Field(default_factory=list)
    diagram_data: Optional[dict] = None
    chart_data: Optional[dict] = None
    caption_text: str = ""
    illustrative: bool = False
    needs_verification: bool = False
    word_count: int = 0
    est_duration_s: float = 0.0

    @field_validator("segment_type", mode="before")
    @classmethod
    def _coerce_segment_type(cls, v):
        # Small models often put a visual name here; fall back to a safe default.
        v = str(v or "").strip().lower()
        return v if v in _SEGMENT_TYPES else "explanation"

    @field_validator("visual_type", mode="before")
    @classmethod
    def _coerce_visual_type(cls, v):
        # Only known template types may reach the renderer; anything else becomes bullets.
        v = str(v or "").strip().lower()
        return v if v in ALLOWED_VISUALS else "bullets"

    @field_validator("narration_text")
    @classmethod
    def _nonempty(cls, v):
        if not v.strip():
            raise ValueError("narration_text is empty")
        return v.strip()


class ModuleScript(BaseModel):
    segments: list[Segment]


class AudioUnit(BaseModel):
    unit_id: str
    segment_id: str
    text: str
    wav_path: str
    duration_s: float
    start_s: float = 0.0
    end_s: float = 0.0


class AlignedWord(BaseModel):
    """One narrated word. start/end are None when the aligner could not place it (never invented)."""
    word: str
    start: Optional[float] = None   # seconds, relative to the start of its audio clip
    end: Optional[float] = None
    score: Optional[float] = None
    aligned: bool = False


class UnitAlignment(BaseModel):
    unit_id: str
    status: str = "ok"              # ok | partial | failed | unavailable
    note: str = ""
    aligner: str = ""
    words: list[AlignedWord] = Field(default_factory=list)


class ItemCue(BaseModel):
    """When one on-screen item appears. time_s is on the global timeline."""
    index: int
    text: str
    time_s: float = 0.0
    method: str = "unit_fallback"   # llm | lexical | unit_fallback  (+ '_unit' when only sentence-level)
    anchor_word: str = ""
    unit_id: str = ""
    warning: str = ""


class Shot(BaseModel):
    """A span of the final video during which the picture does not change."""
    shot_id: str
    beat_id: str
    unit_id: str
    caption: str
    revealed: int = 0
    start_s: float = 0.0
    end_s: float = 0.0
    start_frame: int = 0
    end_frame: int = 0
    trigger: str = "unit_start"     # segment_start | unit_start | item_cue
    frame_path: str = ""


class Beat(BaseModel):
    """One synchronized narration/visual unit: what is said, what is shown, when (measured)."""
    beat_id: str
    segment_id: str
    module_id: str = ""
    narration_text: str
    source_ids: list[str] = Field(default_factory=list)
    visual_type: str = "bullets"
    visual_title: str = ""
    items: list[str] = Field(default_factory=list)      # final on-screen items, in reveal order
    cues: list[ItemCue] = Field(default_factory=list)
    visual_description: str = ""
    visual_asset: str = ""                               # first frame of the beat
    audio_files: list[str] = Field(default_factory=list)
    unit_ids: list[str] = Field(default_factory=list)
    audio_duration_s: float = 0.0                        # sum of the real clip durations
    start_s: float = 0.0
    end_s: float = 0.0                                   # = start of the next beat's narration
    alignment_status: str = "unavailable"
    llm_grounded: bool = False
    warnings: list[str] = Field(default_factory=list)


class VideoMetadata(BaseModel):
    target_duration_s: float
    actual_duration_s: float
    width: int
    height: int
    fps: float
    video_codec: str
    audio_codec: str
    has_audio: bool
    has_video: bool
    subtitle_file: str
    source_sha256: str
    llm_model: str
    tts_backend: str
    tts_voice: str
    within_tolerance: bool
    deviation_percent: float
