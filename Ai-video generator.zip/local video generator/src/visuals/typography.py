"""Font loading, wrapping and fit-to-box with a minimum size."""
from __future__ import annotations

from functools import lru_cache

from PIL import ImageDraw, ImageFont

_CANDIDATES = ["segoeui.ttf", "arial.ttf", "DejaVuSans.ttf", "LiberationSans-Regular.ttf",
               "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]
_BOLD = ["segoeuib.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf", "LiberationSans-Bold.ttf",
         "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"]


class TextOverflow(Exception):
    pass


@lru_cache(maxsize=64)
def font(size: int, bold: bool = False):
    for name in (_BOLD if bold else _CANDIDATES):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default(size)


def wrap(draw: ImageDraw.ImageDraw, text: str, fnt, max_w: int) -> list[str]:
    words, lines, cur = text.split(), [], ""
    for w in words:
        t = f"{cur} {w}".strip()
        if draw.textlength(t, font=fnt) <= max_w or not cur:
            cur = t
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def fit(draw, text: str, max_w: int, max_h: int, start: int, min_size: int = 22,
        bold: bool = False, line_gap: float = 1.25, max_lines: int | None = None):
    """Return (font, lines, line_height) fitting the box; raise TextOverflow if impossible."""
    min_size = min(min_size, start)  # small frames: never let the minimum exceed the start size
    size = start
    while size >= min_size:
        f = font(size, bold)
        lines = wrap(draw, text, f, max_w)
        lh = int(size * line_gap)
        if len(lines) * lh <= max_h and (max_lines is None or len(lines) <= max_lines):
            return f, lines, lh
        size -= 2
    raise TextOverflow(f"text does not fit at min size {min_size}: {text[:40]!r}")
