"""Render one PNG per narration unit (content + burned-in caption) to disk."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Callable, Optional

import hashlib
import json

from src.models.schemas import AudioUnit, Beat, Segment, Shot
from src.visuals.templates import draw_caption, render_content
from src.visuals.theme import get_theme
from src.visuals.typography import TextOverflow


def split_units(text: str, max_words: int = 20) -> list[str]:
    """Caption-sized units: sentences, long ones split at commas/semicolons or by word count."""
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s.strip()]
    units: list[str] = []
    for s in sentences:
        if len(s.split()) <= max_words:
            units.append(s)
            continue
        parts = [p.strip() for p in re.split(r"(?<=[,;:])\s+", s) if p.strip()]
        cur = ""
        for p in parts:
            if cur and len((cur + " " + p).split()) > max_words:
                units.append(cur)
                cur = p
            else:
                cur = f"{cur} {p}".strip()
        if cur:
            units.append(cur)
    out: list[str] = []
    for u in units:  # hard split anything still too long
        w = u.split()
        for i in range(0, len(w), max_words):
            out.append(" ".join(w[i:i + max_words]))
    return out


def render_frames(segments: list[Segment], units: list[AudioUnit], frames_dir: Path,
                  width: int, height: int, theme_name: str,
                  progress: Optional[Callable[[int, int, str], None]] = None) -> dict[str, Path]:
    """Returns {unit_id: png_path}. Deterministic. Raises on missing/overflowing visuals."""
    frames_dir = Path(frames_dir)
    frames_dir.mkdir(parents=True, exist_ok=True)
    th = get_theme(theme_name)
    seg_by_id = {s.segment_id: s for s in segments}
    by_seg: dict[str, list[AudioUnit]] = {}
    for u in units:
        by_seg.setdefault(u.segment_id, []).append(u)
    paths: dict[str, Path] = {}
    done = 0
    for sid, seg_units in by_seg.items():
        seg = seg_by_id[sid]
        sd = seg.model_dump()
        n_items = max(1, len([t for t in seg.on_screen_text if t.strip()]))
        for i, u in enumerate(seg_units):
            revealed = max(1, round((i + 1) / len(seg_units) * n_items))
            out = frames_dir / f"{u.unit_id}.png"
            try:
                img = render_content(sd, width, height, th, revealed)
                img = draw_caption(img, u.text, th)
            except TextOverflow:
                sd2 = dict(sd, on_screen_text=[t[:40] for t in seg.on_screen_text[:3]],
                           visual_title=seg.visual_title[:60])
                img = draw_caption(render_content(sd2, width, height, th, revealed), u.text[:140], th)
            img.save(out, "PNG")
            paths[u.unit_id] = out
            done += 1
        if progress:
            progress(done, len(units), seg.visual_title or sid)
    missing = [u.unit_id for u in units if not paths.get(u.unit_id) or not paths[u.unit_id].exists()]
    if missing:
        raise RuntimeError(f"Missing visuals for units: {missing[:5]}")
    return paths


def render_shots(beats: list[Beat], shots: list[Shot], segments: list[Segment], frames_dir: Path,
                 width: int, height: int, theme_name: str,
                 progress: Optional[Callable[[int, int, str], None]] = None) -> dict[str, Path]:
    """One PNG per shot (picture state + caption). Returns {shot_id: png}. Content-addressed, so reruns
    and identical states reuse files. Sets shot.frame_path and beat.visual_asset."""
    frames_dir = Path(frames_dir)
    frames_dir.mkdir(parents=True, exist_ok=True)
    th = get_theme(theme_name)
    seg_by_id = {s.segment_id: s for s in segments}
    beat_by_id = {b.beat_id: b for b in beats}
    paths: dict[str, Path] = {}
    for n, sh in enumerate(shots, 1):
        beat = beat_by_id[sh.beat_id]
        seg = seg_by_id[beat.segment_id]
        sd = seg.model_dump()
        if not ((seg.diagram_data or {}).get("steps") and seg.visual_type == "flow") and \
                not ((seg.chart_data or {}).get("labels") and seg.visual_type == "chart"):
            sd["on_screen_text"] = list(beat.items)       # the items whose reveal times were scheduled
        key = hashlib.sha1(json.dumps([sd, sh.revealed, sh.caption, width, height, th.name, "v2"],
                                      sort_keys=True, default=str).encode()).hexdigest()[:16]
        out = frames_dir / f"{key}.png"
        if not out.exists():
            try:
                img = draw_caption(render_content(sd, width, height, th, sh.revealed), sh.caption, th)
            except TextOverflow:
                sd2 = dict(sd, on_screen_text=[t[:40] for t in sd["on_screen_text"][:3]],
                           visual_title=(seg.visual_title or "")[:60])
                img = draw_caption(render_content(sd2, width, height, th, sh.revealed), sh.caption[:140], th)
            img.save(out, "PNG")
        sh.frame_path = str(out)
        paths[sh.shot_id] = out
        if not beat.visual_asset:
            beat.visual_asset = str(out)
        if progress and (n % 10 == 0 or n == len(shots)):
            progress(n, len(shots), seg.visual_title or seg.segment_id)
    missing = [k for k, v in paths.items() if not v.exists()]
    if missing:
        raise RuntimeError(f"Missing visuals for shots: {missing[:5]}")
    return paths
