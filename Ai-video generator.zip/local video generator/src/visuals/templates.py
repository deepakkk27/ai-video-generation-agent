"""Deterministic Pillow scene templates. Each draws the *content area* only; captions are
drawn separately so they can change while the visual stays."""
from __future__ import annotations

from PIL import Image, ImageDraw

from src.visuals.theme import Theme
from src.visuals.typography import TextOverflow, fit, font


def _title(d, W, H, th, text, y=None):
    f, lines, lh = fit(d, text or " ", W - 240, 150, int(H * 0.06), min_size=30, bold=True, max_lines=2)
    y = int(H * 0.07) if y is None else y
    for ln in lines:
        d.text((120, y), ln, font=f, fill=th.text)
        y += lh
    d.rectangle([120, y + 6, 320, y + 12], fill=th.accent)
    return y + 40


def _bullet_rows(d, W, H, th, items, y, revealed, numbered=False):
    area_h = int(H * 0.68) - y
    n = max(1, len(items))
    per = area_h // n
    f, _, _ = fit(d, max(items, key=len) if items else " ", W - 420, per, int(H * 0.042), min_size=24)
    for i, it in enumerate(items):
        if i >= revealed:
            break
        cy = y + i * per
        cur = (i == revealed - 1)
        d.ellipse([140, cy + 8, 180, cy + 48], fill=th.accent if cur else th.muted)
        if numbered:
            d.text((152, cy + 12), str(i + 1), font=font(26, True), fill=th.bg)
        try:
            f2, lines, lh = fit(d, it, W - 420, per, int(H * 0.042), min_size=24)
        except TextOverflow:
            f2, lines, lh = f, [it[:60]], per
        for k, ln in enumerate(lines[:2]):
            d.text((210, cy + k * lh), ln, font=f2, fill=th.text if cur else th.muted)


def render_content(seg: dict, W: int, H: int, th: Theme, revealed: int) -> Image.Image:
    """seg: dict with visual_type, visual_title, on_screen_text, diagram_data, chart_data."""
    img = Image.new("RGB", (W, H), th.bg)
    d = ImageDraw.Draw(img)
    vt = seg.get("visual_type", "bullets")
    title = seg.get("visual_title") or ""
    items = [t for t in seg.get("on_screen_text", []) if t.strip()][:5] or [title or " "]
    reveal = max(0, min(revealed, len(items)))

    if vt in ("title", "closing", "divider"):
        f, lines, lh = fit(d, title or items[0], W - 360, int(H * 0.3), int(H * 0.09), min_size=36,
                           bold=True, max_lines=3)
        y = int(H * 0.32)
        d.rectangle([120, y - 30, 130, y + len(lines) * lh + 10], fill=th.accent)
        for ln in lines:
            d.text((170, y), ln, font=f, fill=th.text)
            y += lh
        if items and items[0] != title:
            sf, sl, slh = fit(d, items[0], W - 360, 120, int(H * 0.035), min_size=24)
            for ln in sl:
                d.text((170, y + 20), ln, font=sf, fill=th.muted)
                y += slh
        return img

    y = _title(d, W, H, th, title)
    if vt == "definition" and reveal > 0:
        d.rounded_rectangle([120, y, W - 120, int(H * 0.66)], 24, fill=th.panel, outline=th.accent, width=4)
        f, lines, lh = fit(d, " ".join(items[:2]), W - 340, int(H * 0.66) - y - 80, int(H * 0.05), min_size=26)
        if reveal < min(2, len(items)):   # only what has been said so far
            f, lines, lh = fit(d, " ".join(items[:reveal]) or " ", W - 340, int(H * 0.66) - y - 80,
                               int(H * 0.05), min_size=26)
        yy = y + 40
        for ln in lines:
            d.text((160, yy), ln, font=f, fill=th.text)
            yy += lh
    elif vt == "flow":
        steps = (seg.get("diagram_data") or {}).get("steps") or items
        steps = [str(s)[:40] for s in steps][:5]
        n = max(1, len(steps))
        bw = (W - 240 - (n - 1) * 70) // n
        by, bh = int(H * 0.32), int(H * 0.2)
        for i, s in enumerate(steps):
            x = 120 + i * (bw + 70)
            on = i < reveal
            d.rounded_rectangle([x, by, x + bw, by + bh], 18, fill=th.panel,
                                outline=th.accent if on else th.muted, width=5 if on else 2)
            f, lines, lh = fit(d, s if on else " ", bw - 30, bh - 20, 34, min_size=18, max_lines=4)
            yy = by + (bh - len(lines) * lh) // 2
            for ln in lines:
                d.text((x + 15, yy), ln, font=f, fill=th.text)
                yy += lh
            if i < n - 1 and i + 1 < reveal:
                ax = x + bw + 8
                d.line([ax, by + bh // 2, ax + 36, by + bh // 2], fill=th.accent2, width=6)
                d.polygon([(ax + 36, by + bh // 2 - 14), (ax + 36, by + bh // 2 + 14),
                           (ax + 54, by + bh // 2)], fill=th.accent2)
    elif vt == "comparison":
        left, right = items[: (len(items) + 1) // 2], items[(len(items) + 1) // 2:]
        cw = (W - 300) // 2
        for k, col in enumerate((left, right)):
            x = 120 + k * (cw + 60)
            d.rounded_rectangle([x, y, x + cw, int(H * 0.66)], 20, fill=th.panel,
                                outline=th.accent if k == 0 else th.accent2, width=4)
            yy = y + 30
            for j, t in enumerate(col):
                if k * len(left) + j >= reveal:
                    continue
                f, lines, lh = fit(d, t, cw - 60, 140, 34, min_size=20, max_lines=3)
                for ln in lines:
                    d.text((x + 30, yy), ln, font=f, fill=th.text)
                    yy += lh
                yy += 16
    elif vt == "timeline":
        ly = int(H * 0.42)
        d.line([140, ly, W - 140, ly], fill=th.muted, width=6)
        n = max(1, len(items))
        for i, t in enumerate(items):
            x = 160 + i * ((W - 320) // max(1, n - 1 if n > 1 else 1))
            on = i < reveal
            d.ellipse([x - 16, ly - 16, x + 16, ly + 16], fill=th.accent if on else th.muted)
            f, lines, lh = fit(d, t if on else " ", 300, 160, 30, min_size=18, max_lines=4)
            for k, ln in enumerate(lines):
                d.text((max(60, x - 150), ly + 40 + k * lh), ln, font=f, fill=th.text)
    elif vt == "chart":
        data = (seg.get("chart_data") or {})
        labels, vals = data.get("labels") or [], data.get("values") or []
        try:
            vals = [float(v) for v in vals]
        except (TypeError, ValueError):
            vals = []
        if labels and vals and len(labels) == len(vals):
            mx = max(vals) or 1
            n = len(vals)
            bw = min(180, (W - 360) // n - 30)
            base = int(H * 0.62)
            for i, (lb, v) in enumerate(zip(labels, vals)):
                if i >= reveal:
                    continue
                x = 180 + i * (bw + 30)
                h = int((base - y - 60) * v / mx)
                d.rectangle([x, base - h, x + bw, base], fill=th.accent)
                d.text((x, base - h - 40), f"{v:g}", font=font(28, True), fill=th.text)
                d.text((x, base + 10), str(lb)[:16], font=font(24), fill=th.muted)
        else:
            _bullet_rows(d, W, H, th, items, y, reveal)
    elif vt in ("steps",):
        _bullet_rows(d, W, H, th, items, y, reveal, numbered=True)
    elif vt in ("question", "example", "recap"):
        tag = {"question": "CHECKPOINT", "example": "EXAMPLE", "recap": "KEY TAKEAWAYS"}[vt]
        d.rounded_rectangle([120, y - 10, 120 + 30 * len(tag) + 40, y + 44], 12, fill=th.accent2)
        d.text((140, y), tag, font=font(30, True), fill=th.bg)
        _bullet_rows(d, W, H, th, items, y + 70, reveal)
    else:
        _bullet_rows(d, W, H, th, items, y, reveal)
    if seg.get("illustrative"):
        d.text((120, int(H * 0.69)), "Illustrative example", font=font(24), fill=th.accent2)
    return img


def draw_caption(img: Image.Image, text: str, th: Theme) -> Image.Image:
    W, H = img.size
    d = ImageDraw.Draw(img, "RGBA")
    box_h = int(H * 0.2)
    top = H - box_h - int(H * 0.03)
    f, lines, lh = fit(d, text, W - 300, box_h - 30, int(H * 0.04), min_size=26, bold=False, max_lines=2)
    d.rounded_rectangle([100, top, W - 100, top + box_h], 18, fill=th.caption_bg + (225,))
    yy = top + (box_h - len(lines) * lh) // 2
    for ln in lines:
        w = d.textlength(ln, font=f)
        d.text(((W - w) / 2, yy), ln, font=f, fill=(255, 255, 255))
        yy += lh
    return img
