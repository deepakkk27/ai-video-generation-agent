"""Three simple, high-contrast themes."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Theme:
    name: str
    bg: tuple
    panel: tuple
    text: tuple
    muted: tuple
    accent: tuple
    accent2: tuple
    caption_bg: tuple


THEMES = {
    "Clean Light": Theme("Clean Light", (248, 249, 252), (255, 255, 255), (22, 28, 45), (95, 105, 125),
                         (37, 99, 235), (234, 88, 12), (15, 23, 42)),
    "Deep Blue": Theme("Deep Blue", (14, 25, 48), (24, 40, 72), (240, 244, 252), (160, 176, 205),
                       (96, 165, 250), (251, 191, 36), (5, 10, 25)),
    "Warm Paper": Theme("Warm Paper", (250, 245, 235), (255, 252, 245), (45, 36, 28), (115, 100, 85),
                        (180, 83, 9), (21, 128, 61), (35, 28, 22)),
}


def get_theme(name: str) -> Theme:
    return THEMES.get(name, THEMES["Clean Light"])
