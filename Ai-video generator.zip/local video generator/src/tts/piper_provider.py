"""Piper local TTS using a locally stored .onnx voice (pip install piper-tts)."""
from __future__ import annotations

import wave
from pathlib import Path

import numpy as np

from src.tts.audio_utils import clean_text_for_tts, write_wav
from src.tts.base import TTSError, TTSProvider

VOICE_DIR = Path(__file__).resolve().parents[2] / "voices"


class PiperProvider(TTSProvider):
    name = "piper"

    def __init__(self, voice: str = ""):
        self._voice = voice
        self._model = None

    @property
    def voice(self) -> str:
        return self._voice or (self.list_voices() or [""])[0]

    def list_voices(self) -> list[str]:
        return sorted(p.stem for p in VOICE_DIR.glob("*.onnx")) if VOICE_DIR.exists() else []

    def availability(self) -> tuple[bool, str]:
        try:
            import piper  # noqa: F401
        except ImportError:
            return False, "Piper is not installed. Run: pip install piper-tts"
        if not self.list_voices():
            return False, (f"No Piper voice found. Download a voice .onnx and its .onnx.json from "
                           f"the Piper voices page into {VOICE_DIR} (check the voice license).")
        return True, "Piper ready."

    def _load(self):
        if self._model is None:
            from piper import PiperVoice
            self._model = PiperVoice.load(str(VOICE_DIR / f"{self.voice}.onnx"))
        return self._model

    def synthesize(self, text: str, out_wav: Path) -> None:
        text = clean_text_for_tts(text)
        if not text:
            raise TTSError("empty text")
        tmp = Path(out_wav).with_suffix(".piper.wav")
        try:
            model = self._load()
            with wave.open(str(tmp), "wb") as w:
                model.synthesize_wav(text, w)
            with wave.open(str(tmp), "rb") as r:
                sr = r.getframerate()
                data = np.frombuffer(r.readframes(r.getnframes()), dtype=np.int16).astype(np.float32) / 32768
            write_wav(data, sr, out_wav)
        except Exception as e:  # noqa: BLE001
            raise TTSError(f"Piper failed: {e}") from e
        finally:
            tmp.unlink(missing_ok=True)
