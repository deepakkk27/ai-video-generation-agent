"""Select a TTS backend explicitly; never silently switch."""
from __future__ import annotations

from src.tts.base import TTSProvider


def make_tts(provider: str, voice: str = "") -> TTSProvider:
    provider = provider.lower()
    if provider == "kokoro":
        from src.tts.kokoro_provider import KokoroProvider
        return KokoroProvider(voice)
    if provider == "piper":
        from src.tts.piper_provider import PiperProvider
        return PiperProvider(voice)
    raise ValueError(f"Unknown TTS provider '{provider}'. Use 'kokoro' or 'piper'.")
