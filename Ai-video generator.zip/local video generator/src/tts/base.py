"""TTS provider interface."""
from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path


class TTSError(Exception):
    pass


class TTSProvider(ABC):
    name = "base"
    sample_rate = 24000

    @abstractmethod
    def availability(self) -> tuple[bool, str]:
        """(ready, message) without generating audio."""

    @abstractmethod
    def list_voices(self) -> list[str]:
        ...

    @abstractmethod
    def synthesize(self, text: str, out_wav: Path) -> None:
        """Write a mono 16-bit WAV. Raise TTSError on failure."""

    @property
    @abstractmethod
    def voice(self) -> str:
        ...

    def self_test(self, tmp_wav: Path) -> tuple[bool, str]:
        ok, msg = self.availability()
        if not ok:
            return False, msg
        try:
            self.synthesize("Ready.", tmp_wav)
            from src.tts.audio_utils import wav_duration
            d = wav_duration(tmp_wav)
            return (d > 0.1), f"{self.name} voice '{self.voice}' produced {d:.2f}s sample."
        except Exception as e:  # noqa: BLE001
            return False, f"{self.name} self-test failed: {e}"
