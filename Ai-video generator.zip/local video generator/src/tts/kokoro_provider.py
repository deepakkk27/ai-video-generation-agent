"""Kokoro-82M local TTS (optional dependency: pip install kokoro, needs espeak-ng)."""
from __future__ import annotations

from pathlib import Path

import numpy as np

from src.tts.audio_utils import clean_text_for_tts, write_wav
from src.tts.base import TTSError, TTSProvider

KOKORO_VOICES = ["af_heart", "af_bella", "af_nicole", "am_michael", "am_adam", "bf_emma", "bm_george"]


class KokoroProvider(TTSProvider):
    name = "kokoro"
    sample_rate = 24000

    def __init__(self, voice: str = ""):
        self._voice = voice or KOKORO_VOICES[0]
        self._pipeline = None

    @property
    def voice(self) -> str:
        return self._voice

    def availability(self) -> tuple[bool, str]:
        try:
            import kokoro  # noqa: F401
        except ImportError:
            return False, ("Kokoro is not installed. Run: pip install kokoro soundfile  and install "
                           "espeak-ng for Windows. Or choose Piper in Settings.")
        return True, "Kokoro package found."

    def list_voices(self) -> list[str]:
        return KOKORO_VOICES if self.availability()[0] else []

    def _load(self):
        if self._pipeline is None:  # keep loaded for the whole job
            from kokoro import KPipeline
            self._pipeline = KPipeline(lang_code=self._voice[0])
        return self._pipeline

    def synthesize(self, text: str, out_wav: Path) -> None:
        text = clean_text_for_tts(text)
        if not text:
            raise TTSError("empty text")
        try:
            parts = [np.asarray(a) for _, _, a in self._load()(text, voice=self._voice) if a is not None]
            if not parts:
                raise TTSError("Kokoro produced no audio")
            write_wav(np.concatenate(parts), self.sample_rate, out_wav)
        except TTSError:
            raise
        except Exception as e:  # noqa: BLE001
            raise TTSError(f"Kokoro failed: {e}") from e
