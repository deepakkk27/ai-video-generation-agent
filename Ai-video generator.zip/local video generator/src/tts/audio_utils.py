"""WAV helpers: write normalized mono 16-bit PCM, measure exact duration, validate."""
from __future__ import annotations

import wave
from pathlib import Path

import numpy as np

TARGET_SR = 24000


def write_wav(samples, sample_rate: int, out: Path) -> None:
    """Normalize to mono, clip-safe, resample to TARGET_SR, write 16-bit PCM."""
    a = np.asarray(samples, dtype=np.float32)
    if a.ndim > 1:
        a = a.mean(axis=1)
    a = np.nan_to_num(a)
    if a.size == 0:
        raise ValueError("TTS returned empty audio")
    peak = float(np.max(np.abs(a)))
    if peak < 1e-4:
        raise ValueError("TTS returned silent audio")
    if peak > 1.0:
        a = a / peak
    if sample_rate != TARGET_SR:
        n = int(round(a.size * TARGET_SR / sample_rate))
        a = np.interp(np.linspace(0, a.size - 1, n), np.arange(a.size), a).astype(np.float32)
    pcm = (np.clip(a, -1, 1) * 32767).astype(np.int16)
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(out), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(TARGET_SR)
        w.writeframes(pcm.tobytes())


def wav_duration(path: Path) -> float:
    with wave.open(str(path), "rb") as w:
        return w.getnframes() / float(w.getframerate())


def clean_text_for_tts(text: str) -> str:
    text = "".join(ch for ch in text if ch.isprintable() or ch in "\n ")
    return " ".join(text.split())
