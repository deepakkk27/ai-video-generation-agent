"""PPTX parser: slide text, tables, and speaker notes."""
from __future__ import annotations

from pathlib import Path

from src.ingestion.text_parser import normalize
from src.models.schemas import SourceRecord


def _shape_text(shape) -> list[str]:
    out: list[str] = []
    if getattr(shape, "has_text_frame", False) and shape.has_text_frame:
        t = shape.text_frame.text.strip()
        if t:
            out.append(t)
    if getattr(shape, "has_table", False) and shape.has_table:
        for row in shape.table.rows:
            out.append(" | ".join(c.text.strip() for c in row.cells))
    if shape.shape_type == 6:  # group
        for s in shape.shapes:
            out.extend(_shape_text(s))
    return out


def parse_pptx(path: Path) -> tuple[list[SourceRecord], list[str]]:
    from pptx import Presentation

    prs = Presentation(str(path))
    records: list[SourceRecord] = []
    warnings: list[str] = []
    image_only = 0
    for i, slide in enumerate(prs.slides, 1):
        parts: list[str] = []
        pictures = 0
        for shape in slide.shapes:
            parts.extend(_shape_text(shape))
            if shape.shape_type == 13:
                pictures += 1
        notes = ""
        if slide.has_notes_slide:
            notes = slide.notes_slide.notes_text_frame.text.strip()
        raw = "\n".join(parts)
        if notes:
            raw += "\n[Speaker notes]\n" + notes
        sid = f"PPT-S{i:04d}"
        text = normalize(raw)
        if not text:
            records.append(SourceRecord(source_id=sid, kind="pptx", index=i, status="skipped",
                                        note="slide has no text"))
            if pictures:
                image_only += 1
            continue
        note = f"{pictures} picture(s) not parsed" if pictures else ""
        records.append(SourceRecord(source_id=sid, kind="pptx", index=i, raw_text=raw,
                                    text=text, note=note))
    if image_only:
        warnings.append(f"{image_only} slide(s) contain only images; their content was not parsed.")
    if any(r.note.endswith("not parsed") for r in records):
        warnings.append("Some slides contain pictures/diagrams whose content was not parsed.")
    if not records:
        warnings.append("The presentation has no slides.")
    return records, warnings
