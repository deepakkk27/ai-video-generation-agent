"""DOCX parser preserving body order of paragraphs and tables."""
from __future__ import annotations

from pathlib import Path

from src.ingestion.text_parser import normalize
from src.models.schemas import SourceRecord


def parse_docx(path: Path) -> tuple[list[SourceRecord], list[str]]:
    from docx import Document
    from docx.table import Table
    from docx.text.paragraph import Paragraph

    doc = Document(str(path))
    records: list[SourceRecord] = []
    warnings: list[str] = []
    n = 0
    for child in doc.element.body.iterchildren():
        tag = child.tag.rsplit("}", 1)[-1]
        if tag == "p":
            p = Paragraph(child, doc)
            raw = p.text.strip()
            heading = (p.style.name or "").lower().startswith("heading") if p.style is not None else False
        elif tag == "tbl":
            t = Table(child, doc)
            rows = [" | ".join(c.text.strip() for c in r.cells) for r in t.rows]
            raw = "\n".join(rows).strip()
            heading = False
            if len(rows) > 60:
                warnings.append(f"A table with {len(rows)} rows was included; it is very long.")
        else:
            continue
        if not raw:
            continue
        n += 1
        records.append(SourceRecord(source_id=f"DOC-P{n:04d}", kind="docx", index=n,
                                    raw_text=raw, text=normalize(raw), heading=heading))
    if not records:
        warnings.append("The Word document has no text.")
    return records, warnings
