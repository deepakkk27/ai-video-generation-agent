"""SRT / VTT transcript parser preserving timestamps as metadata."""
from __future__ import annotations

import re
from pathlib import Path

from src.ingestion.text_parser import decode_bytes
from src.models.schemas import SourceRecord

_TS = re.compile(
    r"(?:(\d+):)?(\d{1,2}):(\d{2})[,.](\d{1,3})\s*-->\s*(?:(\d+):)?(\d{1,2}):(\d{2})[,.](\d{1,3})")


def _secs(h, m, s, ms) -> float:
    return int(h or 0) * 3600 + int(m) * 60 + int(s) + int(ms.ljust(3, "0")) / 1000


def parse_subtitles(path: Path, kind: str) -> tuple[list[SourceRecord], list[str]]:
    raw = decode_bytes(Path(path).read_bytes()).replace("\r\n", "\n")
    records: list[SourceRecord] = []
    for block in re.split(r"\n\s*\n", raw):
        lines = [l for l in block.split("\n") if l.strip()]
        if not lines:
            continue
        ts_idx = next((i for i, l in enumerate(lines) if _TS.search(l)), None)
        if ts_idx is None:
            continue  # WEBVTT header, NOTE blocks, etc.
        m = _TS.search(lines[ts_idx])
        start = _secs(*m.group(1, 2, 3, 4))
        end = _secs(*m.group(5, 6, 7, 8))
        body = " ".join(re.sub(r"<[^>]+>", "", l).strip() for l in lines[ts_idx + 1:])
        if not body:
            continue
        n = len(records) + 1
        records.append(SourceRecord(
            source_id=f"TRANSCRIPT-T{n:04d}", kind=kind, index=n,
            raw_text=body, text=body, start_s=start, end_s=end))
    warnings = [] if records else [f"No cues found in {kind.upper()} file."]
    return records, warnings
