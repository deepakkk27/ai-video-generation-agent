"""Coverage manifests for extraction and for LLM analysis."""
from __future__ import annotations

from src.models.schemas import Chunk, ChunkAnalysis, SourceRecord


def extraction_coverage(records: list[SourceRecord]) -> dict:
    items = [{"source_id": r.source_id, "status": r.status, "chars": len(r.text), "note": r.note}
             for r in records]
    failed = [i["source_id"] for i in items if i["status"] == "failed"]
    skipped = [i["source_id"] for i in items if i["status"] == "skipped"]
    return {
        "total": len(items),
        "processed": sum(1 for i in items if i["status"] == "processed"),
        "failed": failed, "skipped": skipped,
        "complete": not failed and not skipped,
        "items": items,
    }


def analysis_coverage(chunks: list[Chunk], analyses: list[ChunkAnalysis]) -> dict:
    by_id = {a.chunk_id: a for a in analyses}
    missing = [c.chunk_id for c in chunks if c.chunk_id not in by_id]
    failed = [a.chunk_id for a in analyses if a.status == "failed"]
    return {
        "total_chunks": len(chunks),
        "analyzed": sum(1 for c in chunks if c.chunk_id in by_id and by_id[c.chunk_id].status == "analyzed"),
        "failed": failed, "missing": missing,
        "complete": not missing and not failed,
    }
