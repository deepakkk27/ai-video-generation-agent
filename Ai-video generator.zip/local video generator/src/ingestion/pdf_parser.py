"""PDF parser: PyMuPDF text first, OCR fallback for low-text pages."""
from __future__ import annotations

from pathlib import Path

from src.ingestion import ocr
from src.ingestion.text_parser import normalize
from src.models.schemas import SourceRecord

LOW_TEXT_CHARS = 25


def parse_pdf(path: Path) -> tuple[list[SourceRecord], list[str]]:
    import fitz  # PyMuPDF

    warnings: list[str] = []
    records: list[SourceRecord] = []
    ocr_ok = ocr.tesseract_available()
    ocr_warned = False
    with fitz.open(str(path)) as doc:
        if doc.needs_pass:
            raise ValueError("The PDF is password protected.")
        for i, page in enumerate(doc, 1):
            sid = f"PDF-P{i:04d}"
            try:
                raw = page.get_text("text") or ""
            except Exception as e:  # noqa: BLE001
                records.append(SourceRecord(source_id=sid, kind="pdf", index=i,
                                            status="failed", note=f"extraction error: {e}"))
                warnings.append(f"Page {i}: extraction failed ({e}).")
                continue
            note = ""
            if len(raw.strip()) < LOW_TEXT_CHARS:
                if ocr_ok:
                    try:
                        pix = page.get_pixmap(dpi=200)
                        raw = ocr.ocr_image_bytes(pix.tobytes("png"))
                        note = "ocr"
                    except Exception as e:  # noqa: BLE001
                        note = f"ocr failed: {e}"
                else:
                    note = "low text; OCR unavailable"
                    if not ocr_warned:
                        warnings.append(ocr.INSTALL_HELP)
                        ocr_warned = True
            text = normalize(raw)
            if not text:
                records.append(SourceRecord(source_id=sid, kind="pdf", index=i, raw_text=raw,
                                            status="failed", note=note or "no text"))
                warnings.append(f"Page {i}: no text could be extracted ({note or 'empty'}).")
                continue
            records.append(SourceRecord(source_id=sid, kind="pdf", index=i, raw_text=raw,
                                        text=text, note=note))
    if not records:
        warnings.append("The PDF has no pages.")
    return records, warnings
