"""Optional OCR via Tesseract. Never fails silently."""
from __future__ import annotations

import shutil

INSTALL_HELP = (
    "Tesseract OCR was not found. Install it on Windows from the UB-Mannheim build "
    "(https://github.com/UB-Mannheim/tesseract/wiki), add its folder to PATH, then restart the app."
)


def tesseract_available() -> bool:
    if not shutil.which("tesseract"):
        return False
    try:
        import pytesseract  # noqa: F401
    except ImportError:
        return False
    return True


def ocr_image_bytes(png_bytes: bytes) -> str:
    import io

    import pytesseract
    from PIL import Image

    with Image.open(io.BytesIO(png_bytes)) as img:
        return pytesseract.image_to_string(img)
