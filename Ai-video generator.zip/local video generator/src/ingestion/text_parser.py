"""TXT / Markdown parser. Each non-empty paragraph (blank-line separated) is a record."""
from __future__ import annotations

import re
from pathlib import Path

from src.models.schemas import SourceRecord


def decode_bytes(data: bytes) -> str:
    for enc in ("utf-8-sig", "utf-16", "cp1252", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeError:
            continue
    return data.decode("utf-8", errors="replace")


def normalize(text: str) -> str:
    text = text.replace(" ", " ").replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def parse_text(path: Path, kind: str = "txt") -> tuple[list[SourceRecord], list[str]]:
    raw = decode_bytes(Path(path).read_bytes())
    prefix = "TXT" if kind == "txt" else "MD"
    records: list[SourceRecord] = []
    for i, para in enumerate([p for p in re.split(r"\n\s*\n", raw) if p.strip()], 1):
        is_heading = para.lstrip().startswith("#") if kind == "md" else False
        records.append(SourceRecord(
            source_id=f"{prefix}-L{i:06d}", kind=kind, index=i,
            raw_text=para, text=normalize(para), heading=is_heading))
    warnings = [] if records else ["The text file is empty."]
    return records, warnings
