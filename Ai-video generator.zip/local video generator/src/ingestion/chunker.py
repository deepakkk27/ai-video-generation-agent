"""Semantic chunking: groups whole source records into bounded chunks, splitting oversized
records on sentence boundaries. Every chunk keeps the IDs of the records it contains."""
from __future__ import annotations

import re

from src.models.schemas import Chunk, SourceRecord


def approx_tokens(text: str) -> int:
    return max(1, len(text) // 4)


def _split_long(text: str, max_chars: int) -> list[str]:
    sentences = re.split(r"(?<=[.!?])\s+", text)
    parts, cur = [], ""
    for s in sentences:
        while len(s) > max_chars:  # unbreakable run: hard split
            if cur:
                parts.append(cur)
                cur = ""
            parts.append(s[:max_chars])
            s = s[max_chars:]
        if len(cur) + len(s) + 1 > max_chars and cur:
            parts.append(cur)
            cur = s
        else:
            cur = f"{cur} {s}".strip()
    if cur:
        parts.append(cur)
    return parts


def chunk_records(records: list[SourceRecord], max_chars: int = 5000,
                  overlap_chars: int = 0) -> list[Chunk]:
    """Chunk processed records in order. Headings start a new chunk when the current one is
    already reasonably full, so concepts stay together."""
    chunks: list[Chunk] = []
    cur_ids: list[str] = []
    cur_txt: list[str] = []
    cur_len = 0

    def flush():
        nonlocal cur_ids, cur_txt, cur_len
        if cur_ids:
            chunks.append(Chunk(chunk_id=f"C{len(chunks) + 1:04d}",
                                source_ids=list(dict.fromkeys(cur_ids)),
                                text="\n\n".join(cur_txt)))
        cur_ids, cur_txt, cur_len = [], [], 0

    for r in records:
        if r.status != "processed" or not r.text.strip():
            continue
        pieces = _split_long(r.text, max_chars) if len(r.text) > max_chars else [r.text]
        for piece in pieces:
            labelled = f"[{r.source_id}] {piece}"
            if cur_len + len(labelled) > max_chars and cur_ids:
                tail = cur_txt[-1][-overlap_chars:] if overlap_chars and cur_txt else ""
                tail_ids = cur_ids[-1:]
                flush()
                if tail:
                    cur_ids, cur_txt, cur_len = list(tail_ids), [tail], len(tail)
            elif r.heading and cur_len > max_chars * 0.6:
                flush()
            cur_ids.append(r.source_id)
            cur_txt.append(labelled)
            cur_len += len(labelled)
    flush()
    return chunks
