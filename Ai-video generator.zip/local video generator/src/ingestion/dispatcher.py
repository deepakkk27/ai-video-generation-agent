"""Validate an upload and route it to the right parser."""
from __future__ import annotations

import hashlib
import re
import uuid
from dataclasses import dataclass
from pathlib import Path

from src.models.schemas import SourceRecord

SUPPORTED = {".pdf": "pdf", ".pptx": "pptx", ".docx": "docx", ".txt": "txt",
             ".md": "md", ".srt": "srt", ".vtt": "vtt"}
ZIP_SIG = b"PK\x03\x04"


class IngestError(Exception):
    pass


@dataclass
class IngestResult:
    kind: str
    records: list[SourceRecord]
    warnings: list[str]
    sha256: str
    size_bytes: int
    original_name: str


def sanitize_filename(name: str) -> str:
    name = Path(name.replace("\\", "/")).name
    name = re.sub(r"[^A-Za-z0-9._ -]", "_", name).strip(" .")
    return name or "upload"


def new_job_id() -> str:
    return uuid.uuid4().hex


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def detect_kind(path: Path) -> str:
    ext = Path(path).suffix.lower()
    if ext not in SUPPORTED:
        raise IngestError(f"Unsupported file type '{ext}'. Supported: {', '.join(sorted(SUPPORTED))}")
    kind = SUPPORTED[ext]
    with open(path, "rb") as f:
        head = f.read(8)
    if kind == "pdf" and not head.startswith(b"%PDF"):
        raise IngestError("File has a .pdf extension but is not a valid PDF.")
    if kind in ("pptx", "docx") and not head.startswith(ZIP_SIG):
        raise IngestError(f"File has a .{kind} extension but is not a valid Office file.")
    return kind


def ingest(path: Path, max_upload_mb: int = 512, original_name: str | None = None) -> IngestResult:
    path = Path(path)
    if not path.is_file():
        raise IngestError("File not found.")
    size = path.stat().st_size
    if size == 0:
        raise IngestError("The file is empty.")
    if size > max_upload_mb * 1024 * 1024:
        raise IngestError(f"File is larger than the {max_upload_mb} MB limit.")
    kind = detect_kind(path)
    try:
        if kind == "pdf":
            from src.ingestion.pdf_parser import parse_pdf
            records, warnings = parse_pdf(path)
        elif kind == "pptx":
            from src.ingestion.pptx_parser import parse_pptx
            records, warnings = parse_pptx(path)
        elif kind == "docx":
            from src.ingestion.docx_parser import parse_docx
            records, warnings = parse_docx(path)
        elif kind in ("txt", "md"):
            from src.ingestion.text_parser import parse_text
            records, warnings = parse_text(path, kind)
        else:
            from src.ingestion.subtitle_parser import parse_subtitles
            records, warnings = parse_subtitles(path, kind)
    except IngestError:
        raise
    except Exception as e:  # noqa: BLE001
        raise IngestError(f"Could not read the {kind.upper()} file: {e}") from e
    if not any(r.status == "processed" and r.text.strip() for r in records):
        raise IngestError("No usable text could be extracted from this file. "
                          + " ".join(warnings[:2]))
    return IngestResult(kind=kind, records=records, warnings=warnings,
                        sha256=sha256_file(path), size_bytes=size,
                        original_name=original_name or path.name)
