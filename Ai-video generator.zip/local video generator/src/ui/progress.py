"""Stage-labelled progress display."""
from __future__ import annotations

import time

import streamlit as st

from src.pipeline.orchestrator import STAGES


class ProgressView:
    def __init__(self):
        self.t0 = time.time()
        self.bar = st.progress(0.0)
        self.stage_box = st.empty()
        self.list_box = st.empty()

    def __call__(self, stage: int, frac: float, detail: str = "") -> None:
        overall = (stage + max(0.0, min(1.0, frac))) / len(STAGES)
        self.bar.progress(min(1.0, overall))
        el = int(time.time() - self.t0)
        self.stage_box.markdown(
            f"**Stage {stage + 1}/{len(STAGES)}: {STAGES[stage]}** — {frac * 100:.0f}% · "
            f"{detail} · elapsed {el // 60}m {el % 60}s")
        self.list_box.markdown("\n".join(
            ("✅ " if i < stage else "▶️ " if i == stage else "⬜ ") + n for i, n in enumerate(STAGES)))
