"""Small Streamlit helpers."""
from __future__ import annotations

from pathlib import Path

import streamlit as st

CSS = """
<style>
.block-container {max-width: 1000px; padding-top: 2rem;}
h1 {letter-spacing: -0.5px;}
.stButton>button[kind="primary"] {font-weight: 600;}
</style>
"""


def download_if_exists(label: str, path: Path, mime: str, key: str) -> None:
    """Never show a download button for a missing/empty file."""
    path = Path(path)
    if path.exists() and path.stat().st_size > 0:
        st.download_button(label, data=path.read_bytes(), file_name=path.name, mime=mime, key=key)


def status_badge(ok: bool, msg: str) -> None:
    (st.success if ok else st.warning)(msg)
