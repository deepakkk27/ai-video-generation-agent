"""FFmpeg / ffprobe discovery and runner."""
from __future__ import annotations

import shutil
import subprocess

FFMPEG_HELP = ("FFmpeg/ffprobe not found. Install a full FFmpeg build (e.g. `winget install Gyan.FFmpeg`), "
               "restart the terminal, and verify with `ffmpeg -version` and `ffprobe -version`.")


class FFmpegError(Exception):
    pass


def check_ffmpeg() -> tuple[bool, str]:
    if shutil.which("ffmpeg") and shutil.which("ffprobe"):
        return True, "FFmpeg and ffprobe found."
    return False, FFMPEG_HELP


def run(args: list[str], timeout: int = 3600) -> str:
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    except FileNotFoundError as e:
        raise FFmpegError(FFMPEG_HELP) from e
    except subprocess.TimeoutExpired as e:
        raise FFmpegError(f"{args[0]} timed out") from e
    if p.returncode != 0:
        raise FFmpegError(f"{args[0]} failed: {p.stderr[-800:]}")
    return p.stdout
