"""Assemble per-segment clips and a single audio track into an MP4 (H.264/AAC)."""
from __future__ import annotations

import wave
from pathlib import Path
from typing import Callable, Optional

from src.models.schemas import AudioUnit, Shot
from src.tts.audio_utils import TARGET_SR
from src.video.ffmpeg import run


def build_audio_track(units: list[AudioUnit], pause_s: float, out_wav: Path) -> None:
    """Stream-concatenate unit WAVs with silence gaps (no full-audio load into RAM)."""
    pause_frames = int(round(pause_s * TARGET_SR))
    silence = b"\x00\x00" * pause_frames
    with wave.open(str(out_wav), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(TARGET_SR)
        for u in units:
            p = Path(u.wav_path)
            if not p.exists():
                raise FileNotFoundError(f"missing audio for {u.unit_id}")
            with wave.open(str(p), "rb") as r:
                if r.getframerate() != TARGET_SR or r.getnchannels() != 1:
                    raise ValueError(f"{u.unit_id}: unexpected WAV format")
                w.writeframes(r.readframes(r.getnframes()))
            w.writeframes(silence)


def _concat_file(lines: list[str], path: Path) -> None:
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def render_segment_clip(seg_units: list[AudioUnit], frames: dict[str, Path], pause_s: float,
                        out_mp4: Path, w: int, h: int, fps: int, work: Path) -> None:
    lines = []
    for u in seg_units:
        lines.append(f"file '{frames[u.unit_id].resolve().as_posix()}'")
        lines.append(f"duration {u.duration_s + pause_s:.3f}")
    lines.append(f"file '{frames[seg_units[-1].unit_id].resolve().as_posix()}'")  # concat quirk
    lst = work / (out_mp4.stem + ".txt")
    _concat_file(lines, lst)
    run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(lst),
         "-vf", f"scale={w}:{h},fps={fps},format=yuv420p,fade=t=in:st=0:d=0.4",
         "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-an", str(out_mp4)])


def assemble(units: list[AudioUnit], frames: dict[str, Path], pause_s: float, job_dir: Path,
             out_mp4: Path, w: int, h: int, fps: int,
             progress: Optional[Callable[[int, int, str], None]] = None) -> None:
    job_dir = Path(job_dir)
    work = job_dir / "clips"
    work.mkdir(parents=True, exist_ok=True)
    order: list[str] = []
    by_seg: dict[str, list[AudioUnit]] = {}
    for u in units:
        if u.segment_id not in by_seg:
            order.append(u.segment_id)
        by_seg.setdefault(u.segment_id, []).append(u)
    clips = []
    for i, sid in enumerate(order, 1):
        clip = work / f"{sid}.mp4"
        render_segment_clip(by_seg[sid], frames, pause_s, clip, w, h, fps, work)
        clips.append(clip)
        if progress:
            progress(i, len(order), sid)
    audio = job_dir / "narration.wav"
    build_audio_track(units, pause_s, audio)
    lst = work / "all_clips.txt"
    _concat_file([f"file '{c.resolve().as_posix()}'" for c in clips], lst)
    video_only = work / "video_only.mp4"
    run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(lst),
         "-c", "copy", str(video_only)])
    run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(video_only), "-i", str(audio),
         "-c:v", "copy", "-c:a", "aac", "-b:a", "160k", "-shortest", "-movflags", "+faststart",
         str(out_mp4)])


def assemble_timeline(shots: list[Shot], units: list[AudioUnit], pause_s: float, job_dir: Path,
                      out_mp4: Path, w: int, h: int, fps: int,
                      progress: Optional[Callable[[int, int, str], None]] = None) -> Path:
    """Single-pass render driven by the shared timeline.

    Every shot lasts an exact whole number of frames computed from absolute times (no per-clip encodes,
    so no per-clip rounding or container offsets add up), there are no fades, and the audio track is built
    with the same sample-exact positions the timeline used. Returns the narration WAV path."""
    job_dir = Path(job_dir)
    work = job_dir / "clips"
    work.mkdir(parents=True, exist_ok=True)
    if not shots:
        raise ValueError("no shots to render")
    audio = job_dir / "narration.wav"
    build_audio_track(units, pause_s, audio)
    lines = []
    for sh in shots:
        lines.append(f"file '{Path(sh.frame_path).resolve().as_posix()}'")
        lines.append(f"duration {(sh.end_frame - sh.start_frame) / fps:.6f}")
    lines.append(f"file '{Path(shots[-1].frame_path).resolve().as_posix()}'")  # concat demuxer quirk
    lst = work / "timeline.txt"
    _concat_file(lines, lst)
    video_only = work / "video_only.mp4"
    n_frames = shots[-1].end_frame
    if progress:
        progress(0, 2, "encoding video")
    run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(lst),
         "-vf", f"scale={w}:{h},fps={fps},format=yuv420p", "-frames:v", str(n_frames),
         "-c:v", "libx264", "-preset", "veryfast", "-tune", "stillimage", "-crf", "20", "-an",
         str(video_only)])
    if progress:
        progress(1, 2, "muxing audio")
    run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(video_only), "-i", str(audio),
         "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k",
         "-movflags", "+faststart", str(out_mp4)])
    if progress:
        progress(2, 2, "done")
    return audio
