"""ffprobe-based validation of the final MP4."""
from __future__ import annotations

import json
from pathlib import Path

from src.video.ffmpeg import run


def probe(path: Path) -> dict:
    out = run(["ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams",
               str(path)], timeout=120)
    return json.loads(out)


def summarize(info: dict) -> dict:
    v = next((s for s in info.get("streams", []) if s.get("codec_type") == "video"), None)
    a = next((s for s in info.get("streams", []) if s.get("codec_type") == "audio"), None)
    fps = 0.0
    if v and v.get("r_frame_rate", "0/1") != "0/0":
        n, d = v["r_frame_rate"].split("/")
        fps = float(n) / float(d) if float(d) else 0.0
    return {
        "duration_s": float(info.get("format", {}).get("duration", 0) or 0),
        "has_video": v is not None, "has_audio": a is not None,
        "width": int(v["width"]) if v else 0, "height": int(v["height"]) if v else 0,
        "fps": fps, "video_codec": v.get("codec_name", "") if v else "",
        "audio_codec": a.get("codec_name", "") if a else "",
        "size_bytes": int(info.get("format", {}).get("size", 0) or 0),
    }


def validate_summary(s: dict, width: int, height: int) -> list[str]:
    """Pure function (testable without ffprobe). Returns a list of problems."""
    problems = []
    if s.get("duration_s", 0) <= 0:
        problems.append("duration is not positive")
    if not s.get("has_video"):
        problems.append("no video stream")
    if not s.get("has_audio"):
        problems.append("no audio stream")
    if s.get("has_video") and (s.get("width") != width or s.get("height") != height):
        problems.append(f"unexpected size {s.get('width')}x{s.get('height')}, expected {width}x{height}")
    return problems


def validate_mp4(path: Path, width: int, height: int) -> tuple[dict, list[str]]:
    path = Path(path)
    if not path.exists() or path.stat().st_size == 0:
        return {}, ["output file is missing or empty"]
    s = summarize(probe(path))
    return s, validate_summary(s, width, height)
