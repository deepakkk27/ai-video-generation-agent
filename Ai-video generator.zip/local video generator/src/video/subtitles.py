"""SRT generation from measured audio durations; timeline computation."""
from __future__ import annotations

from src.models.schemas import AudioUnit


def assign_timeline(units: list[AudioUnit], pause_s: float) -> list[AudioUnit]:
    """Sample-exact timeline. Positions are integer sample counts, so they match the concatenated
    audio track bit for bit and never drift (the pause is snapped to whole samples)."""
    from src.tts.audio_utils import TARGET_SR
    pause_n = int(round(pause_s * TARGET_SR))
    n = 0
    for u in units:
        dur_n = int(round(u.duration_s * TARGET_SR))
        u.start_s = n / TARGET_SR
        u.end_s = (n + dur_n) / TARGET_SR
        n += dur_n + pause_n
    return units


def fmt_ts(sec: float) -> str:
    ms = int(round(sec * 1000))
    h, ms = divmod(ms, 3600_000)
    m, ms = divmod(ms, 60_000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def build_srt(units: list[AudioUnit]) -> str:
    out = []
    for i, u in enumerate(units, 1):
        out.append(f"{i}\n{fmt_ts(u.start_s)} --> {fmt_ts(u.end_s)}\n{u.text}\n")
    return "\n".join(out)


def validate_timeline(units: list[AudioUnit]) -> list[str]:
    problems = []
    prev_end = 0.0
    for u in units:
        if u.end_s <= u.start_s:
            problems.append(f"{u.unit_id}: non-positive duration")
        if u.start_s < prev_end - 1e-6:
            problems.append(f"{u.unit_id}: overlaps previous unit")
        if abs((u.end_s - u.start_s) - u.duration_s) > 0.002:
            problems.append(f"{u.unit_id}: SRT span differs from measured audio")
        prev_end = u.end_s
    return problems
