"""Per-chunk analysis with on-disk persistence (resumable) and hierarchical global summary."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Callable, Optional

from src.llm import prompts
from src.llm.base import LLMError, LLMProvider
from src.llm.validators import extract_json, parse_with_repair
from src.models.schemas import Chunk, ChunkAnalysis


def analyze_chunks(chunks: list[Chunk], llm: LLMProvider, out_dir: Path,
                   progress: Optional[Callable[[int, int, str], None]] = None) -> list[ChunkAnalysis]:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    results: list[ChunkAnalysis] = []
    for i, ch in enumerate(chunks, 1):
        f = out_dir / f"{ch.chunk_id}.json"
        if f.exists():  # resume
            try:
                prev = ChunkAnalysis.model_validate_json(f.read_text(encoding="utf-8"))
                if prev.status == "analyzed":
                    results.append(prev)
                    if progress:
                        progress(i, len(chunks), ch.chunk_id)
                    continue
            except Exception:  # noqa: BLE001
                pass
        try:
            raw = llm.generate(prompts.analysis_prompt(ch.chunk_id, ch.text),
                               system=prompts.SYSTEM, json_mode=True)
            data = parse_with_repair(raw, ChunkAnalysis, llm)
            data.chunk_id = ch.chunk_id
            data.source_ids = ch.source_ids
            data.status = "analyzed"
        except LLMError as e:
            data = ChunkAnalysis(chunk_id=ch.chunk_id, source_ids=ch.source_ids,
                                 status="failed", error=str(e))
        f.write_text(data.model_dump_json(indent=2), encoding="utf-8")
        results.append(data)
        if progress:
            progress(i, len(chunks), ch.chunk_id)
    return results


def global_summary(analyses: list[ChunkAnalysis], llm: LLMProvider, group: int = 8) -> str:
    """Hierarchical reduction; only called after every chunk has been processed."""
    level = [a.summary for a in analyses if a.status == "analyzed" and a.summary]
    if not level:
        return ""
    while len(level) > 1:
        nxt = []
        for i in range(0, len(level), group):
            raw = llm.generate(prompts.global_summary_prompt(level[i:i + group]),
                               system=prompts.SYSTEM, json_mode=True)
            try:
                nxt.append(str(extract_json(raw).get("summary", "")).strip() or " ".join(level[i:i + group])[:800])
            except ValueError:
                nxt.append(" ".join(level[i:i + group])[:800])
        level = nxt
    return level[0]
