"""Course outline generation: compact prompt, tolerant parsing, retries, deterministic fallback."""
from __future__ import annotations

from pathlib import Path
from typing import Callable, Optional

from src.llm import prompts
from src.llm.base import LLMError, LLMProvider
from src.llm.validators import extract_json, salvage_items
from src.models.schemas import ChunkAnalysis, Module, Outline


def target_words(minutes: float, wpm: int) -> int:
    return int(round(minutes * wpm))


def _strs(v) -> list[str]:
    if isinstance(v, str):
        v = [v]
    return [str(x).strip() for x in v if str(x).strip()] if isinstance(v, list) else []


def _digest(analyses: list[ChunkAnalysis], max_chars: int = 3000) -> str:
    ok = [a for a in analyses if a.status == "analyzed"]
    per = max(60, max_chars // max(1, len(ok)))
    return "\n".join(f"{a.chunk_id}: {(a.summary or ' '.join(a.main_ideas))[:per]}" for a in ok)


def _n_modules(minutes: int, n_chunks: int) -> int:
    return max(3, min(8, round(minutes / 3), max(3, n_chunks)))


def parse_outline(raw: str) -> Outline:
    try:
        data = extract_json(raw)
        items = data.get("modules") if isinstance(data, dict) else None
        head = data if isinstance(data, dict) else {}
    except ValueError:
        items, head = salvage_items(raw, "modules"), {}
    mods = []
    for it in items or []:
        if not isinstance(it, dict) or not str(it.get("title", "")).strip():
            continue
        try:
            wb = int(float(it.get("word_budget", 0)))
        except (TypeError, ValueError):
            wb = 0
        mods.append(Module(module_id=f"M{len(mods) + 1}", title=str(it["title"]).strip()[:120],
                           objectives=_strs(it.get("objectives")), subtopics=_strs(it.get("subtopics")),
                           source_ids=_strs(it.get("chunks")) + _strs(it.get("source_ids")),
                           word_budget=max(0, wb), recap_points=_strs(it.get("recap_points"))))
    if not mods:
        raise ValueError("no usable modules in outline")
    return Outline(title=str(head.get("title") or "Course").strip()[:150],
                   objectives=_strs(head.get("objectives")), modules=mods)


def fallback_outline(analyses: list[ChunkAnalysis], minutes: int, title: str) -> Outline:
    """Deterministic outline built straight from the chunk analyses (no model needed)."""
    ok = [a for a in analyses if a.status == "analyzed"]
    n = min(_n_modules(minutes, len(ok)), max(1, len(ok)))
    size = -(-len(ok) // n)
    mods = []
    for i in range(0, len(ok), size):
        grp = ok[i:i + size]
        ideas = [x for a in grp for x in a.main_ideas]
        label = (ideas[0] if ideas else grp[0].summary or f"Part {len(mods) + 1}")
        label = label.split("[")[0].strip(" .:-")[:70] or f"Part {len(mods) + 1}"
        mods.append(Module(module_id=f"M{len(mods) + 1}", title=label,
                           objectives=[f"Understand: {label}"], subtopics=ideas[:4],
                           source_ids=[s for a in grp for s in a.source_ids]))
    return Outline(title=title or "Course", modules=mods)


def build_outline(analyses: list[ChunkAnalysis], summary: str, llm: LLMProvider, minutes: int,
                  wpm: int, title: str, audience: str, mode: str, source_ids: list[str],
                  intro_outro_words: int = 60, note: Optional[Callable[[str], None]] = None,
                  debug_dir: Optional[Path] = None) -> Outline:
    total = max(60, target_words(minutes, wpm) - intro_outro_words)
    ok = [a for a in analyses if a.status == "analyzed"]
    n_mod = _n_modules(minutes, len(ok))
    digest = _digest(analyses)
    outline: Optional[Outline] = None
    for attempt in range(3):
        raw = llm.generate(prompts.outline_prompt(summary, digest, title, audience, minutes, total,
                                                  mode, n_mod if attempt < 2 else 3),
                           system=prompts.SYSTEM, json_mode=True)
        try:
            outline = parse_outline(raw)
            break
        except ValueError:
            if debug_dir:
                Path(debug_dir).mkdir(parents=True, exist_ok=True)
                (Path(debug_dir) / f"outline_attempt{attempt + 1}.txt").write_text(raw, encoding="utf-8")
    if outline is None:
        if note:
            note("Model outline failed 3 times; built a simple outline directly from the chunk analyses.")
        outline = fallback_outline(analyses, minutes, title)
    # map chunk ids (and any real source ids) to valid source ids
    by_chunk = {a.chunk_id: a.source_ids for a in ok}
    valid = set(source_ids)
    for m in outline.modules:
        ids: list[str] = []
        for x in m.source_ids:
            ids += by_chunk.get(x, [x] if x in valid else [])
        m.source_ids = list(dict.fromkeys(i for i in ids if i in valid))
    if title:
        outline.title = title
    if audience:
        outline.audience = audience
    _normalize_budgets(outline, total)
    return outline


def _normalize_budgets(outline: Outline, total: int) -> None:
    s = sum(max(0, m.word_budget) for m in outline.modules)
    if s <= 0:
        for m in outline.modules:
            m.word_budget = max(40, total // len(outline.modules))
        return
    for m in outline.modules:
        m.word_budget = max(40, int(round(max(0, m.word_budget) * total / s)))


def outline_markdown(o: Outline) -> str:
    lines = [f"# {o.title}", f"*Audience: {o.audience}*", "", "## Learning objectives"]
    lines += [f"- {x}" for x in o.objectives]
    if o.prerequisites:
        lines += ["", "## Prerequisites"] + [f"- {x}" for x in o.prerequisites]
    for m in o.modules:
        lines += ["", f"## {m.module_id}: {m.title} (~{m.word_budget} words)"]
        lines += [f"- Objective: {x}" for x in m.objectives]
        lines += [f"- Topic: {x}" for x in m.subtopics]
        lines.append(f"- Sources: {', '.join(m.source_ids[:12]) or 'n/a'}{' ...' if len(m.source_ids) > 12 else ''}")
    if o.excluded_source_notes:
        lines += ["", "## Intentionally excluded"] + [f"- {x}" for x in o.excluded_source_notes]
    return "\n".join(lines) + "\n"
