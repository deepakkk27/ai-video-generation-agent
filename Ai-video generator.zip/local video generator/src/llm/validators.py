"""Parse and validate untrusted LLM JSON; repair through a bounded model request."""
from __future__ import annotations

import json
import re
from typing import Type, TypeVar

from pydantic import BaseModel, ValidationError

from src.llm.base import LLMError, LLMProvider
from src.models.schemas import Segment

T = TypeVar("T", bound=BaseModel)


def extract_json(text: str):
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.S)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    for open_c, close_c in (("{", "}"), ("[", "]")):
        s, e = text.find(open_c), text.rfind(close_c)
        if s != -1 and e > s:
            try:
                return json.loads(text[s:e + 1])
            except json.JSONDecodeError:
                continue
    raise ValueError("no valid JSON found in model output")


def salvage_items(raw: str, key: str) -> list[dict]:
    """Recover complete objects from the array under `key` in truncated JSON."""
    i = raw.find(f'"{key}"')
    j = raw.find("[", i) if i != -1 else -1
    if j == -1:
        return []
    dec, pos, out = json.JSONDecoder(), j + 1, []
    while True:
        while pos < len(raw) and raw[pos] in " \r\n\t,":
            pos += 1
        if pos >= len(raw) or raw[pos] != "{":
            break
        try:
            obj, pos = dec.raw_decode(raw, pos)
        except ValueError:
            break
        out.append(obj)
    return out


def salvage_segments(raw: str) -> list[dict]:
    return salvage_items(raw, "segments")


def parse_validated(raw: str, model: Type[T]) -> T:
    return model.model_validate(extract_json(raw))


def parse_with_repair(raw: str, model: Type[T], llm: LLMProvider, max_repairs: int = 1) -> T:
    """Validate; on failure ask the model to repair (bounded). Never returns invalid data."""
    err: Exception
    try:
        return parse_validated(raw, model)
    except (ValueError, ValidationError) as e:
        err = e
    current = raw
    for _ in range(max_repairs):
        prompt = ("The following JSON is invalid or does not match the required schema.\n"
                  f"Error: {str(err)[:600]}\n"
                  f"Required JSON schema: {json.dumps(model.model_json_schema())[:3000]}\n"
                  "Return ONLY the corrected JSON, keeping the original content.\n\n"
                  f"JSON:\n{current[:6000]}")
        current = llm.generate(prompt, json_mode=True)
        try:
            return parse_validated(current, model)
        except (ValueError, ValidationError) as e:
            err = e
    raise LLMError(f"Model output was not valid after repair: {str(err)[:300]}")


def audit_segments(segments: list[Segment], valid_source_ids: set[str],
                   source_grounded: bool) -> list[str]:
    """Return warnings about unsupported claims and bad references."""
    warnings: list[str] = []
    for s in segments:
        bad = [i for i in s.source_ids if i not in valid_source_ids]
        if bad:
            warnings.append(f"{s.segment_id}: references unknown source IDs {bad}.")
        factual = s.segment_type in ("explanation", "recap", "example", "question")
        if source_grounded and factual and not s.source_ids and not s.illustrative:
            warnings.append(f"{s.segment_id}: factual segment has no source reference.")
        if not source_grounded and s.needs_verification:
            warnings.append(f"{s.segment_id}: contains claims that need outside verification.")
        if s.illustrative and not re.search(r"\b(illustrat|for example|imagine|suppose|hypothetical)",
                                            s.narration_text, re.I):
            warnings.append(f"{s.segment_id}: illustrative content is not labelled in narration.")
    seen: dict[str, str] = {}
    for s in segments:
        key = re.sub(r"\W+", " ", s.narration_text.lower()).strip()
        if key in seen:
            warnings.append(f"{s.segment_id}: duplicates {seen[key]}.")
        seen[key] = s.segment_id
    return warnings
