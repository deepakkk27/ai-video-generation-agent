"""LLM provider interface."""
from __future__ import annotations

from abc import ABC, abstractmethod


class LLMError(Exception):
    """Raised for any LLM failure; message is user-actionable."""


class LLMProvider(ABC):
    @abstractmethod
    def health(self) -> tuple[bool, str]:
        """Return (ready, human-readable message)."""

    @abstractmethod
    def generate(self, prompt: str, system: str = "", json_mode: bool = False) -> str:
        """Return the raw model text."""
