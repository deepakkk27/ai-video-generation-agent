"""Ollama local HTTP client. Only talks to the configured local base URL."""
from __future__ import annotations

import re
import time

import requests

from src.llm.base import LLMError, LLMProvider

_THINK = re.compile(r"<think>.*?</think>", re.S)


class OllamaClient(LLMProvider):
    def __init__(self, base_url: str, model: str, num_ctx: int = 4096,
                 temperature: float = 0.2, timeout: int = 900, retries: int = 2,
                 max_tokens: int = 2048, keep_alive: str = "30m"):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.num_ctx = num_ctx
        self.temperature = temperature
        self.timeout = timeout
        self.retries = retries
        self.max_tokens = max_tokens
        self.keep_alive = keep_alive
        self.on_call = None  # optional callback(str) used to log timing per call

    def health(self) -> tuple[bool, str]:
        try:
            r = requests.get(f"{self.base_url}/api/tags", timeout=5)
            r.raise_for_status()
        except requests.RequestException:
            return False, ("Ollama is not reachable at "
                           f"{self.base_url}. Install it from https://ollama.com, start it "
                           "(run `ollama serve` or open the Ollama app), then retry.")
        names = [m.get("name", "") for m in r.json().get("models", [])]
        wanted = self.model if ":" in self.model else self.model + ":latest"
        if wanted not in names and self.model not in names:
            return False, (f"Model '{self.model}' is not downloaded. Run: ollama pull {self.model}  "
                           "(smaller options: qwen3.5:2b, qwen3.5:0.8b)")
        return True, f"Ollama ready with model {self.model}."

    def _note(self, data: dict, secs: float) -> None:
        if not self.on_call:
            return
        ec = data.get("eval_count", 0) or 0
        ed = (data.get("eval_duration", 0) or 0) / 1e9
        speed = f"{ec / ed:.1f}" if ed else "?"
        try:
            self.on_call(f"LLM call: {secs:.0f}s, prompt_tokens={data.get('prompt_eval_count', '?')}, "
                         f"output_tokens={ec}, {speed} tok/s, done_reason={data.get('done_reason')}")
        except Exception:  # noqa: BLE001
            pass

    def generate(self, prompt: str, system: str = "", json_mode: bool = False) -> str:
        payload = {
            "model": self.model, "prompt": prompt, "stream": False, "think": False,
            "keep_alive": self.keep_alive,
            "options": {"temperature": self.temperature, "num_ctx": self.num_ctx,
                        "num_predict": self.max_tokens},
        }
        if system:
            payload["system"] = system
        if json_mode:
            payload["format"] = "json"
        last: Exception | None = None
        for attempt in range(self.retries + 1):
            try:
                t0 = time.time()
                r = requests.post(f"{self.base_url}/api/generate", json=payload,
                                  timeout=self.timeout)
                if r.status_code == 404:
                    raise LLMError(f"Model '{self.model}' not found. Run: ollama pull {self.model}")
                if r.status_code >= 500:
                    raise requests.RequestException(f"server error {r.status_code}")
                r.raise_for_status()
                data = r.json()
                self._note(data, time.time() - t0)
                text = _THINK.sub("", data.get("response", "") or "").strip()
                if not text:
                    hint = (" The model spent its output on hidden 'thinking'; update Ollama."
                            if data.get("thinking") else "")
                    raise requests.RequestException(
                        f"empty response (done_reason={data.get('done_reason')}).{hint}")
                return text
            except LLMError:
                raise
            except (requests.ConnectionError, requests.Timeout, requests.RequestException) as e:
                last = e
                time.sleep(1.5 * (attempt + 1))
        raise LLMError(f"Ollama request failed after retries: {last}. Check that Ollama is running.")
