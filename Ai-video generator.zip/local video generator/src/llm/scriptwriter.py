"""Source-aware script writing.

The source is split into *units* (passages of the source, assigned in document order to modules). Each
unit is narrated from its own passage, so every segment is traceable and the whole source is used.
A unit that comes out short is expanded from its passage, and if the expansion is unusable it is
regenerated from that same passage. It is never silently accepted short without a report.
Finished units are cached on disk, so a failure never throws away completed work."""
from __future__ import annotations

import hashlib
import json
import logging
import math
import re
from pathlib import Path
from typing import Callable, Optional

from pydantic import ValidationError

from src.ingestion.chunker import _split_long
from src.llm import prompts
from src.llm.base import LLMError, LLMProvider
from src.llm.validators import audit_segments, extract_json, salvage_items
from src.models.schemas import ALLOWED_VISUALS, Chunk, ChunkAnalysis, Outline, Segment

SOURCE_RATIO = 1.2      # grounded narration may be at most ~1.2x the words of the passage it explains
EXPANDED_RATIO = 1.8    # expanded mode allows analogies/examples, so more room
UNIT_WORDS = 280        # max target words per model call (keeps output inside the token limit)
PIECE_MAX_CHARS = 3600  # max source characters per call (fits a 4096-token context)
MIN_FILL = 0.7          # a unit below this share of its target gets expansion/regeneration (top-up covers the rest)
LOG = logging.getLogger("coursegen.script")
LABEL_RE = re.compile(r"\[([A-Z]+-[A-Z]\d+)\]")


# ---------------------------------------------------------------- text helpers
def count_words(text: str) -> int:
    return len(re.findall(r"\b[\w'’-]+\b", text))


def _plain_words(text: str) -> int:
    return count_words(LABEL_RE.sub("", text))


def finalize_segment(s: Segment, wpm: float) -> Segment:
    s.word_count = count_words(s.narration_text)
    s.est_duration_s = round(s.word_count / wpm * 60, 2)
    s.caption_text = s.caption_text or s.narration_text
    s.on_screen_text = [t[:80] for t in s.on_screen_text][:5]
    return s


def _tokens(t: str) -> set[str]:
    return set(re.findall(r"[a-z0-9']+", t.lower()))


def near_duplicate(a: str, b: str, thr: float = 0.8) -> bool:
    ta, tb = _tokens(a), _tokens(b)
    if len(ta) < 6 or len(tb) < 6:
        return a.strip().lower() == b.strip().lower()
    return len(ta & tb) / len(ta | tb) >= thr


def dedupe(segs: list[Segment], against: tuple | list = ()) -> tuple[list[Segment], int]:
    """Drop segments that (nearly) repeat earlier narration. Returns (kept, dropped_count)."""
    pool = [x.narration_text for x in against]
    kept, dropped = [], 0
    for s in segs:
        if any(near_duplicate(s.narration_text, p) for p in pool):
            dropped += 1
            continue
        kept.append(s)
        pool.append(s.narration_text)
    return kept, dropped


def _total_words(segs: list[Segment]) -> int:
    return sum(s.word_count for s in segs)


# ---------------------------------------------------------------- model output parsing
def _strs_any(v, cap: int = 5) -> list[str]:
    if isinstance(v, (str, dict)):
        v = [v]
    out = []
    for x in (v if isinstance(v, list) else []):
        if isinstance(x, dict):
            x = " ".join(str(y) for y in x.values())
        x = str(x).strip()
        if x:
            out.append(x[:80])
    return out[:cap]


def _coerce_item(it: dict, module_id: str) -> Optional[dict]:
    """Accept the many shapes small models produce; return a clean dict or None."""
    nt = it.get("narration_text") or it.get("narration") or it.get("text") or it.get("script")
    if isinstance(nt, list):
        nt = " ".join(str(x) for x in nt)
    nt = str(nt or "").strip()
    if not nt:
        return None
    return {"segment_id": "tmp", "module_id": module_id, "narration_text": nt,
            "source_ids": _strs_any(it.get("source_ids"), 50),
            "segment_type": str(it.get("segment_type") or "explanation"),
            "visual_type": str(it.get("visual_type") or "bullets"),
            "visual_title": str(it.get("visual_title") or "")[:120],
            "on_screen_text": _strs_any(it.get("on_screen_text")),
            "illustrative": bool(it.get("illustrative", False)),
            "needs_verification": bool(it.get("needs_verification", False))}


def parse_segments(raw: str, module_id: str) -> list[Segment]:
    """Tolerant: any reasonable JSON shape, or complete segments salvaged from truncated output."""
    try:
        data = extract_json(raw)
        if isinstance(data, dict):
            items = data.get("segments")
            if items is None:
                items = next((v for v in data.values() if isinstance(v, list) and v and isinstance(v[0], dict)), None)
            if items is None and any(k in data for k in ("narration_text", "narration", "text")):
                items = [data]
        else:
            items = data
    except ValueError:
        items = salvage_items(raw, "segments")
    segs: list[Segment] = []
    for it in items or []:
        d = _coerce_item(it, module_id) if isinstance(it, dict) else None
        if not d:
            continue
        try:
            segs.append(Segment.model_validate(d))
        except ValidationError:
            continue
    return segs


def _plain_segments(text: str, module_id: str, title: str) -> list[Segment]:
    """Build segments from plain narration text (no JSON needed): 2 sentences per segment."""
    text = LABEL_RE.sub("", text)
    text = re.sub(r"[*#`>_]+", " ", text)
    text = re.sub(r"(?m)^\s*[-•]\s+", "", text)
    text = " ".join(text.split())
    sents = [x.strip() for x in re.split(r"(?<=[.!?])\s+", text) if len(x.split()) >= 3]
    segs = []
    for i in range(0, len(sents), 2):
        nt = " ".join(sents[i:i + 2])
        segs.append(Segment(segment_id="tmp", module_id=module_id, narration_text=nt, visual_type="bullets",
                            visual_title=title[:80], on_screen_text=[" ".join(nt.split()[:7])]))
    return segs


def _plain_ok(segs: list[Segment], piece: str, target: int) -> bool:
    """Plain-text output counts only if it is long enough and actually uses the passage's vocabulary."""
    text = " ".join(x.narration_text for x in segs)
    n = len(text.split())
    if n < 0.4 * min(target, max(1, len(piece.split()))):
        return False
    src = set(re.findall(r"[a-z]{4,}", piece.lower()))
    out = re.findall(r"[a-z]{4,}", text.lower())
    return bool(out) and sum(1 for w in out if w in src) / len(out) >= 0.3


def _extractive(piece: str, module_id: str, title: str, words: int) -> list[Segment]:
    """Last resort: narrate the passage's own sentences (faithful by construction)."""
    sents = []
    for x in re.split(r"(?<=[.!?])\s+", " ".join(LABEL_RE.sub("", piece).split())):
        w = x.split()
        sents += [" ".join(w[i:i + 30]) for i in range(0, len(w), 30) if len(w[i:i + 30]) >= 3]
    out, n = [], 0
    for x in sents:
        out.append(x)
        n += len(x.split())
        if n >= max(50, words):
            break
    return _plain_segments(" ".join(out), module_id, title)


def _dump(debug_dir: Optional[Path], name: str, raw: str) -> None:
    if not debug_dir:
        return
    try:
        Path(debug_dir).mkdir(parents=True, exist_ok=True)
        (Path(debug_dir) / name).write_text(raw, encoding="utf-8")
    except OSError:
        pass


def _gen(llm: LLMProvider, prompt: str, module_id: str, debug_dir, tag: str, tries: int) -> list[Segment]:
    for t in range(tries):
        raw = llm.generate(prompt, system=prompts.SYSTEM, json_mode=True)
        segs = parse_segments(raw, module_id)
        if segs:
            return segs
        _dump(debug_dir, f"{tag}_try{t + 1}.txt", raw)
        LOG.warning("Unusable model output for %s (try %d): %r", tag, t + 1, raw[:300])
    return []


def _clean(segs: list[Segment], piece_ids: list[str], wpm: float) -> list[Segment]:
    """Keep only source ids that really appear in the passage; attribute the rest to the passage."""
    allowed = set(piece_ids)
    for s in segs:
        s.source_ids = [i for i in s.source_ids if i in allowed] or list(piece_ids[:4])
        finalize_segment(s, wpm)
    return segs


# ---------------------------------------------------------------- planning
def allocate(budgets: list[float], caps: list[float], total: float) -> list[int]:
    """Cap each module by the material it has and hand the spare words to modules with headroom."""
    alloc = [min(b, c) for b, c in zip(budgets, caps)]
    spare = total - sum(alloc)
    head = [max(0.0, c - a) for a, c in zip(alloc, caps)]
    H = sum(head)
    if spare > 0 and H > 0:
        add = min(spare, H)
        alloc = [a + add * h / H for a, h in zip(alloc, head)]
    return [int(round(a)) for a in alloc]


def assign_chunks(outline: Outline, chunks: list[Chunk]) -> list[list[Chunk]]:
    """Give every chunk to exactly one module, in document order, so the complete source is used."""
    n_mod = len(outline.modules)
    idx_by_sid: dict[str, list[int]] = {}
    for ci, c in enumerate(chunks):
        for sid in c.source_ids:
            idx_by_sid.setdefault(sid, []).append(ci)
    owner: dict[int, int] = {}
    for mi, m in enumerate(outline.modules):
        for sid in m.source_ids:
            for ci in idx_by_sid.get(sid, []):
                owner.setdefault(ci, mi)
    last = None
    for ci in range(len(chunks)):
        if ci in owner:
            last = owner[ci]
        elif last is not None:
            owner[ci] = last
    first = owner[min(owner)] if owner else 0
    for ci in range(len(chunks)):
        owner.setdefault(ci, first)
    groups: list[list[Chunk]] = [[] for _ in range(n_mod)]
    for ci, c in enumerate(chunks):
        groups[owner[ci]].append(c)
    starts = [owner_first for owner_first in
              (min((ci for ci in owner if owner[ci] == mi), default=None) for mi in range(n_mod))]
    ordered = [x for x in starts if x is not None]
    if any(not g for g in groups) or ordered != sorted(ordered):
        groups = _proportional_groups(outline, chunks)
    return groups


def _proportional_groups(outline: Outline, chunks: list[Chunk]) -> list[list[Chunk]]:
    """Fallback: contiguous runs of chunks, sized in proportion to each module's word budget."""
    n_mod = len(outline.modules)
    w = [max(1, m.word_budget) for m in outline.modules]
    W = sum(w)
    bounds, acc = [], 0.0
    for x in w:
        acc += x / W
        bounds.append(acc)
    cw = [_plain_words(c.text) for c in chunks]
    tot = sum(cw) or 1
    groups: list[list[Chunk]] = [[] for _ in range(n_mod)]
    run = 0.0
    for c, x in zip(chunks, cw):
        mid = (run + x / 2) / tot
        run += x
        mi = next((i for i, b in enumerate(bounds) if mid <= b + 1e-9), n_mod - 1)
        groups[mi].append(c)
    return groups


def split_pieces(text: str, n: int) -> list[str]:
    n = max(1, n)
    if n == 1 and len(text) <= PIECE_MAX_CHARS + 600:
        return [text]
    size = min(PIECE_MAX_CHARS + 600, max(400, math.ceil(len(text) / n) + 150))
    paras: list[str] = []
    for p in re.split(r"\n\s*\n", text):
        p = p.strip()
        if p:
            paras += _split_long(p, size) if len(p) > size else [p]
    pieces, cur = [], ""
    for p in paras:
        if cur and len(cur) + len(p) + 2 > size:
            pieces.append(cur)
            cur = p
        else:
            cur = f"{cur}\n\n{p}".strip()
    if cur:
        pieces.append(cur)
    return pieces


def plan_units(outline: Outline, groups: list[list[Chunk]], target_total: float, mode: str):
    ratio = SOURCE_RATIO if mode == "source" else EXPANDED_RATIO
    mats = ["\n\n".join(c.text for c in g) for g in groups]
    mwords = [_plain_words(t) for t in mats]
    caps = [ratio * w for w in mwords]
    raw_b = [max(0, m.word_budget) for m in outline.modules]
    S = sum(raw_b) or 1
    alloc = allocate([b * target_total / S for b in raw_b], caps, target_total)
    plan, skipped = [], []
    last_ids: list[str] = []
    for mi, m in enumerate(outline.modules):
        if not mats[mi].strip():
            skipped.append(m.title)
            continue
        n = max(math.ceil(len(mats[mi]) / PIECE_MAX_CHARS), math.ceil(alloc[mi] / UNIT_WORDS))
        n = max(1, min(n, max(1, len(mats[mi]) // 300)))
        pieces = split_pieces(mats[mi], n)
        pw = [max(1, _plain_words(p)) for p in pieces]
        tot = sum(pw)
        for k, p in enumerate(pieces, 1):
            ids = list(dict.fromkeys(LABEL_RE.findall(p))) or last_ids
            last_ids = ids
            share = alloc[mi] * pw[k - 1] / tot
            cap = int(ratio * pw[k - 1])
            plan.append({"module_id": m.module_id, "title": m.title, "idx": k, "piece": p, "ids": ids,
                         "piece_words": pw[k - 1], "cap": cap, "target": min(cap, max(25, int(share)))})
    info = {"material_words": sum(mwords), "capacity_words": int(sum(caps)),
            "allocated_words": sum(alloc), "skipped_modules": skipped, "ratio": ratio}
    return plan, info


# ---------------------------------------------------------------- unit generation
def _expand(llm, piece, ids, existing: list[Segment], extra_words: int, mode: str, wpm: float,
            module_id: str, debug_dir, tag: str, attempts: int) -> list[Segment]:
    for att in range(attempts):
        prompt = prompts.unit_expand_prompt(piece, " ".join(s.narration_text for s in existing)[-1800:],
                                            int(extra_words), mode, ALLOWED_VISUALS)
        new = _clean(_gen(llm, prompt, module_id, debug_dir, f"{tag}_expand{att + 1}", 2), ids, wpm)
        new, _ = dedupe(new, against=existing)
        if new:
            return new
    return []


def build_unit(llm: LLMProvider, mode: str, wpm: float, u: dict, prior: str, debug_dir) -> tuple[list[Segment], dict]:
    mid, tag = u["module_id"], f"{u['module_id']}_U{u['idx']:02d}"
    target, piece, ids = u["target"], u["piece"], u["ids"]
    steps: list[str] = []
    prompt = prompts.unit_prompt(piece, target, u["title"], mode, prior, ALLOWED_VISUALS)
    segs = _clean(_gen(llm, prompt, mid, debug_dir, f"{tag}_gen", 3), ids, wpm)
    segs, d = dedupe(segs)
    steps.append(f"generate: {_total_words(segs)} words")
    # 1) source-aware expansion from the same passage
    for att in range(2):
        words = _total_words(segs)
        if words >= MIN_FILL * target:
            break
        new = _expand(llm, piece, ids, segs, target - words, mode, wpm, mid, debug_dir, tag, 1)
        steps.append(f"expand{att + 1}: +{_total_words(new)} words")
        segs += new
    # 2) expansion unusable or still short: regenerate the unit from its passage with a stronger brief
    if _total_words(segs) < MIN_FILL * target:
        alt_prompt = prompts.unit_prompt(piece, int(target * 1.4), u["title"], mode, prior, ALLOWED_VISUALS,
                                         detailed=True)
        alt = _clean(_gen(llm, alt_prompt, mid, debug_dir, f"{tag}_regen", 2), ids, wpm)
        alt, _ = dedupe(alt)
        steps.append(f"regenerate: {_total_words(alt)} words")
        if _total_words(alt) > _total_words(segs):
            segs = alt
    # 3) the model's JSON is unusable for this passage: smaller passages, then plain text, then the source itself
    if not segs:
        halves = split_pieces(piece, 2)
        got: list[Segment] = []
        if len(halves) > 1:
            for h in halves:
                got += _clean(_gen(llm, prompts.unit_prompt(h, max(25, target // 2), u["title"], mode, prior,
                                                            ALLOWED_VISUALS), mid, debug_dir, f"{tag}_half", 2), ids, wpm)
            got, _ = dedupe(got)
        steps.append(f"split-passage: {_total_words(got)} words")
        segs = got
    if not segs:
        raw = llm.generate(prompts.unit_plain_prompt(piece, target, u["title"], mode),
                           system="Use only facts stated in the source text. Reply in plain text.")
        segs = _clean(_plain_segments(raw, mid, u["title"]), ids, wpm)
        if segs and not _plain_ok(segs, piece, target):      # refusals / chatter are not narration
            _dump(debug_dir, f"{tag}_plain.txt", raw)
            segs = []
        steps.append(f"plain-text: {_total_words(segs)} words")
        if not segs:
            _dump(debug_dir, f"{tag}_plain.txt", raw)
    if not segs:
        segs = _clean(_extractive(piece, mid, u["title"], target), ids, wpm)
        steps.append(f"extractive fallback (model output unusable): {_total_words(segs)} words")
        LOG.warning("%s: model output unusable; used extractive fallback", tag)
    if not segs:
        raise LLMError(f"No narration could be built for '{u['title']}' (part {u['idx']}): the passage has no "
                       "usable sentences. Check the extracted text for this part of the source.")
    return segs, {"steps": steps, "target": target, "words": _total_words(segs), "cap": u["cap"]}


def _sig(piece: str, target: int, mode: str) -> str:
    return hashlib.sha1(f"{mode}|{target}|{piece}".encode()).hexdigest()[:12]


def _tail(segs: list[Segment]) -> str:
    return segs[-1].narration_text[-200:] if segs else ""


def write_script(outline: Outline, analyses: list[ChunkAnalysis], llm: LLMProvider, mode: str,
                 wpm: float, valid_ids: set[str], target_total_words: int,
                 progress: Optional[Callable[[int, int, str], None]] = None,
                 cache_dir: Optional[Path] = None, debug_dir: Optional[Path] = None,
                 revisions: int = 1, chunks: Optional[list[Chunk]] = None):
    """Returns (segments, warnings, report). Finished units are cached and reused on resume."""
    if chunks is None or cache_dir is None:
        raise ValueError("write_script needs the source chunks and a cache directory")
    cache = Path(cache_dir)
    cache.mkdir(parents=True, exist_ok=True)
    groups = assign_chunks(outline, chunks)
    plan, info = plan_units(outline, groups, target_total_words, mode)
    if not plan:
        raise LLMError("No source material could be assigned to the course modules.")
    names, tails, unit_reports = [], {}, []
    for n, u in enumerate(plan, 1):
        name = f"{u['module_id']}_U{u['idx']:02d}.json"
        names.append(name)
        f = cache / name
        sig = _sig(u["piece"], u["target"], mode)
        data = None
        if f.exists():
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                if data.get("sig") != sig:
                    data = None
            except (OSError, ValueError):
                data = None
        if data is None:
            segs, rep = build_unit(llm, mode, wpm, u, tails.get(u["module_id"], ""), debug_dir)
            data = {**{k: u[k] for k in ("module_id", "title", "idx", "piece", "ids", "piece_words",
                                         "target", "cap")},
                    "sig": sig, "segments": [s.model_dump() for s in segs], "report": rep}
            f.write_text(json.dumps(data), encoding="utf-8")
        last = [Segment(**x) for x in data["segments"]]
        tails[u["module_id"]] = _tail(last)
        unit_reports.append({"unit": name, **data["report"], "words": _total_words(last)})
        if progress:
            progress(n, len(plan), f"{u['title']} ({u['idx']})")
    for stale in cache.glob("M*_U*.json"):
        if stale.name not in names:
            stale.unlink(missing_ok=True)
    (cache / "plan.json").write_text(json.dumps({"units": names, "info": info}), encoding="utf-8")
    segments, dups = assemble_script(outline, cache)
    for s in segments:
        finalize_segment(s, wpm)
    words = _total_words(segments)
    warnings: list[str] = []
    if info["capacity_words"] < target_total_words * 0.97:
        warnings.append(
            f"The source supports about {info['capacity_words']} words (~{info['capacity_words'] / wpm:.1f} min) of "
            f"{'source-grounded' if mode == 'source' else 'expanded'} narration, but the target needs "
            f"{target_total_words} words. No filler was added.")
    for r in unit_reports:
        if r["words"] < MIN_FILL * r["target"] and r["words"] < r["cap"] * 0.95:
            warnings.append(f"{r['unit']} produced {r['words']} of {r['target']} target words after expansion "
                            f"and regeneration ({'; '.join(r['steps'])}).")
    for r in unit_reports:
        if any("extractive" in x or "plain-text" in x for x in r["steps"]):
            warnings.append(f"{r['unit']}: the model's structured output failed, so this part was written "
                            f"{'directly from the source text' if any('extractive' in x for x in r['steps']) else 'in plain-text mode'}; "
                            "please review it.")
    if info["skipped_modules"]:
        warnings.append("Modules with no assigned source material were skipped: "
                        + ", ".join(info["skipped_modules"]))
    if dups:
        warnings.append(f"{dups} near-duplicate narration segment(s) were removed.")
    warnings += audit_segments(segments, valid_ids, source_grounded=(mode == "source"))
    covered = sorted({i for u in plan for i in u["ids"]})
    report = {**info, "target_words": target_total_words, "actual_words": words, "duplicates_dropped": dups,
              "covered_source_ids": covered,
              "achievable_minutes": round(min(info["capacity_words"], max(words, 0)) / wpm, 1),
              "capacity_minutes": round(info["capacity_words"] / wpm, 1), "units": unit_reports}
    return segments, warnings, report


def assemble_script(outline: Outline, cache_dir) -> tuple[list[Segment], int]:
    cache = Path(cache_dir)
    names = json.loads((cache / "plan.json").read_text(encoding="utf-8"))["units"] \
        if (cache / "plan.json").exists() else sorted(p.name for p in cache.glob("M*_U*.json"))
    order = {m.module_id: i for i, m in enumerate(outline.modules)}
    units = [json.loads((cache / n).read_text(encoding="utf-8")) for n in names if (cache / n).exists()]
    units.sort(key=lambda d: (order.get(d["module_id"], 999), d["idx"]))
    segs = [Segment(**x) for d in units for x in d["segments"]]
    kept, dropped = dedupe(segs)
    counters: dict[str, int] = {}
    for s in kept:
        counters[s.module_id] = counters.get(s.module_id, 0) + 1
        s.segment_id = f"{s.module_id}-S{counters[s.module_id]:03d}"
    return kept, dropped


def top_up(cache_dir, need_words: int, llm: LLMProvider, mode: str, wpm: float,
           debug_dir=None) -> tuple[int, int]:
    """Add source-grounded narration to units that still have unused material.
    Returns (words_added, spare_capacity_words_before)."""
    cache = Path(cache_dir)
    names = json.loads((cache / "plan.json").read_text(encoding="utf-8"))["units"]
    states = []
    for n in names:
        d = json.loads((cache / n).read_text(encoding="utf-8"))
        words = sum(Segment(**x).word_count for x in d["segments"])
        states.append((d["cap"] - words, n, d))
    spare_total = sum(max(0, sp) for sp, _, _ in states)
    states.sort(key=lambda t: -t[0])
    added = 0
    for spare, n, d in states:
        if need_words - added <= 10:
            break
        if spare < 30:
            continue
        want = min(spare, need_words - added)
        segs = [Segment(**x) for x in d["segments"]]
        new = _expand(llm, d["piece"], d["ids"], segs, want, mode, wpm, d["module_id"], debug_dir,
                      n.replace(".json", "") + "_topup", 2)
        gained = _total_words(new)
        if gained:
            d["segments"] += [x.model_dump() for x in new]
            d["report"]["steps"].append(f"top-up: +{gained} words")
            (cache / n).write_text(json.dumps(d), encoding="utf-8")
            added += gained
    return added, spare_total
