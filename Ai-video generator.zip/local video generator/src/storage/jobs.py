"""JSON-manifest job storage. Job IDs are validated; all paths stay under output_dir."""
from __future__ import annotations

import json
import logging
import os
import re
import stat
import shutil
import time
from pathlib import Path

JOB_ID_RE = re.compile(r"^[0-9a-f]{32}$")
_ACTIVE: set[str] = set()  # jobs currently running inside this process


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        import ctypes
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return False
        k32.CloseHandle(h)
        return True
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


class JobError(Exception):
    pass


class JobStore:
    def __init__(self, output_dir: Path):
        self.root = Path(output_dir).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def job_dir(self, job_id: str) -> Path:
        if not JOB_ID_RE.match(job_id or ""):
            raise JobError("Invalid job id.")
        p = (self.root / job_id).resolve()
        if self.root not in p.parents:
            raise JobError("Path escapes the output directory.")
        return p

    def create(self, job_id: str) -> Path:
        d = self.job_dir(job_id)
        d.mkdir(parents=True, exist_ok=False)
        self.update(job_id, status="created", created=time.time(), stages={})
        return d

    def _manifest(self, job_id: str) -> Path:
        return self.job_dir(job_id) / "job.json"

    def load(self, job_id: str) -> dict:
        m = self._manifest(job_id)
        for _ in range(8):
            try:
                if not m.exists():
                    return {}
                return json.loads(m.read_text(encoding="utf-8"))
            except (OSError, ValueError):  # briefly locked or mid-write on Windows
                time.sleep(0.1)
        return {}

    def update(self, job_id: str, **fields) -> dict:
        data = self.load(job_id)
        data.update(fields)
        text = json.dumps(data, indent=2, default=str)
        target = self._manifest(job_id)
        tmp = target.with_suffix(".tmp")
        for _ in range(10):
            try:
                tmp.write_text(text, encoding="utf-8")
                tmp.replace(target)
                return data
            except OSError:  # WinError 5/32: another process (viewer, antivirus, sync) has it open
                time.sleep(0.15)
        try:  # last resort: write in place so progress is never fatal
            target.write_text(text, encoding="utf-8")
        except OSError:
            pass
        return data

    def set_stage(self, job_id: str, stage: str, state: str, detail: str = "") -> None:
        data = self.load(job_id)
        stages = data.get("stages", {})
        stages[stage] = {"state": state, "detail": detail, "t": time.time()}
        self.update(job_id, stages=stages)

    def list_jobs(self) -> list[dict]:
        out = []
        for d in sorted(self.root.iterdir(), reverse=True):
            if d.is_dir() and JOB_ID_RE.match(d.name):
                m = d / "job.json"
                if m.exists():
                    out.append({"job_id": d.name, **json.loads(m.read_text(encoding="utf-8"))})
        return out

    def delete(self, job_id: str) -> None:
        d = self.job_dir(job_id)
        # Windows cannot delete open files: close this job's log handlers first.
        lg = logging.getLogger(f"job.{d.name}")
        for h in list(lg.handlers):
            try:
                h.flush()
                h.close()
            except Exception:  # noqa: BLE001
                pass
            lg.removeHandler(h)

        def _retry(func, path, _exc):
            try:
                os.chmod(path, stat.S_IWRITE)
                func(path)
            except OSError:
                time.sleep(0.3)
                func(path)

        try:
            shutil.rmtree(d, onerror=_retry)
        except OSError as e:
            raise JobError(f"Could not delete the job folder (a file is still in use): {e}. "
                           "Close any video player or Explorer window using it and try again.") from e

    # simple single-job lock
    def acquire_lock(self, job_id: str) -> bool:
        """Lock file holds 'pid job_id'. A lock from a dead process, or from this process
        when no job is actually running here, is stale and gets replaced."""
        lock = self.root / ".lock"
        if lock.exists():
            try:
                pid_s, _, held_job = lock.read_text().strip().partition(" ")
                pid = int(pid_s)
            except (ValueError, OSError):
                pid, held_job = -1, ""
            if pid == os.getpid():
                stale = held_job not in _ACTIVE
            else:
                stale = not _pid_alive(pid)
            if not stale and time.time() - lock.stat().st_mtime < 6 * 3600:
                return False
        lock.write_text(f"{os.getpid()} {job_id}")
        _ACTIVE.add(job_id)
        return True

    def release_lock(self) -> None:
        lock = self.root / ".lock"
        try:
            _, _, held = lock.read_text().strip().partition(" ")
            _ACTIVE.discard(held)
        except OSError:
            pass
        lock.unlink(missing_ok=True)
