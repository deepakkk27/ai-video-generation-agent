"""Synchronization QA. A generated MP4 is NOT treated as proof of sync.

Hard checks (must pass for `sync_verified`):
  - audio clips: no gaps/overlaps beyond the planned pause, whole timeline = narration.wav length
  - shots tile the timeline with no hole/overlap and every beat has a picture
  - no picture appears before its narration (beat start / item cue), none more than one frame late
  - ffprobe: video stream, audio stream and container durations agree with the timeline
  - frame verification: frames are pulled out of the FINAL MP4 and compared with the intended PNG,
    one frame before and exactly at each sampled picture change.
Warnings (reported, do not fail): unaligned words, fallback cues, duplicate consecutive visuals, etc.
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

import numpy as np
from PIL import Image

from src.models.schemas import AudioUnit, Beat, Shot, UnitAlignment
from src.tts.audio_utils import TARGET_SR, wav_duration
from src.video import probe


def _stream_dur(info: dict, kind: str) -> float:
    for s in info.get("streams", []):
        if s.get("codec_type") == kind and s.get("duration"):
            return float(s["duration"])
    return 0.0


def _thumb(img: Image.Image) -> np.ndarray:
    return np.asarray(img.convert("L").resize((160, 90), Image.BILINEAR), dtype=np.float32)


def _decode_selected(mp4: Path, wanted: set[int], tw: int = 320, th: int = 180) -> tuple[dict[int, np.ndarray], int]:
    """Decode the FINAL MP4 once, frame by frame (no seeking, so frame n is really frame n), keeping only
    the wanted frames. Returns ({frame_index: RGB array}, total_frames_decoded)."""
    fsize = tw * th * 3
    for mode in (["-fps_mode", "passthrough"], ["-vsync", "0"]):
        cmd = ["ffmpeg", "-v", "error", "-i", str(mp4), *mode, "-vf", f"scale={tw}:{th}:flags=area,format=rgb24",
               "-f", "rawvideo", "-"]
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        got: dict[int, np.ndarray] = {}
        n = 0
        while True:
            buf = proc.stdout.read(fsize)
            if len(buf) < fsize:
                break
            if n in wanted:
                got[n] = np.frombuffer(buf, np.uint8).reshape(th, tw, 3).copy()
            n += 1
        proc.stdout.close()
        proc.wait()
        if proc.returncode == 0 and n > 0:
            return got, n
    return {}, 0


def verify_frames(mp4: Path, shots: list[Shot], fps: int, out_dir: Path, max_boundaries: int = 40) -> dict:
    """Check frames of the final MP4 around picture changes: the frame just before a change must show the
    previous shot and the frame at the change must show the new one."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    refs: dict[str, np.ndarray] = {}
    for sh in shots:
        if sh.frame_path not in refs:
            with Image.open(sh.frame_path) as im:
                refs[sh.frame_path] = _thumb(im)
    keys = list(refs)
    mat = np.stack([refs[k] for k in keys]).reshape(len(keys), -1)
    key_idx = {k: i for i, k in enumerate(keys)}

    idx = list(range(1, len(shots)))
    if len(idx) > max_boundaries:
        step = len(idx) / max_boundaries
        idx = [idx[int(i * step)] for i in range(max_boundaries)]
    wanted = {f for k in idx for f in (shots[k].start_frame - 1, shots[k].start_frame)}
    got, n_decoded = _decode_selected(mp4, wanted)
    expected_frames = shots[-1].end_frame
    rows, fails = [], []
    for k in idx:
        for label, frame, expect in (("at change", shots[k].start_frame, shots[k]),
                                     ("one frame before", shots[k].start_frame - 1, shots[k - 1])):
            rgb = got.get(frame)
            if rgb is None:
                rows.append({"shot": expect.shot_id, "check": label, "ok": False, "note": "frame not decoded"})
                fails.append(f"{expect.shot_id} {label}: frame {frame} not decoded")
                continue
            if label == "at change":
                Image.fromarray(rgb).save(out_dir / f"{expect.shot_id}_at_change.png")
            thumb = _thumb(Image.fromarray(rgb))
            d = np.abs(mat - thumb.reshape(1, -1)).mean(axis=1)
            d_exp, d_min = float(d[key_idx[expect.frame_path]]), float(d.min())
            ok = d_exp <= d_min + 1.5 and d_exp < 12.0
            best = next(s for s in shots if s.frame_path == keys[int(d.argmin())]).shot_id
            rows.append({"shot": expect.shot_id, "frame": frame, "t": round(frame / fps, 3), "check": label,
                         "ok": bool(ok), "diff_expected": round(d_exp, 2), "diff_best": round(d_min, 2),
                         "best_match": best})
            if not ok:
                fails.append(f"{expect.shot_id} {label} (frame {frame}, {frame / fps:.2f}s) shows {best} instead")
    return {"checked": len(rows), "failed": len(fails), "failures": fails, "rows": rows,
            "frames_decoded": n_decoded, "frames_planned": expected_frames}


def build_sync_report(beats: list[Beat], shots: list[Shot], units: list[AudioUnit],
                      aligns: dict[str, UnitAlignment], pause_s: float, narration_wav: Path, mp4: Path,
                      fps: int, out_dir: Path, aligner: str, aligner_message: str,
                      verify: bool = True, max_boundaries: int = 40) -> dict:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    checks: list[dict] = []
    warnings: list[str] = []

    def add(name, ok, detail=""):
        checks.append({"check": name, "passed": bool(ok), "detail": detail})

    total_s = (units[-1].end_s + pause_s) if units else 0.0
    one_sample = 1.5 / TARGET_SR

    # ---- audio gaps / overlaps ---------------------------------------------------------------
    gaps = []
    for a, b in zip(units, units[1:]):
        gap = b.start_s - a.end_s
        if abs(gap - pause_s) > one_sample:
            gaps.append(f"{a.unit_id}->{b.unit_id}: gap {gap:.4f}s (planned {pause_s:.4f}s)")
        if gap < 0:
            gaps.append(f"{a.unit_id}->{b.unit_id}: OVERLAP {-gap:.4f}s")
    add("Audio clips: no unplanned gaps or overlaps", not gaps, "; ".join(gaps[:5]))
    wav_len = wav_duration(narration_wav)
    add("narration.wav length equals the timeline", abs(wav_len - total_s) <= one_sample,
        f"wav {wav_len:.4f}s vs timeline {total_s:.4f}s")

    # ---- shots tile the timeline ---------------------------------------------------------------
    holes = []
    if not shots or shots[0].start_frame != 0:
        holes.append("first shot does not start at frame 0")
    for a, b in zip(shots, shots[1:]):
        if a.end_frame != b.start_frame:
            holes.append(f"{a.shot_id}->{b.shot_id}: hole/overlap of {b.start_frame - a.end_frame} frames")
    end_frame_expected = int(np.ceil(total_s * fps - 1e-6))
    if shots and shots[-1].end_frame != end_frame_expected:
        holes.append(f"last shot ends at frame {shots[-1].end_frame}, timeline needs {end_frame_expected}")
    add("Pictures tile the whole timeline (no hole, no overlap)", not holes, "; ".join(holes[:5]))

    # ---- visuals exist, none missing / duplicated ---------------------------------------------
    missing = [b.beat_id for b in beats if not b.visual_asset or not Path(b.visual_asset).exists()]
    add("Every beat has a visual", not missing, f"missing={missing[:5]}")
    dups = []
    for a, b in zip(beats, beats[1:]):
        if a.visual_type == b.visual_type and a.visual_title == b.visual_title and a.items == b.items and a.items:
            dups.append(f"{a.beat_id}={b.beat_id}")
    if dups:
        warnings.append(f"Consecutive beats show identical visuals: {dups[:5]}")

    # ---- never early, at most one frame late -------------------------------------------------
    early, late = [], []
    first_shot = {}
    for sh in shots:
        first_shot.setdefault(sh.beat_id, sh)
    for b in beats:
        sh = first_shot.get(b.beat_id)
        if sh is None:
            continue
        if sh.start_s < b.start_s - 1e-6:
            early.append(f"{b.beat_id} picture {b.start_s - sh.start_s:.3f}s early")
        if sh.start_s > b.start_s + 1.0 / fps + 1e-6:
            late.append(f"{b.beat_id} picture {sh.start_s - b.start_s:.3f}s late")
    cue_by_shot = {}
    for b in beats:
        for c in b.cues:
            sh = next((s for s in shots if s.beat_id == b.beat_id and s.start_s + 1e-6 >= c.time_s
                       and s.revealed > c.index), None)
            if sh is None:
                continue
            if sh.start_s < c.time_s - 1e-6:
                early.append(f"{b.beat_id} item '{c.text}' {c.time_s - sh.start_s:.3f}s early")
            elif sh.start_s > c.time_s + 1.0 / fps + 1e-6:
                late.append(f"{b.beat_id} item '{c.text}' {sh.start_s - c.time_s:.3f}s late")
    add("No visual appears before its narration", not early, "; ".join(early[:5]))
    add("No visual is more than one frame late", not late, "; ".join(late[:5]))

    # ---- final MP4 (ffprobe) ------------------------------------------------------------------
    info = probe.probe(mp4)
    v_dur, a_dur = _stream_dur(info, "video"), _stream_dur(info, "audio")
    f_dur = float(info.get("format", {}).get("duration", 0) or 0)
    tol = 2.0 / fps + 0.06
    add("MP4 video stream length matches the timeline", abs(v_dur - total_s) <= tol,
        f"video {v_dur:.3f}s vs timeline {total_s:.3f}s")
    add("MP4 audio stream length matches the timeline", abs(a_dur - total_s) <= 0.08,
        f"audio {a_dur:.3f}s vs timeline {total_s:.3f}s")
    add("MP4 audio and video end together", abs(v_dur - a_dur) <= tol + 0.05,
        f"video {v_dur:.3f}s, audio {a_dur:.3f}s")

    # ---- alignment ----------------------------------------------------------------------------
    unaligned, failed_units, low = [], [], []
    for u in units:
        al = aligns.get(u.unit_id)
        if al is None or al.status in ("failed", "unavailable"):
            failed_units.append(f"{u.unit_id}:{al.status if al else 'missing'}")
            continue
        for w in al.words:
            if not w.aligned:
                unaligned.append(f"{u.unit_id}:{w.word}")
            elif w.score is not None and w.score < 0.2:
                low.append(f"{u.unit_id}:{w.word}({w.score:.2f})")
    word_level = bool(units) and not failed_units and aligner != "none"
    if aligner == "none":
        warnings.append("WORD-LEVEL ALIGNMENT WAS NOT USED (aligner unavailable): " + aligner_message)
    elif failed_units:
        warnings.append(f"Alignment failed for {len(failed_units)} clip(s); those use sentence-level timing "
                        f"from the real clip length: {failed_units[:5]}")
    if unaligned:
        warnings.append(f"{len(unaligned)} word(s) could not be aligned (no time invented): {unaligned[:8]}")
    if low:
        warnings.append(f"{len(low)} low-confidence word time(s): {low[:8]}")
    for b in beats:
        for w in b.warnings:
            warnings.append(f"{b.beat_id}: {w}")

    # ---- frames pulled from the final MP4 ----------------------------------------------------
    frame_check = {"checked": 0, "failed": 0, "failures": [], "rows": []}
    if verify and len(shots) > 1:
        frame_check = verify_frames(mp4, shots, fps, out_dir / "verify_frames", max_boundaries)
        add("Frames decoded from the final MP4 show the planned visuals", frame_check["failed"] == 0,
            f"{frame_check['checked']} frames checked; " + "; ".join(frame_check["failures"][:4]))
        add("MP4 contains exactly the planned number of frames",
            frame_check["frames_decoded"] == frame_check["frames_planned"],
            f"decoded {frame_check['frames_decoded']} vs planned {frame_check['frames_planned']}")

    # ---- per-beat table ------------------------------------------------------------------------
    unit_by_id = {u.unit_id: u for u in units}
    beat_rows = []
    for b in beats:
        bs = [s for s in shots if s.beat_id == b.beat_id]
        words = []
        miss = []
        for uid in b.unit_ids:
            u, al = unit_by_id[uid], aligns.get(uid)
            for w in (al.words if al else []):
                words.append({"unit": uid, "word": w.word,
                              "start_s": None if w.start is None else round(u.start_s + w.start, 3),
                              "end_s": None if w.end is None else round(u.start_s + w.end, 3),
                              "score": w.score})
                if not w.aligned:
                    miss.append(w.word)
        beat_rows.append({
            "beat_id": b.beat_id, "narration": b.narration_text, "audio_duration_s": b.audio_duration_s,
            "alignment_status": b.alignment_status, "words": words, "unaligned_words": miss,
            "visual_asset": b.visual_asset, "visual_description": b.visual_description,
            "visual_start_s": bs[0].start_s if bs else None, "visual_end_s": bs[-1].end_s if bs else None,
            "narration_start_s": b.start_s,
            "item_cues": [c.model_dump() for c in b.cues],
            "shots": [{"id": s.shot_id, "start_s": s.start_s, "end_s": s.end_s, "revealed": s.revealed,
                       "trigger": s.trigger} for s in bs],
            "llm_grounded": b.llm_grounded, "warnings": b.warnings})

    hard_ok = all(c["passed"] for c in checks)
    verified = hard_ok and frame_check["checked"] > 0
    report = {
        "sync_verified": bool(verified), "word_level_alignment_used": word_level, "aligner": aligner,
        "checks": checks, "warnings": warnings,
        "final": {"timeline_s": round(total_s, 3), "narration_wav_s": round(wav_len, 3),
                  "mp4_container_s": round(f_dur, 3), "mp4_video_s": round(v_dur, 3),
                  "mp4_audio_s": round(a_dur, 3)},
        "frame_verification": frame_check, "beats": beat_rows,
        "note": "Automated timing/visual checks. They cannot judge whether a picture is the best explanation; "
                "watch the video."}
    (out_dir / "sync_report.json").write_text(json.dumps(report, indent=1), encoding="utf-8")
    (out_dir / "sync_report.md").write_text(sync_markdown(report), encoding="utf-8")
    return report


def sync_markdown(r: dict) -> str:
    L = ["# Synchronization QA report", "",
         f"**Result: {'VERIFIED' if r['sync_verified'] else 'NOT VERIFIED'}** · word-level alignment used: "
         f"**{'yes' if r['word_level_alignment_used'] else 'NO'}** (aligner: {r['aligner']})", ""]
    f = r["final"]
    L += [f"Timeline {f['timeline_s']}s · narration.wav {f['narration_wav_s']}s · MP4 container {f['mp4_container_s']}s "
          f"(video {f['mp4_video_s']}s / audio {f['mp4_audio_s']}s)", "", "## Checks"]
    L += [f"- [{'x' if c['passed'] else ' '}] {c['check']}" + (f" — {c['detail']}" if c["detail"] else "") for c in r["checks"]]
    if r["warnings"]:
        L += ["", "## Warnings"] + [f"- {w}" for w in r["warnings"]]
    L += ["", "## Beats", "", "| Beat | Narration | Audio s | Visual shown (s) | Alignment | Unaligned words |", "|---|---|---|---|---|---|"]
    for b in r["beats"]:
        vs, ve = b["visual_start_s"], b["visual_end_s"]
        L.append(f"| {b['beat_id']} | {b['narration'][:70].replace('|', '/')}… | {b['audio_duration_s']:.2f} | "
                 f"{vs:.2f}–{ve:.2f} | {b['alignment_status']} | {', '.join(b['unaligned_words'][:5]) or '-'} |")
    L += ["", "## Item reveal times", ""]
    for b in r["beats"]:
        for c in b["item_cues"]:
            L.append(f"- {b['beat_id']} · **{c['text']}** at {c['time_s']:.2f}s ({c['method']}"
                     + (f", word '{c['anchor_word']}'" if c["anchor_word"] else "") + ")")
    L += ["", f"_{r['note']}_", ""]
    return "\n".join(L)
