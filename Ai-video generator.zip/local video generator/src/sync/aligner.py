"""Forced alignment of the exact Kokoro narration text against the exact generated audio.

WhisperX is used in forced-alignment mode only: the transcript is the text Kokoro already spoke, so no
speech recognition (Whisper ASR) and no diarization is run, and no model other than the small wav2vec2
alignment model is loaded. Everything is local and runs on CPU.

Words the aligner cannot place (digits, symbols, out-of-vocabulary tokens) are returned with
start/end = None. Their time is never guessed.
"""
from __future__ import annotations

import hashlib
import json
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional

from src.models.schemas import AlignedWord, UnitAlignment

log = logging.getLogger("sync.align")

INSTALL_HELP = ("WhisperX is not installed. Run:  pip install whisperx   (see README_SYNC.md). "
                "Without it the video is still scheduled from the real audio clip lengths, but "
                "on-screen items can only change at sentence boundaries.")


class Aligner(ABC):
    name = "base"

    @abstractmethod
    def availability(self) -> tuple[bool, str]:
        ...

    @abstractmethod
    def align(self, wav: Path, text: str, duration_s: float, unit_id: str) -> UnitAlignment:
        ...


def _check_words(words: list[AlignedWord], duration_s: float) -> tuple[list[AlignedWord], list[str]]:
    """Drop timestamps that are impossible (outside the clip or going backwards)."""
    issues: list[str] = []
    prev = 0.0
    for w in words:
        if not w.aligned:
            continue
        if w.start is None or w.end is None or w.start < -0.02 or w.end > duration_s + 0.25 or w.end < w.start:
            issues.append(f"'{w.word}' outside clip")
            w.start = w.end = None
            w.aligned = False
            continue
        if w.start < prev - 0.05:
            issues.append(f"'{w.word}' goes backwards")
            w.start = w.end = None
            w.aligned = False
            continue
        prev = max(prev, w.start)
    return words, issues


class WhisperXAligner(Aligner):
    name = "whisperx"

    def __init__(self, language: str = "en", device: str = "cpu", model_dir: Optional[Path] = None):
        self.language = language
        self.device = device
        self.model_dir = Path(model_dir) if model_dir else None
        self._model = None
        self._meta = None
        self._wx = None

    # -- setup ---------------------------------------------------------------------------------
    def availability(self) -> tuple[bool, str]:
        try:
            import whisperx  # noqa: F401
        except Exception as e:  # noqa: BLE001  (ImportError, or a torch/DLL problem on Windows)
            return False, f"{INSTALL_HELP} ({type(e).__name__}: {e})"
        ok, msg = self._language_supported()
        return ok, msg

    def _language_supported(self) -> tuple[bool, str]:
        try:
            from whisperx import alignment as A
            known = set(getattr(A, "DEFAULT_ALIGN_MODELS_TORCH", {})) | set(getattr(A, "DEFAULT_ALIGN_MODELS_HF", {}))
            if known and self.language not in known:
                return False, f"WhisperX has no alignment model for language '{self.language}'."
        except Exception:  # noqa: BLE001  attribute layout differs between versions; load_align_model will tell
            pass
        return True, f"WhisperX alignment ready (language={self.language}, device={self.device})."

    def _load(self):
        if self._model is None:
            import whisperx
            self._wx = whisperx
            kw = {}
            if self.model_dir:  # the alignment model is downloaded once into this folder and reused offline
                self.model_dir.mkdir(parents=True, exist_ok=True)
                kw["model_dir"] = str(self.model_dir)
            self._model, self._meta = whisperx.load_align_model(
                language_code=self.language, device=self.device, **kw)
        return self._model, self._meta

    # -- alignment -----------------------------------------------------------------------------
    def align(self, wav: Path, text: str, duration_s: float, unit_id: str) -> UnitAlignment:
        tokens = text.split()
        try:
            model, meta = self._load()
            audio = self._wx.load_audio(str(wav))  # 16 kHz mono float32 (uses ffmpeg)
            res = self._wx.align([{"text": text, "start": 0.0, "end": float(duration_s)}], model, meta,
                                 audio, self.device, return_char_alignments=False)
        except Exception as e:  # noqa: BLE001
            log.warning("alignment failed for %s: %s", unit_id, e)
            return UnitAlignment(unit_id=unit_id, status="failed", aligner=self.name,
                                 note=f"{type(e).__name__}: {e}",
                                 words=[AlignedWord(word=t) for t in tokens])
        raw = [w for seg in res.get("segments", []) for w in seg.get("words", [])]
        words = [AlignedWord(word=str(w.get("word", "")), start=w.get("start"), end=w.get("end"),
                             score=w.get("score"),
                             aligned=w.get("start") is not None and w.get("end") is not None) for w in raw]
        note = ""
        if [w.word for w in words] != tokens:
            # WhisperX re-splits some tokens; keep its words (they carry the times) but say so.
            note = f"word list differs from text ({len(words)} vs {len(tokens)} tokens)"
        words, issues = _check_words(words, duration_s)
        n_al = sum(w.aligned for w in words)
        status = "ok" if words and n_al == len(words) else ("partial" if n_al else "failed")
        if issues:
            note = (note + "; " if note else "") + "; ".join(issues[:4])
        return UnitAlignment(unit_id=unit_id, status=status, aligner=self.name, note=note, words=words)


class NullAligner(Aligner):
    """Used when no aligner is installed. Produces no word times (status 'unavailable')."""
    name = "none"

    def __init__(self, reason: str = INSTALL_HELP):
        self.reason = reason

    def availability(self) -> tuple[bool, str]:
        return False, self.reason

    def align(self, wav: Path, text: str, duration_s: float, unit_id: str) -> UnitAlignment:
        return UnitAlignment(unit_id=unit_id, status="unavailable", aligner=self.name, note=self.reason,
                             words=[AlignedWord(word=t) for t in text.split()])


def make_aligner(voice: str, device: str, model_dir: Path) -> Aligner:
    """Kokoro voices start with 'a'/'b' (American/British English). Other prefixes map to their language."""
    lang = {"a": "en", "b": "en", "e": "es", "f": "fr", "h": "hi", "i": "it", "j": "ja",
            "p": "pt", "z": "zh"}.get((voice or "a")[:1], "en")
    al = WhisperXAligner(lang, device, model_dir)
    ok, msg = al.availability()
    return al if ok else NullAligner(msg)


def align_units(units, aligner: Aligner, cache_dir: Path, progress=None) -> dict[str, UnitAlignment]:
    """Align every audio unit once; results are cached per (text, audio length, aligner)."""
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)
    out: dict[str, UnitAlignment] = {}
    for i, u in enumerate(units, 1):
        key = hashlib.sha1(f"{aligner.name}|{u.text}|{u.duration_s:.4f}".encode()).hexdigest()[:16]
        f = cache_dir / f"{u.unit_id}.json"
        hit = None
        if f.exists():
            try:
                d = json.loads(f.read_text(encoding="utf-8"))
                if d.get("key") == key:
                    hit = UnitAlignment.model_validate(d["alignment"])
            except (ValueError, OSError):
                hit = None
        if hit is None:
            hit = aligner.align(Path(u.wav_path), u.text, u.duration_s, u.unit_id)
            if hit.status != "unavailable":
                f.write_text(json.dumps({"key": key, "alignment": hit.model_dump()}), encoding="utf-8")
        out[u.unit_id] = hit
        if progress:
            progress(i, len(units), u.unit_id)
    return out
