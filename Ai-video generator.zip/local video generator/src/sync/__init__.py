"""Narration-led synchronization: WhisperX alignment -> item cues -> one shared timeline."""
