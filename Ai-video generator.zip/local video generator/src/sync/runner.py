"""Glue: align every clip, resolve item cues, build the shared timeline, persist the sync artifacts."""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from src.llm.base import LLMProvider
from src.models.schemas import AudioUnit, Beat, Segment, Shot, UnitAlignment
from src.sync.aligner import Aligner, align_units, make_aligner
from src.sync.cues import Breaker, Resolved, resolve_cues
from src.sync.timeline import build_timeline

log = logging.getLogger("sync")
Progress = Callable[[float, str], None]   # (fraction 0-1 of the sync-planning phase, detail)


@dataclass
class SyncPlan:
    beats: list[Beat]
    shots: list[Shot]
    aligns: dict[str, UnitAlignment]
    aligner: str
    aligner_message: str
    total_s: float


def plan_sync(segments: list[Segment], units: list[AudioUnit], pause_s: float, job_dir: Path, voice: str,
              device: str, model_dir: Path, fps: int, llm: Optional[LLMProvider], use_llm_cues: bool,
              progress: Optional[Progress] = None, aligner: Optional[Aligner] = None) -> SyncPlan:
    job_dir = Path(job_dir)
    sdir = job_dir / "sync"
    sdir.mkdir(parents=True, exist_ok=True)
    aligner = aligner or make_aligner(voice, device, model_dir)
    ok, msg = aligner.availability()
    log.info("Aligner %s: %s", aligner.name, msg)

    aligns = align_units(units, aligner, sdir / "align",
                         (lambda i, n, u: progress(0.5 * i / n, f"aligning {i}/{n}")) if progress else None)

    by_seg: dict[str, list[AudioUnit]] = {}
    for u in units:
        by_seg.setdefault(u.segment_id, []).append(u)
    seg_by_id = {s.segment_id: s for s in segments}
    resolved: dict[str, Resolved] = {}
    breaker = Breaker()
    for i, (sid, su) in enumerate(by_seg.items(), 1):
        resolved[sid] = resolve_cues(seg_by_id[sid], su, aligns, llm if use_llm_cues else None,
                                     sdir / "cues", breaker)
        if progress:
            progress(0.5 + 0.5 * i / len(by_seg), f"matching visuals {i}/{len(by_seg)}")

    total_s = (units[-1].end_s + pause_s) if units else 0.0
    beats, shots = build_timeline(segments, units, aligns, resolved, fps, total_s)
    plan = SyncPlan(beats, shots, aligns, aligner.name, msg, total_s)
    (sdir / "alignment.json").write_text(
        json.dumps({k: v.model_dump() for k, v in aligns.items()}, indent=1), encoding="utf-8")
    return plan


def save_plan(plan: SyncPlan, job_dir: Path) -> None:
    sdir = Path(job_dir) / "sync"
    (sdir / "beats.json").write_text(json.dumps([b.model_dump() for b in plan.beats], indent=1), encoding="utf-8")
    (sdir / "shots.json").write_text(json.dumps([s.model_dump() for s in plan.shots], indent=1), encoding="utf-8")
