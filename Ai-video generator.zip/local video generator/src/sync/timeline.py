"""One shared timeline: audio clips and pictures are both positioned from the same measured data.

Source of truth = the measured length of every Kokoro clip (sample exact) + WhisperX word times.
Nothing is estimated from a speaking speed and nothing is fixed-length.

Rules enforced here
  * a beat's first picture appears exactly when its first sentence starts (never before);
  * a picture stays until the next beat's narration starts (the silence between clips belongs to the
    sentence just spoken, so the viewer never sees the next visual before its narration begins);
  * an item is revealed at the frame that contains its cue word, rounded UP to the next frame, so a visual
    is never early and at most one frame (1/fps s) late; frame positions are computed from absolute times,
    so rounding never accumulates;
  * no fades or transitions that would delay a visual.
"""
from __future__ import annotations

import math
from typing import Optional

from src.models.schemas import AudioUnit, Beat, Segment, Shot, UnitAlignment
from src.sync.cues import REVEAL_TYPES, Resolved


def to_frame(t: float, fps: int) -> int:
    return int(math.ceil(t * fps - 1e-6))


def _status(units: list[AudioUnit], aligns: dict[str, UnitAlignment]) -> str:
    st = [aligns[u.unit_id].status if u.unit_id in aligns else "unavailable" for u in units]
    if all(s == "ok" for s in st):
        return "ok"
    if all(s == "unavailable" for s in st):
        return "unavailable"
    return "failed" if all(s in ("failed", "unavailable") for s in st) else "partial"


def build_timeline(segments: list[Segment], units: list[AudioUnit], aligns: dict[str, UnitAlignment],
                   resolved: dict[str, Resolved], fps: int, total_s: float) -> tuple[list[Beat], list[Shot]]:
    seg_by_id = {s.segment_id: s for s in segments}
    order: list[str] = []
    by_seg: dict[str, list[AudioUnit]] = {}
    for u in units:
        if u.segment_id not in by_seg:
            order.append(u.segment_id)
        by_seg.setdefault(u.segment_id, []).append(u)

    beats: list[Beat] = []
    shots: list[Shot] = []
    pending: list[tuple[int, Shot]] = []          # (start_frame, shot) in timeline order
    for bi, sid in enumerate(order):
        seg, su = seg_by_id[sid], by_seg[sid]
        res = resolved.get(sid) or Resolved([t for t in seg.on_screen_text if t.strip()][:5], [], False, [])
        reveals = seg.visual_type in REVEAL_TYPES and bool(res.cues)
        beat_id = f"B{bi + 1:04d}-{sid}"
        beat_start = su[0].start_s
        beat_end = by_seg[order[bi + 1]][0].start_s if bi + 1 < len(order) else total_s
        title = seg.visual_title or ""
        beats.append(Beat(
            beat_id=beat_id, segment_id=sid, module_id=seg.module_id, narration_text=" ".join(u.text for u in su),
            source_ids=seg.source_ids, visual_type=seg.visual_type, visual_title=title, items=res.items,
            cues=res.cues, visual_description=f"{seg.visual_type}: {title}" + (f" | {'; '.join(res.items)}" if res.items else ""),
            audio_files=[u.wav_path for u in su], unit_ids=[u.unit_id for u in su],
            audio_duration_s=round(sum(u.duration_s for u in su), 4), start_s=beat_start, end_s=beat_end,
            alignment_status=_status(su, aligns), llm_grounded=res.llm_grounded, warnings=list(res.warnings)))

        # events inside the beat: (time, trigger, unit)
        ev: list[tuple[float, str, AudioUnit]] = [(su[0].start_s, "segment_start", su[0])]
        ev += [(u.start_s, "unit_start", u) for u in su[1:]]
        ev += [(c.time_s, "item_cue", next((u for u in reversed(su) if u.start_s <= c.time_s + 1e-9), su[0]))
               for c in res.cues]
        ev.sort(key=lambda e: (e[0], {"segment_start": 0, "unit_start": 1, "item_cue": 2}[e[1]]))
        for t, trig, _u in ev:
            unit = next(u for u in reversed(su) if u.start_s <= t + 1e-9)
            n_rev = sum(1 for c in res.cues if c.time_s <= t + 1e-9) if reveals else len(res.items)
            frame = 0 if (bi == 0 and trig == "segment_start") else to_frame(t, fps)
            pending.append((frame, Shot(shot_id="", beat_id=beat_id, unit_id=unit.unit_id, caption=unit.text,
                                        revealed=n_rev, start_s=t, trigger=trig)))

    # collapse events that land on the same frame (the later state wins), drop no-ops, set end frames
    collapsed: list[tuple[int, Shot]] = []
    for fr, sh in pending:
        if collapsed and collapsed[-1][0] == fr:
            collapsed[-1] = (fr, sh)
        else:
            collapsed.append((fr, sh))
    end_frame = to_frame(total_s, fps)
    n_in_beat: dict[str, int] = {}
    for i, (fr, sh) in enumerate(collapsed):
        nxt = collapsed[i + 1][0] if i + 1 < len(collapsed) else end_frame
        if nxt <= fr:
            continue
        n_in_beat[sh.beat_id] = n_in_beat.get(sh.beat_id, 0) + 1
        sh.shot_id = f"{sh.beat_id}-K{n_in_beat[sh.beat_id]:02d}"
        sh.start_frame, sh.end_frame = fr, nxt
        sh.start_s, sh.end_s = fr / fps, nxt / fps
        shots.append(sh)
    return beats, shots
