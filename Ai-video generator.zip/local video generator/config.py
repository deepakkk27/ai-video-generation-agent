"""Central configuration loaded from environment / .env with safe validation."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _load_dotenv() -> None:
    env = ROOT / ".env"
    if not env.exists():
        return
    for line in env.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip())


def _int(name: str, default: int, lo: int, hi: int) -> int:
    try:
        val = int(os.environ.get(name, default))
    except ValueError:
        val = default
    return max(lo, min(hi, val))


def _float(name: str, default: float, lo: float, hi: float) -> float:
    try:
        val = float(os.environ.get(name, default))
    except ValueError:
        val = default
    return max(lo, min(hi, val))


@dataclass(frozen=True)
class Settings:
    ollama_base_url: str
    ollama_model: str
    ollama_num_ctx: int
    ollama_temperature: float
    default_duration_minutes: int
    max_duration_minutes: int
    duration_tolerance_percent: float
    tts_provider: str
    tts_voice: str
    video_width: int
    video_height: int
    video_fps: int
    fallback_video_width: int
    fallback_video_height: int
    max_upload_mb: int
    keep_intermediates: bool
    output_dir: Path
    temp_dir: Path
    words_per_minute: int = 130
    pause_between_units_s: float = 0.35
    max_script_revisions: int = 2
    sync_enabled: bool = True          # narration-led visual timeline (WhisperX + cues)
    sync_use_llm_cues: bool = True     # ask the local LLM to ground on-screen items in the narration
    align_device: str = "cpu"
    align_model_dir: Path = Path("models")


def load_settings() -> Settings:
    _load_dotenv()
    g = os.environ.get
    out = Path(g("OUTPUT_DIR", "outputs"))
    tmp = Path(g("TEMP_DIR", "temp"))
    out = out if out.is_absolute() else ROOT / out
    tmp = tmp if tmp.is_absolute() else ROOT / tmp
    provider = g("TTS_PROVIDER", "kokoro").lower()
    if provider not in ("kokoro", "piper"):
        provider = "kokoro"
    return Settings(
        ollama_base_url=g("OLLAMA_BASE_URL", "http://localhost:11434").rstrip("/"),
        ollama_model=g("OLLAMA_MODEL", "qwen3.5:4b"),
        ollama_num_ctx=_int("OLLAMA_NUM_CTX", 4096, 1024, 32768),
        ollama_temperature=_float("OLLAMA_TEMPERATURE", 0.2, 0.0, 1.0),
        default_duration_minutes=_int("DEFAULT_DURATION_MINUTES", 10, 1, 10000),
        max_duration_minutes=_int("MAX_DURATION_MINUTES", 180, 1, 10000),
        duration_tolerance_percent=_float("DURATION_TOLERANCE_PERCENT", 3, 0.5, 50),
        tts_provider=provider,
        tts_voice=g("TTS_VOICE", ""),
        video_width=_int("VIDEO_WIDTH", 1920, 320, 7680),
        video_height=_int("VIDEO_HEIGHT", 1080, 240, 4320),
        video_fps=_int("VIDEO_FPS", 25, 5, 60),
        fallback_video_width=_int("FALLBACK_VIDEO_WIDTH", 1280, 320, 7680),
        fallback_video_height=_int("FALLBACK_VIDEO_HEIGHT", 720, 240, 4320),
        max_upload_mb=_int("MAX_UPLOAD_MB", 512, 1, 10000),
        keep_intermediates=g("KEEP_INTERMEDIATES", "true").lower() in ("1", "true", "yes"),
        output_dir=out,
        temp_dir=tmp,
        sync_enabled=g("SYNC_ENABLED", "true").lower() in ("1", "true", "yes"),
        sync_use_llm_cues=g("SYNC_USE_LLM_CUES", "true").lower() in ("1", "true", "yes"),
        align_device=g("ALIGN_DEVICE", "cpu").lower(),
        align_model_dir=(lambda p: p if p.is_absolute() else ROOT / p)(Path(g("ALIGN_MODEL_DIR", "models"))),
    )


SETTINGS = load_settings()
