"""One-off environment check for the WhisperX integration:  python check_sync_env.py
Imports torch/torchaudio/kokoro/whisperx, downloads the English alignment model into ./models (first run only,
needs internet once), synthesizes one Kokoro sentence and force-aligns it. Prints every step."""
import sys
import tempfile
from pathlib import Path

from config import SETTINGS as S


def step(msg):
    print(f"- {msg} ...", end=" ", flush=True)


def main() -> int:
    for mod in ("torch", "torchaudio", "kokoro", "whisperx"):
        step(f"import {mod}")
        try:
            m = __import__(mod)
            print("ok", getattr(m, "__version__", ""))
        except Exception as e:  # noqa: BLE001
            print("FAILED:", e)
            return 1
    from src.sync.aligner import make_aligner
    from src.tts.factory import make_tts
    tts = make_tts(S.tts_provider, S.tts_voice)
    al = make_aligner(tts.voice, S.align_device, S.align_model_dir)
    step("aligner availability")
    ok, msg = al.availability()
    print(msg)
    if not ok:
        return 1
    text = "First, initialize the centroids. Then assign every point to its nearest centroid."
    with tempfile.TemporaryDirectory() as td:
        wav = Path(td) / "t.wav"
        step("Kokoro sample")
        tts.synthesize(text, wav)
        from src.tts.audio_utils import wav_duration
        dur = wav_duration(wav)
        print(f"{dur:.2f}s")
        step("force-align (first run downloads the model into %s)" % S.align_model_dir)
        r = al.align(wav, text, dur, "check")
        print(r.status, r.note)
    for w in r.words:
        print(f"   {w.word:12s} {w.start if w.start is not None else '--':>6} {w.end if w.end is not None else '--':>6}")
    return 0 if r.status == "ok" else 1


if __name__ == "__main__":
    sys.exit(main())
