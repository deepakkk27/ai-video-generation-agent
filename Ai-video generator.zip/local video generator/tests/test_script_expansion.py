"""Regression tests for the 'script expansion returned nothing usable -> 6.7 min video' failure."""
import json
import re

from src.ingestion.chunker import chunk_records
from src.llm.scriptwriter import (allocate, assemble_script, assign_chunks, dedupe, near_duplicate,
                                  top_up, write_script)
from src.models.schemas import Module, Outline, Segment, SourceRecord

WPM = 130.0


def make_chunks(n_records=24, words_per=140):
    recs = [SourceRecord(source_id=f"PDF-P{i:04d}", kind="pdf", index=i,
                         text=" ".join(_tok(i * 1000 + j) for j in range(words_per)))
            for i in range(1, n_records + 1)]
    return recs, chunk_records(recs, max_chars=3000)


def make_outline(n_mod=3, budget=300):
    return Outline(title="T", modules=[Module(module_id=f"M{i}", title=f"Mod {i}", word_budget=budget)
                                       for i in range(1, n_mod + 1)])


def _tok(i):
    """Unique letters-only word (the tokenizer ignores digits and underscores)."""
    s = ""
    while True:
        s = chr(97 + i % 26) + s
        i //= 26
        if i == 0:
            return "w" + s


class FakeLLM:
    """Behaviours: base_factor (share of requested words returned for the first request),
    expand_ok (does an expansion request return usable output?), regen_factor."""
    counter = 0

    def __init__(self, base_factor=1.0, expand_ok=True, regen_factor=1.0, duplicate=False):
        self.base_factor, self.expand_ok, self.regen_factor = base_factor, expand_ok, regen_factor
        self.duplicate = duplicate
        self.calls = 0
        self.kinds = []

    def health(self):
        return True, "ok"

    def _narr(self, n):
        FakeLLM.counter += 1
        if self.duplicate:
            return " ".join(["same words repeated again and again"] * max(1, n // 6))
        words = [_tok(FakeLLM.counter * 1000 + j) for j in range(max(6, n))]
        return ". ".join(" ".join(words[i:i + 12]) for i in range(0, len(words), 12)) + "."

    def generate(self, prompt, system="", json_mode=False):
        self.calls += 1
        n = int(re.search(r"about (\d+) words", prompt).group(1))
        ids = re.findall(r"\[([A-Z]+-[A-Z]\d+)\]", prompt)
        if "Write NEW narration" in prompt:
            self.kinds.append("expand")
            if not self.expand_ok:
                return "sorry, I can't do that"
            text = self._narr(n)
        elif "Cover EVERY definition" in prompt:
            self.kinds.append("regen")
            text = self._narr(int(n * self.regen_factor))
        else:
            self.kinds.append("base")
            text = self._narr(int(n * self.base_factor))
        return json.dumps({"segments": [{"narration_text": text, "source_ids": ids[:1],
                                         "visual_type": "bullets", "visual_title": "x", "on_screen_text": ["a"]}]})


def run(llm, tmp_path, target=600, chunks=None, outline=None, mode="source"):
    recs, ch = make_chunks() if chunks is None else chunks
    outline = outline or make_outline()
    valid = {r.source_id for r in recs}
    return write_script(outline, [], llm, mode, WPM, valid, target, cache_dir=tmp_path / "u",
                        debug_dir=tmp_path / "dbg", chunks=ch), outline, valid


def test_near_duplicate_and_dedupe():
    a = "The mean is the sum of all values divided by the count of values in the set."
    b = "The mean is the sum of all values divided by the count of the values in the set."
    assert near_duplicate(a, b)
    assert not near_duplicate(a, "Median is the middle value after sorting the data from low to high.")
    s1 = Segment(segment_id="a", module_id="M1", narration_text=a)
    s2 = Segment(segment_id="b", module_id="M1", narration_text=b)
    kept, dropped = dedupe([s1, s2])
    assert len(kept) == 1 and dropped == 1


def test_allocate_moves_words_to_modules_with_headroom():
    out = allocate([500, 500, 500], [100, 1000, 1000], 1500)
    assert out[0] == 100 and sum(out) == 1500 and out[1] > 500


def test_every_chunk_is_assigned_exactly_once_in_order(tmp_path):
    recs, ch = make_chunks()
    o = make_outline(3)
    o.modules[0].source_ids = [recs[0].source_id]  # model claims almost nothing
    groups = assign_chunks(o, ch)
    flat = [c.chunk_id for g in groups for c in g]
    assert sorted(flat) == sorted(c.chunk_id for c in ch) and len(flat) == len(set(flat))
    assert all(groups)


def test_normal_run_reaches_target_and_covers_source(tmp_path):
    (segs, warnings, rep), o, valid = run(FakeLLM(), tmp_path, target=600)
    assert rep["actual_words"] >= 0.9 * 600
    covered = set(rep["covered_source_ids"])
    assert len(covered & valid) / len(valid) >= 0.9        # whole source narrated
    assert all(s.source_ids for s in segs)                 # every segment traceable


def test_short_output_is_expanded_from_the_source(tmp_path):
    llm = FakeLLM(base_factor=0.3)
    (segs, warnings, rep), _, _ = run(llm, tmp_path, target=600)
    assert "expand" in llm.kinds and rep["actual_words"] >= 0.8 * 600


def test_unusable_expansion_triggers_regeneration_not_acceptance(tmp_path):
    llm = FakeLLM(base_factor=0.3, expand_ok=False)
    (segs, warnings, rep), _, _ = run(llm, tmp_path, target=600)
    assert "regen" in llm.kinds
    assert rep["actual_words"] >= 0.8 * 600               # the short script was NOT silently kept


def test_persistent_duplicates_are_removed_and_reported(tmp_path):
    (segs, warnings, rep), _, _ = run(FakeLLM(duplicate=True), tmp_path, target=300)
    texts = [s.narration_text for s in segs]
    assert not any(near_duplicate(a, b) for i, a in enumerate(texts) for b in texts[i + 1:])
    assert any("below target" in w or "produced" in w or "near-duplicate" in w for w in warnings)


def test_insufficient_source_reports_capacity_and_adds_no_filler(tmp_path):
    chunks = make_chunks(n_records=3, words_per=100)       # ~300 source words
    (segs, warnings, rep), _, _ = run(FakeLLM(), tmp_path, target=2500, chunks=chunks)
    assert rep["capacity_words"] < 2500
    assert any("source supports about" in w and "No filler" in w for w in warnings)
    assert rep["actual_words"] <= rep["capacity_words"] * 1.15
    assert rep["capacity_minutes"] < 5


def test_resume_reuses_finished_units(tmp_path):
    llm = FakeLLM()
    run(llm, tmp_path, target=600)
    first = llm.calls
    llm2 = FakeLLM()
    run(llm2, tmp_path, target=600)
    assert first > 0 and llm2.calls == 0


def test_top_up_adds_source_grounded_words_and_assembles(tmp_path):
    (segs, _, rep), outline, _ = run(FakeLLM(), tmp_path, target=400)
    before = sum(s.word_count for s in segs)
    added, spare = top_up(tmp_path / "u", 150, FakeLLM(), "source", WPM)
    assert added > 0 and spare > 0
    segs2, dropped = assemble_script(outline, tmp_path / "u")
    assert sum(len(s.narration_text.split()) for s in segs2) > before - 5
    assert all(s.source_ids for s in segs2)


class JunkLLM(FakeLLM):
    """Never returns parseable JSON; plain-text requests work only if plain_ok."""
    def __init__(self, plain_ok=False):
        super().__init__()
        self.plain_ok = plain_ok

    def generate(self, prompt, system="", json_mode=False):
        self.calls += 1
        if "Plain text only" in prompt and self.plain_ok:
            n = int(re.search(r"about (\d+) words", prompt).group(1))
            return self._narr(n)
        return "I cannot produce that right now."


def test_unparseable_output_never_aborts_job_uses_extractive(tmp_path):
    (segs, warnings, rep), _, valid = run(JunkLLM(), tmp_path, target=300)
    assert segs and all(s.source_ids for s in segs)
    assert any("directly from the source" in w for w in warnings)


def test_plain_text_fallback_when_json_fails(tmp_path):
    (segs, warnings, rep), _, _ = run(JunkLLM(plain_ok=True), tmp_path, target=300)
    assert segs and rep["actual_words"] > 0
