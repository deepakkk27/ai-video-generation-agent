import pytest

from src.ingestion.dispatcher import new_job_id
from src.storage.jobs import JobError, JobStore


def test_create_and_manifest(tmp_path):
    st = JobStore(tmp_path)
    jid = new_job_id()
    d = st.create(jid)
    assert d.parent == tmp_path.resolve()
    st.set_stage(jid, "x", "done")
    assert st.load(jid)["stages"]["x"]["state"] == "done"


@pytest.mark.parametrize("bad", ["../etc", "..", "abc", "", "a" * 32 + "/../x", "/abs"])
def test_rejects_bad_ids(tmp_path, bad):
    with pytest.raises(JobError):
        JobStore(tmp_path).job_dir(bad)


def test_delete_and_lock(tmp_path):
    st = JobStore(tmp_path)
    jid = new_job_id()
    st.create(jid)
    st.delete(jid)
    assert not (tmp_path / jid).exists()
    assert st.acquire_lock(jid) and not st.acquire_lock(jid)
    st.release_lock()
    assert st.acquire_lock(jid)
