"""Offline orchestrator test with mocked LLM and TTS; FFmpeg required only if present."""
import json
import shutil

import numpy as np
import pytest

from config import load_settings
from src.ingestion.dispatcher import new_job_id
from src.pipeline import orchestrator as orch
from src.storage.jobs import JobStore
from src.tts.audio_utils import write_wav
from src.tts.base import TTSError, TTSProvider


class FakeLLM:
    model = "fake"

    def health(self):
        return True, "ok"

    def generate(self, prompt, system="", json_mode=False):
        if "Analyze this source chunk" in prompt:
            return '{"summary":"Plants make glucose.","main_ideas":["Photosynthesis makes glucose [TXT-L000002]"],"facts":["f [TXT-L000002]"]}'
        if "Combine these chunk summaries" in prompt:
            return '{"summary":"Photosynthesis overview."}'
        if "Plan a course" in prompt:
            return json.dumps({"title": "Photosynthesis", "objectives": ["Explain it"], "modules": [
                {"module_id": "M1", "title": "Basics", "source_ids": ["TXT-L000002"], "word_budget": 100}]})
        return json.dumps({"segments": [
            {"segment_id": "M1-S001", "module_id": "M1", "narration_text": "Plants convert light into chemical energy. It is stored in glucose.",
             "source_ids": ["TXT-L000002"], "visual_type": "bullets", "visual_title": "Basics", "on_screen_text": ["Light", "Glucose"]}]})


class FakeTTS(TTSProvider):
    name = "fake"
    fail = False

    @property
    def voice(self):
        return "v"

    def availability(self):
        return True, "ok"

    def list_voices(self):
        return ["v"]

    def synthesize(self, text, out):
        if self.fail:
            raise TTSError("boom")
        write_wav(np.sin(np.linspace(0, 300, 24000 * 2)).astype(np.float32) * 0.4, 24000, out)


def setup(tmp_path):
    s = load_settings()
    st = JobStore(tmp_path / "out")
    jid = new_job_id()
    d = st.create(jid)
    up = d / "original.txt"
    up.write_text("# Title\n\nPlants convert light into chemical energy.\n\nChlorophyll absorbs light.", encoding="utf-8")
    orch.analyze_source(st, jid, up, s)
    return s, st, jid


def test_analyze_source(tmp_path):
    s, st, jid = setup(tmp_path)
    assert st.load(jid)["source"]["coverage_complete"]


def test_tts_failure_stops_cleanly_and_keeps_state(tmp_path):
    if not shutil.which("ffmpeg"):
        pytest.skip("ffmpeg not installed")
    s, st, jid = setup(tmp_path)
    t = FakeTTS()
    t.fail = True
    with pytest.raises(orch.PipelineError):
        orch.generate_video(st, jid, orch.CourseRequest(minutes=1), s, FakeLLM(), t)
    assert st.load(jid)["status"] == "failed"
    assert not (st.job_dir(jid) / "course_video.mp4").exists()
    assert (st.job_dir(jid) / "outline.json").exists()  # intermediates kept
    assert not (st.root / ".lock").exists()


def test_full_run_reports_real_duration(tmp_path):
    if not shutil.which("ffmpeg"):
        pytest.skip("ffmpeg not installed")
    s, st, jid = setup(tmp_path)
    meta = orch.generate_video(st, jid, orch.CourseRequest(minutes=1, low_res=True), s, FakeLLM(), FakeTTS())
    assert meta["has_audio"] and meta["actual_duration_s"] > 0
    assert meta["actual_duration_s"] != 60 or meta["within_tolerance"]
    assert (st.job_dir(jid) / "captions.srt").exists()
