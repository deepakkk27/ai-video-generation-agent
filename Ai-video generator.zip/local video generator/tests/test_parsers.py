import pytest

from src.ingestion.dispatcher import IngestError, ingest, sanitize_filename


def test_txt_ids(tmp_path):
    p = tmp_path / "a.txt"
    p.write_text("First para.\n\nSecond para.", encoding="utf-8")
    r = ingest(p)
    assert [x.source_id for x in r.records] == ["TXT-L000001", "TXT-L000002"]


def test_md_heading_flag(tmp_path):
    p = tmp_path / "a.md"
    p.write_text("# Title\n\nBody text here.", encoding="utf-8")
    r = ingest(p)
    assert r.records[0].heading and not r.records[1].heading


def test_srt_and_vtt(tmp_path):
    s = tmp_path / "a.srt"
    s.write_text("1\n00:00:01,000 --> 00:00:03,500\nHello there.\n\n2\n00:00:04,000 --> 00:00:05,000\nBye.\n", encoding="utf-8")
    r = ingest(s)
    assert r.records[0].source_id == "TRANSCRIPT-T0001" and r.records[0].start_s == 1.0 and r.records[0].end_s == 3.5
    v = tmp_path / "a.vtt"
    v.write_text("WEBVTT\n\n00:01.000 --> 00:02.000\nHi <b>you</b>\n", encoding="utf-8")
    r = ingest(v)
    assert r.records[0].text == "Hi you"


def test_docx(tmp_path):
    docx = pytest.importorskip("docx")
    d = docx.Document()
    d.add_heading("Intro", 1)
    d.add_paragraph("Some body.")
    p = tmp_path / "a.docx"
    d.save(p)
    r = ingest(p)
    assert r.records[0].source_id == "DOC-P0001" and r.records[0].heading


def test_pptx(tmp_path):
    pptx = pytest.importorskip("pptx")
    prs = pptx.Presentation()
    s = prs.slides.add_slide(prs.slide_layouts[1])
    s.shapes.title.text = "Slide one"
    s.placeholders[1].text = "Content"
    p = tmp_path / "a.pptx"
    prs.save(p)
    r = ingest(p)
    assert r.records[0].source_id == "PPT-S0001" and "Slide one" in r.records[0].text


def test_pdf(tmp_path):
    fitz = pytest.importorskip("fitz")
    doc = fitz.open()
    pg = doc.new_page()
    pg.insert_text((72, 72), "Hello PDF world, this page has enough text to count.")
    p = tmp_path / "a.pdf"
    doc.save(p)
    r = ingest(p)
    assert r.records[0].source_id == "PDF-P0001"


def test_rejects_bad_files(tmp_path):
    e = tmp_path / "e.txt"
    e.write_bytes(b"")
    with pytest.raises(IngestError):
        ingest(e)
    f = tmp_path / "fake.pdf"
    f.write_bytes(b"not a pdf")
    with pytest.raises(IngestError):
        ingest(f)
    g = tmp_path / "x.exe"
    g.write_bytes(b"abc")
    with pytest.raises(IngestError):
        ingest(g)
    big = tmp_path / "b.txt"
    big.write_text("hello")
    with pytest.raises(IngestError):
        ingest(big, max_upload_mb=0)


def test_sanitize():
    assert sanitize_filename("../../etc/pass wd.txt") == "pass wd.txt"
