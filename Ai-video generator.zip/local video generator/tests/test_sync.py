"""Synchronization: cues, shared timeline, frame-exact render. No Kokoro/WhisperX needed."""
import json
import shutil

import pytest

from src.models.schemas import AlignedWord, AudioUnit, Segment, UnitAlignment
from src.sync import cues as C
from src.sync.timeline import build_timeline, to_frame
from src.video.subtitles import assign_timeline

FPS = 25


def unit(uid, seg, text, dur):
    return AudioUnit(unit_id=uid, segment_id=seg, text=text, wav_path="x.wav", duration_s=dur)


def aligned(u, per_word=0.3, start=0.05, unaligned=()):
    ws, t = [], start
    for w in u.text.split():
        if w.strip(".,").lower() in unaligned:
            ws.append(AlignedWord(word=w))
        else:
            ws.append(AlignedWord(word=w, start=round(t, 3), end=round(t + per_word, 3), score=0.9, aligned=True))
        t += per_word + 0.05
    return UnitAlignment(unit_id=u.unit_id, status="ok", words=ws)


def seg(sid="S1", vt="steps", items=("Initialize the centroids", "Assign points", "Update the centroids")):
    return Segment(segment_id=sid, module_id="M", narration_text="x", visual_type=vt, visual_title="T",
                   on_screen_text=list(items))


NARR = ["First, initialize the centroids at random.", "Second, assign every point to its nearest centroid.",
        "Third, update each centroid to the mean."]


def make(narr=NARR, **kw):
    us = assign_timeline([unit(f"S1-U{i}", "S1", t, 2.0 + i) for i, t in enumerate(narr)], 0.35)
    al = {u.unit_id: aligned(u, **kw) for u in us}
    return us, al


def test_stemming_matches_inflections():
    assert C.stem("initializes") == C.stem("initialize")
    assert C.stem("assigned") == C.stem("assign") == C.stem("assigns")
    assert C.stem("centroids") == C.stem("centroid")


def test_each_item_is_revealed_when_its_words_are_spoken_not_earlier():
    us, al = make()
    r = C.resolve_cues(seg(), us, al, None)
    t = {c.text: c for c in r.cues}
    assert t["Initialize the centroids"].anchor_word.lower().startswith("initialize")
    assert t["Assign points"].unit_id == "S1-U1" and t["Assign points"].anchor_word.lower() == "assign"
    # 'centroid' is also spoken in sentence 2; the item must wait for 'update' in sentence 3
    assert t["Update the centroids"].unit_id == "S1-U2" and t["Update the centroids"].anchor_word.lower() == "update"
    assert [c.time_s for c in r.cues] == sorted(c.time_s for c in r.cues)
    assert all(c.method == "lexical" for c in r.cues)


def test_unaligned_word_never_gets_an_invented_time():
    us, al = make(unaligned=("assign",))
    r = C.resolve_cues(seg(), us, al, None)
    c = next(c for c in r.cues if c.text == "Assign points")
    # falls back to a REAL time: a neighbouring aligned word of that clip or the clip start
    sentence_start = us[1].start_s
    real_times = {sentence_start + w.start for w in al["S1-U1"].words if w.aligned} | {sentence_start}
    assert c.time_s in {round(x, 4) for x in real_times}


def test_no_aligner_gives_sentence_level_times_and_is_flagged():
    us, _ = make()
    r = C.resolve_cues(seg(), us, {}, None)
    c = next(c for c in r.cues if c.text == "Update the centroids")
    assert c.time_s == us[2].start_s and c.method.endswith("_unit")


def test_missing_item_is_flagged_not_silently_placed():
    us, al = make()
    r = C.resolve_cues(seg(items=("Quantum entanglement",)), us, al, None)
    assert r.cues[0].method == "unit_fallback" and r.cues[0].warning


class ScriptedLLM:
    model = "fake"

    def __init__(self, reply):
        self.reply, self.calls = reply, 0

    def generate(self, prompt, system="", json_mode=False):
        self.calls += 1
        return self.reply


def test_llm_items_must_be_grounded_and_cue_must_be_verbatim(tmp_path):
    us, al = make()
    good = {"items": [{"text": "Initialize the centroids", "cue": "initialize the centroids"},
                      {"text": "Assign every point", "cue": "assign every point"},
                      {"text": "Quantum entanglement", "cue": "quantum"},      # not in narration -> dropped
                      {"text": "Update each centroid", "cue": "made up words"}]}  # cue not verbatim -> lexical
    llm = ScriptedLLM(json.dumps(good))
    r = C.resolve_cues(seg(), us, al, llm, tmp_path)
    assert r.llm_grounded and "Quantum entanglement" not in r.items
    m = {c.text: c.method for c in r.cues}
    assert m["Initialize the centroids"] == "llm" and m["Assign every point"] == "llm"
    assert m["Update each centroid"] == "lexical"
    C.resolve_cues(seg(), us, al, llm, tmp_path)
    assert llm.calls == 1                       # second call served from the cache


def test_llm_garbage_falls_back_to_lexical_and_breaker_stops_calls():
    us, al = make()
    llm = ScriptedLLM("not json at all")
    br = C.Breaker(limit=2)
    for _ in range(4):
        r = C.resolve_cues(seg(), us, al, llm, None, br)
        assert [c.method for c in r.cues] == ["lexical"] * 3
    assert llm.calls == 2 and br.open


def test_timeline_never_early_at_most_one_frame_late_and_tiles():
    us, al = make()
    segs = [seg()]
    res = {"S1": C.resolve_cues(segs[0], us, al, None)}
    total = us[-1].end_s + 0.35
    beats, shots = build_timeline(segs, us, al, res, FPS, total)
    assert shots[0].start_frame == 0 and shots[-1].end_frame == to_frame(total, FPS)
    for a, b in zip(shots, shots[1:]):
        assert a.end_frame == b.start_frame
    for c in beats[0].cues:
        sh = next(s for s in shots if s.revealed > c.index)
        assert sh.start_s >= c.time_s - 1e-9 and sh.start_s - c.time_s <= 1 / FPS + 1e-9
    assert [s.revealed for s in shots][0] == 0 and shots[-1].revealed == 3
    assert max(s.revealed for s in shots) == 3


def test_beat_change_happens_exactly_when_next_narration_starts():
    a, b = ("S1", "S2")
    us = assign_timeline([unit("S1-U0", "S1", "Alpha beta.", 2.0), unit("S2-U0", "S2", "Gamma delta.", 2.0)], 0.35)
    segs = [seg("S1", "bullets", ("Alpha",)), seg("S2", "bullets", ("Gamma",))]
    al = {u.unit_id: aligned(u) for u in us}
    res = {s.segment_id: C.resolve_cues(s, [u for u in us if u.segment_id == s.segment_id], al, None) for s in segs}
    beats, shots = build_timeline(segs, us, al, res, FPS, us[-1].end_s + 0.35)
    first_b2 = next(s for s in shots if s.beat_id == beats[1].beat_id)
    assert 0 <= first_b2.start_s - us[1].start_s <= 1 / FPS + 1e-9
    last_b1 = [s for s in shots if s.beat_id == beats[0].beat_id][-1]
    assert last_b1.end_frame == first_b2.start_frame           # pause stays with the sentence just spoken


def test_sample_exact_timeline_has_no_drift_over_thousands_of_clips():
    us = [unit(f"U{i}", "S", "x", 1.0 + (i % 7) * 0.1234567) for i in range(3000)]
    assign_timeline(us, 0.3333)
    sr = 24000
    pause_n = round(0.3333 * sr)
    n = sum(round(u.duration_s * sr) + pause_n for u in us)
    assert abs((us[-1].end_s + pause_n / sr) - n / sr) < 1e-9


@pytest.mark.skipif(not shutil.which("ffmpeg"), reason="ffmpeg not installed")
def test_end_to_end_synthetic_video_is_frame_exact(tmp_path):
    import subprocess, sys
    r = subprocess.run([sys.executable, "sync_test.py", "--synthetic", "--lowres", "--out", str(tmp_path / "o")],
                       capture_output=True, text=True, cwd=str(__import__("pathlib").Path(__file__).parent.parent))
    assert r.returncode == 0, r.stdout + r.stderr
    rep = json.loads((tmp_path / "o" / "sync" / "sync_report.json").read_text())
    assert rep["sync_verified"] and rep["frame_verification"]["frames_decoded"] == rep["frame_verification"]["frames_planned"]
