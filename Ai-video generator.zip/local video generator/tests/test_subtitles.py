import re

from src.models.schemas import AudioUnit
from src.video.subtitles import assign_timeline, build_srt, fmt_ts, validate_timeline
from src.visuals.renderer import split_units


def mk(durs):
    return [AudioUnit(unit_id=f"U{i}", segment_id="S", text=f"Text {i}.", wav_path="x", duration_s=d)
            for i, d in enumerate(durs)]


def test_timeline_matches_measured_and_monotonic():
    u = assign_timeline(mk([1.2, 2.5, 0.8]), 0.35)
    assert validate_timeline(u) == []
    assert u[0].end_s - u[0].start_s == 1.2
    assert u[1].start_s == 1.55
    assert all(u[i].start_s > u[i - 1].end_s for i in range(1, len(u)))


def test_srt_format():
    srt = build_srt(assign_timeline(mk([1.0, 1.0]), 0.5))
    assert re.search(r"1\n00:00:00,000 --> 00:00:01,000\nText 0\.", srt)
    assert "00:00:01,500 --> 00:00:02,500" in srt
    assert fmt_ts(3661.5) == "01:01:01,500"


def test_validate_catches_mismatch():
    u = assign_timeline(mk([1.0, 1.0]), 0.1)
    u[1].end_s += 0.5
    assert validate_timeline(u)


def test_split_units_bounded():
    text = "Short one. " + "word " * 60 + "end."
    units = split_units(text, 20)
    assert all(len(x.split()) <= 20 for x in units)
    assert " ".join(units).replace("  ", " ").count("word") == 60
