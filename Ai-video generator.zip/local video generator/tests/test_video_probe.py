import shutil
import wave

import numpy as np
import pytest

from src.models.schemas import AudioUnit
from src.tts.audio_utils import write_wav
from src.tts.base import TTSError
from src.video.probe import validate_mp4, validate_summary
from src.video.assembler import build_audio_track

GOOD = {"duration_s": 5, "has_video": True, "has_audio": True, "width": 1920, "height": 1080}


def test_validate_good():
    assert validate_summary(GOOD, 1920, 1080) == []


def test_validate_rejects_missing_streams_and_duration():
    assert any("audio" in p for p in validate_summary({**GOOD, "has_audio": False}, 1920, 1080))
    assert any("video" in p for p in validate_summary({**GOOD, "has_video": False}, 1920, 1080))
    assert any("duration" in p for p in validate_summary({**GOOD, "duration_s": 0}, 1920, 1080))
    assert any("size" in p for p in validate_summary({**GOOD, "width": 640}, 1920, 1080))


def test_missing_file(tmp_path):
    _, problems = validate_mp4(tmp_path / "nope.mp4", 1920, 1080)
    assert problems


def test_write_wav_rejects_silence_and_empty(tmp_path):
    with pytest.raises(ValueError):
        write_wav(np.zeros(100), 24000, tmp_path / "a.wav")
    with pytest.raises(ValueError):
        write_wav([], 24000, tmp_path / "b.wav")


def test_audio_track_stops_on_missing_clip(tmp_path):
    u = [AudioUnit(unit_id="U1", segment_id="S", text="x", wav_path=str(tmp_path / "missing.wav"), duration_s=1)]
    with pytest.raises(FileNotFoundError):
        build_audio_track(u, 0.3, tmp_path / "out.wav")


def test_audio_track_length(tmp_path):
    sig = np.sin(np.linspace(0, 440 * 6.28, 24000)).astype(np.float32) * 0.5
    units = []
    for i in range(2):
        p = tmp_path / f"{i}.wav"
        write_wav(sig, 24000, p)
        units.append(AudioUnit(unit_id=f"U{i}", segment_id="S", text="x", wav_path=str(p), duration_s=1.0))
    out = tmp_path / "t.wav"
    build_audio_track(units, 0.5, out)
    with wave.open(str(out)) as w:
        assert w.getnframes() / w.getframerate() == pytest.approx(3.0, abs=0.01)


@pytest.mark.skipif(not shutil.which("ffmpeg"), reason="ffmpeg not installed")
def test_real_ffmpeg_pipeline(tmp_path):
    """Mini end-to-end of frames -> clips -> mux with synthetic audio (no LLM/TTS)."""
    from src.models.schemas import Segment
    from src.video.assembler import assemble
    from src.video.subtitles import assign_timeline
    from src.visuals.renderer import render_frames
    sig = np.sin(np.linspace(0, 880 * 6.28, 24000)).astype(np.float32) * 0.5
    segs = [Segment(segment_id="M1-S001", module_id="M1", narration_text="Hello world.",
                    visual_type="bullets", visual_title="Test", on_screen_text=["One", "Two"])]
    units = []
    for i in range(2):
        p = tmp_path / f"u{i}.wav"
        write_wav(sig, 24000, p)
        units.append(AudioUnit(unit_id=f"M1-S001-U0{i}", segment_id="M1-S001", text="Hello world.",
                               wav_path=str(p), duration_s=1.0))
    assign_timeline(units, 0.3)
    frames = render_frames(segs, units, tmp_path / "f", 640, 360, "Deep Blue")
    out = tmp_path / "o.mp4"
    assemble(units, frames, 0.3, tmp_path, out, 640, 360, 25)
    s, problems = validate_mp4(out, 640, 360)
    assert problems == [] and s["duration_s"] > 2
