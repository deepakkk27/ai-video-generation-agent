import pytest

from src.pipeline.duration import (deviation_percent, describe, estimate_seconds,
                                   target_word_count, within_tolerance)


@pytest.mark.parametrize("m", [10, 20, 30, 40, 60])
def test_word_targets_in_expected_band(m):
    w = target_word_count(m)
    assert 125 * m <= w <= 135 * m
    assert estimate_seconds(w) == pytest.approx(m * 60, rel=0.01)


def test_tolerance():
    assert within_tolerance(603, 600, 3)
    assert not within_tolerance(560, 600, 3)
    assert deviation_percent(660, 600) == pytest.approx(10)


def test_describe_is_honest():
    assert "outside" in describe(500, 600, 3)
    assert "within" in describe(601, 600, 3)
