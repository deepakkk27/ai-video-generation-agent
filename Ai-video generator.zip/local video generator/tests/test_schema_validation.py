import pytest

from src.llm.base import LLMError
from src.llm.validators import audit_segments, extract_json, parse_with_repair
from src.models.schemas import ModuleScript, Segment


class Repairer:
    def __init__(self, reply):
        self.reply, self.n = reply, 0

    def generate(self, prompt, system="", json_mode=False):
        self.n += 1
        return self.reply


GOOD = '{"segments":[{"segment_id":"M1-S001","module_id":"M1","narration_text":"Hi."}]}'


def test_extract_from_fenced():
    assert extract_json('```json\n{"a":1}\n```') == {"a": 1}


def test_valid_passes_without_llm():
    llm = Repairer("x")
    assert parse_with_repair(GOOD, ModuleScript, llm).segments[0].segment_id == "M1-S001"
    assert llm.n == 0


def test_repair_success():
    llm = Repairer(GOOD)
    assert parse_with_repair("{broken", ModuleScript, llm).segments
    assert llm.n == 1


def test_repair_failure_raises():
    with pytest.raises(LLMError):
        parse_with_repair("{broken", ModuleScript, Repairer("still {broken"))


def test_schema_rejects_empty_narration_and_bad_visual():
    with pytest.raises(LLMError):
        parse_with_repair('{"segments":[{"segment_id":"a","module_id":"m","narration_text":"  "}]}',
                          ModuleScript, Repairer("{}"))
    # Unknown visual/segment types are coerced to safe known values, never passed through.
    s = parse_with_repair('{"segments":[{"segment_id":"a","module_id":"m","narration_text":"x",'
                          '"visual_type":"exec_code","segment_type":"comparison"}]}',
                          ModuleScript, Repairer("{}")).segments[0]
    assert s.visual_type == "bullets" and s.segment_type == "explanation"


def test_unsupported_claims_flagged():
    s = Segment(segment_id="M1-S001", module_id="M1", narration_text="Water boils at 100 C.")
    assert any("no source reference" in w for w in audit_segments([s], {"A"}, True))
    s2 = Segment(segment_id="M1-S002", module_id="M1", narration_text="Fact.", source_ids=["A"])
    assert audit_segments([s2], {"A"}, True) == []
    s3 = Segment(segment_id="M1-S003", module_id="M1", narration_text="Fact.", source_ids=["ZZ"])
    assert any("unknown source" in w for w in audit_segments([s3], {"A"}, True))
