from src.ingestion.chunker import chunk_records
from src.ingestion.coverage import analysis_coverage, extraction_coverage
from src.llm.analysis import analyze_chunks
from src.models.schemas import SourceRecord


def recs(n=30, size=300):
    return [SourceRecord(source_id=f"PDF-P{i:04d}", kind="pdf", index=i, text=("word " * (size // 5)).strip())
            for i in range(1, n + 1)]


def test_chunk_ids_survive():
    r = recs()
    chunks = chunk_records(r, max_chars=1000)
    got = {s for c in chunks for s in c.source_ids}
    assert got == {x.source_id for x in r}
    assert all(len(c.text) < 1500 for c in chunks)


def test_long_record_split_keeps_id():
    r = [SourceRecord(source_id="TXT-L000001", kind="txt", index=1, text="Sentence one. " * 400)]
    chunks = chunk_records(r, max_chars=1000)
    assert len(chunks) > 1 and all(c.source_ids == ["TXT-L000001"] for c in chunks)


def test_failed_records_excluded_and_reported():
    r = recs(3)
    r[1].status = "failed"
    assert extraction_coverage(r)["complete"] is False
    assert "PDF-P0002" not in {s for c in chunk_records(r) for s in c.source_ids}


class FakeLLM:
    model = "fake"

    def __init__(self, fail_on=None):
        self.fail_on, self.calls = fail_on, 0

    def health(self):
        return True, "ok"

    def generate(self, prompt, system="", json_mode=False):
        self.calls += 1
        # Fail the original request and the repair request (which embeds the bad output).
        if self.fail_on and (self.fail_on in prompt or "not json at all" in prompt):
            return "not json at all"
        return '{"summary": "s", "main_ideas": ["a"], "facts": ["f"]}'


def test_all_chunks_in_manifest(tmp_path):
    chunks = chunk_records(recs(10), max_chars=800)
    an = analyze_chunks(chunks, FakeLLM(), tmp_path)
    cov = analysis_coverage(chunks, an)
    assert cov["complete"] and cov["analyzed"] == len(chunks)


def test_failed_chunk_is_marked(tmp_path):
    chunks = chunk_records(recs(10), max_chars=800)
    an = analyze_chunks(chunks, FakeLLM(fail_on="id C0002"), tmp_path)
    cov = analysis_coverage(chunks, an)
    assert not cov["complete"] and "C0002" in cov["failed"]
